#!/bin/bash
# Flimmer vom Mac entfernen
osascript -e 'tell application "Flimmer" to quit' >/dev/null 2>&1; sleep 1
read -r -p "Flimmer entfernen? Profile und Favoriten werden ebenfalls gelöscht. [j/N] " a
case "$a" in j|J|ja|Ja) ;; *) echo "Abgebrochen."; exit 0;; esac
rm -rf "/Applications/Flimmer.app" "$HOME/Applications/Flimmer.app" \
  "$HOME/Library/Application Support/Flimmer" "$HOME/Library/Caches/Flimmer" "$HOME/Library/Logs/Flimmer"
echo "Flimmer wurde entfernt."
