/* Flimmer für macOS – Electron-Hülle um die Flimmer-Oberfläche */
const { app, BrowserWindow, Menu, shell, session } = require('electron');
const path = require('path');

// Videos sofort abspielen, ohne vorherigen Klick
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
app.setName('Flimmer');

let win = null;

function createWindow() {
  win = new BrowserWindow({
    width: 1440, height: 810, minWidth: 960, minHeight: 540,
    title: 'Flimmer',
    backgroundColor: '#0c0f15',
    show: false,
    webPreferences: {
      // Flimmer spricht direkt mit dem Server des Anbieters. Die Browser-Sperre für
      // fremde Server (CORS) gilt deshalb hier nicht. Es werden nur eigene Dateien geladen.
      webSecurity: false,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false
    }
  });
  win.setAspectRatio(16 / 9);
  win.loadFile(path.join(__dirname, 'www', 'index.html'));
  win.once('ready-to-show', () => win.show());

  // Links nach außen (Trailer usw.) im Standardbrowser öffnen
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file:')) { e.preventDefault(); if (/^https?:/i.test(url)) shell.openExternal(url); }
  });
  // Vollbild: Seitenverhältnis-Sperre lösen, sonst passt das Fenster nicht auf den Bildschirm
  win.on('enter-full-screen', () => win.setAspectRatio(0));
  win.on('leave-full-screen', () => win.setAspectRatio(16 / 9));
  win.on('closed', () => { win = null; });
}

function buildMenu() {
  const key = (name) => () => { if (win) win.webContents.sendInputEvent({ type: 'keyDown', keyCode: name }); };
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { role: 'appMenu', label: 'Flimmer' },
    { label: 'Bearbeiten', submenu: [
      { role: 'undo', label: 'Widerrufen' }, { role: 'redo', label: 'Wiederholen' }, { type: 'separator' },
      { role: 'cut', label: 'Ausschneiden' }, { role: 'copy', label: 'Kopieren' }, { role: 'paste', label: 'Einsetzen' }, { role: 'selectAll', label: 'Alles auswählen' }
    ] },
    { label: 'Bedienung', submenu: [
      { label: 'Zurück', accelerator: 'Esc', click: key('Escape') },
      { type: 'separator' },
      { label: 'Favorit (Rot)', accelerator: 'R', click: key('R') },
      { label: 'Grün', accelerator: 'G', click: key('G') },
      { label: 'Gelb (TV-Guide / Bildformat)', accelerator: 'Y', click: key('Y') },
      { label: 'Blau (Suche / Untertitel)', accelerator: 'B', click: key('B') },
      { label: 'Info', accelerator: 'I', click: key('I') },
      { type: 'separator' },
      { label: 'Sender + / Seite vor', accelerator: 'PageUp', click: key('PageUp') },
      { label: 'Sender − / Seite zurück', accelerator: 'PageDown', click: key('PageDown') }
    ] },
    { label: 'Darstellung', submenu: [
      { role: 'togglefullscreen', label: 'Vollbild' },
      { type: 'separator' },
      { role: 'resetZoom', label: 'Originalgröße' }, { role: 'zoomIn', label: 'Vergrößern' }, { role: 'zoomOut', label: 'Verkleinern' },
      { type: 'separator' },
      { role: 'reload', label: 'Neu laden' }
    ] },
    { role: 'windowMenu', label: 'Fenster' }
  ]));
}

// Nur eine Flimmer-Instanz
if (!app.requestSingleInstanceLock()) { app.quit(); }
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(() => {
    // Manche Anbieter lassen nur bekannte Player zu: neutralen Player-Kennzeichner senden
    session.defaultSession.setUserAgent(session.defaultSession.getUserAgent().replace(/ Electron\/\S+| flimmer\/\S+/gi, ''));
    buildMenu();
    createWindow();
  });
  app.on('activate', () => { if (!win) createWindow(); });
  app.on('window-all-closed', () => app.quit());
}
