/* Flimmer – Player: ein <video> für Vorschau und Vollbild, nativ (HLS/MP4/MKV) oder mpegts.js (MPEG-TS) */
(function () {
  'use strict';
  var U = F.util, h = U.h, S = F.store, t = function (k, v) { return F.t(k, v); };
  var ASPECTS = ['auto', '16:9', '4:3', 'zoom', 'fill'];

  var P = F.player = {
    mode: null, media: null, mp: null, layer: null, osdTimer: null, seekAcc: 0, seekTimer: null,
    numBuf: '', numTimer: null, lastLive: null, triedAlt: false, nextTimer: null, zap: null,
    lastSave: 0, watchdog: null, lastTime: 0, lastTimeTs: 0, aspect: null, retries: 0,

    init: function () {
      P.video = document.getElementById('video');
      P.vlayer = document.getElementById('video-layer');
      P.ui = document.getElementById('player-ui');
      var v = P.video;
      // Nur bei echtem Puffern anzeigen. 'stalled' bedeutet lediglich, dass gerade keine
      // neuen Daten kommen – das Bild läuft dabei oft aus dem Puffer weiter.
      v.addEventListener('waiting', function () { P.busyLater(); });
      v.addEventListener('playing', function () { P.busy(false); P.retries = 0; P.renderState(); });
      v.addEventListener('canplay', function () { P.busy(false); });
      v.addEventListener('pause', function () { P.renderState(); });
      v.addEventListener('play', function () { P.renderState(); });
      v.addEventListener('timeupdate', P.onTime);
      v.addEventListener('ended', P.onEnded);
      v.addEventListener('error', function () { P.onError('native', v.error ? v.error.code : 0); });
      v.addEventListener('loadedmetadata', function () {
        if (P.media && P.media.startAt && isFinite(v.duration)) {
          try { v.currentTime = P.media.startAt; } catch (e) { /* */ }
          P.media.startAt = 0;
        }
      });
      P.buildUi();
      P.setAspect(S.settings.aspect);
    },

    /* ---------- Engine ---------- */
    mpegtsOk: function () { return !!(window.mpegts && window.mpegts.isSupported && window.mpegts.isSupported()); },

    start: function (url, isLive) {
      P.destroyEngine();
      P.hideError();
      P.busy(true);
      var v = P.video;
      var eng = S.settings.engine;
      var isTs = /\.ts(\?|$)/i.test(url);
      var isFile = /\.(mp4|mkv|m4v|webm|avi|mov)(\?|$)/i.test(url);
      var isHls = /\.m3u8(\?|$)/i.test(url);
      var useMp = P.mpegtsOk() && !isFile && !isHls && (eng === 'mpegts' || (eng === 'auto' && (isTs || isLive)));
      if (eng === 'native') useMp = false;
      // Browser ohne eingebautes HLS (z. B. Mac-App/Chromium): hls.js verwenden, falls geladen
      var useHls = !useMp && isHls && !!window.Hls && window.Hls.isSupported() && !v.canPlayType('application/vnd.apple.mpegurl');
      P.engine = useMp ? 'mpegts' : useHls ? 'hls.js' : 'native';
      P.lastTime = 0; P.lastTimeTs = Date.now();
      if (useMp) {
        var buf = { small: 192, normal: 512, large: 1536 }[S.settings.buffer] || 512;
        P.mp = window.mpegts.createPlayer({ type: 'mpegts', isLive: !!isLive, url: url }, {
          enableWorker: false, enableStashBuffer: true, stashInitialSize: buf * 1024, lazyLoad: false,
          liveBufferLatencyChasing: S.settings.buffer === 'small', liveBufferLatencyMaxLatency: 4, liveBufferLatencyMinRemain: 1.5,
          autoCleanupSourceBuffer: true
        });
        P.mp.on(window.mpegts.Events.ERROR, function (type, detail) { P.onError('mpegts', type + ' ' + detail); });
        P.mp.attachMediaElement(v);
        P.mp.load();
        var pr = P.mp.play();
        if (pr && pr.catch) pr.catch(function () { /* Autoplay */ });
      } else if (useHls) {
        var bl = { small: 10, normal: 30, large: 90 }[S.settings.buffer] || 30;
        P.hls = new window.Hls({ maxBufferLength: bl, liveSyncDurationCount: S.settings.buffer === 'small' ? 2 : 3, enableWorker: true });
        P.hls.on(window.Hls.Events.ERROR, function (ev, d) {
          if (!d || !d.fatal) return;
          if (d.type === window.Hls.ErrorTypes.MEDIA_ERROR && !P.hlsRecovered) { P.hlsRecovered = true; P.hls.recoverMediaError(); return; }
          P.onError('hls.js', d.type + ' ' + d.details);
        });
        P.hlsRecovered = false;
        P.hls.loadSource(url);
        P.hls.attachMedia(v);
        var p3 = v.play();
        if (p3 && p3.catch) p3.catch(function () { /* */ });
      } else {
        v.src = url;
        v.load();
        var p2 = v.play();
        if (p2 && p2.catch) p2.catch(function () { /* */ });
      }
      P.startWatchdog(isLive);
    },

    destroyEngine: function () {
      clearInterval(P.watchdog);
      if (P.hls) { try { P.hls.destroy(); } catch (e0) { /* */ } P.hls = null; }
      if (P.mp) {
        try { P.mp.pause(); P.mp.unload(); P.mp.detachMediaElement(); P.mp.destroy(); } catch (e) { /* */ }
        P.mp = null;
      }
      var v = P.video;
      try { v.pause(); } catch (e2) { /* */ }
      v.removeAttribute('src');
      try { v.load(); } catch (e3) { /* */ }
    },

    /** Live-Streams hängen manchmal: nach 20 s ohne Fortschritt neu verbinden */
    startWatchdog: function (isLive) {
      clearInterval(P.watchdog);
      if (!isLive) return;
      P.watchdog = setInterval(function () {
        var v = P.video;
        if (!P.media || v.paused) return;
        if (Date.now() - P.lastTimeTs > 20000 && P.retries < 3) {
          P.retries++;
          P.lastTimeTs = Date.now();
          P.start(P.media.url, true);
        }
      }, 5000);
    },

    onError: function (src, detail) {
      if (!P.media) return;
      var m = P.media;
      if (m.type === 'live' && !P.triedAlt && F.lib.provider.altLiveUrl) {
        var alt = F.lib.provider.altLiveUrl(m.item, m.url);
        if (alt && alt !== m.url) { P.triedAlt = true; m.url = alt; P.start(alt, true); return; }
      }
      // Archiv: MPEG-TS fehlgeschlagen → HLS-Variante probieren (und umgekehrt)
      if (m.type === 'catchup' && !P.triedAlt) {
        var alt2 = /\.ts(\?|$)/.test(m.url) ? m.url.replace(/\.ts(\?|$)/, '.m3u8$1') : /\.m3u8(\?|$)/.test(m.url) ? m.url.replace(/\.m3u8(\?|$)/, '.ts$1') : null;
        if (alt2) { P.triedAlt = true; m.url = alt2; P.start(alt2, false); return; }
      }
      P.busy(false);
      P.showError(detail);
    },

    /* ---------- Öffentliche Abspiel-Funktionen ---------- */
    playLive: function (item, opts) {
      opts = opts || {};
      var list = opts.list || [item];
      var idx = list.indexOf(item); if (idx < 0) idx = 0;
      var prev = P.media && P.media.type === 'live' ? P.media.item : null;
      if (prev && prev.id !== item.id) P.lastLive = prev;
      var same = P.media && P.media.type === 'live' && P.media.item.id === item.id && !P.errorShown && !P.media.failed;
      P.media = { type: 'live', item: item, list: list, index: idx, url: F.lib.liveUrl(item), onExit: opts.onExit || (P.media && P.media.onExit), onChannel: opts.onChannel || (P.media && P.media.onChannel) };
      P.triedAlt = false; P.retries = 0;
      S.pushRecentLive(item.id);
      if (!same) P.start(P.media.url, true);
      if (opts.mini) P.mini(opts.mini); else P.full();
      if (P.media.onChannel) P.media.onChannel(item, idx);
      P.renderInfo();
      P.showOsd();
    },

    playCatchup: function (item, prog) {
      var url = F.lib.provider.catchupUrl(item, prog);
      if (!url) { F.ui.toast(t('noArchive'), 'error'); return; }
      P.media = { type: 'catchup', item: item, prog: prog, url: url };
      P.triedAlt = false;
      P.start(url, false);
      P.full();
      P.renderInfo(); P.showOsd();
    },

    playVod: function (item, info, startAt) {
      P.media = {
        type: 'vod', item: item, info: info || {}, url: F.lib.vodUrl(Object.assign({}, item, { ext: (info && info.ext) || item.ext })),
        startAt: startAt || 0, key: 'vod:' + item.id,
        meta: { type: 'vod', id: item.id, title: item.name, poster: item.poster || '' }
      };
      P.triedAlt = true;
      P.start(P.media.url, false);
      P.full();
      P.renderInfo(); P.showOsd();
    },

    /** episodes: flache Liste aller Episoden (über Staffeln), index = aktuelle */
    playEpisode: function (series, episodes, index, startAt) {
      var ep = episodes[index];
      if (!ep) return;
      P.cancelNext();
      P.media = {
        type: 'episode', series: series, episodes: episodes, index: index, ep: ep, url: F.lib.episodeUrl(ep),
        startAt: startAt || 0, key: 'ep:' + ep.id,
        meta: { type: 'episode', seriesId: series.id, epId: ep.id, title: series.name, sub: 'S' + U.pad2(ep.season) + ' E' + U.pad2(ep.episode) + (ep.title ? ' · ' + ep.title : ''), poster: series.poster || '' }
      };
      P.triedAlt = true;
      P.start(P.media.url, false);
      P.full();
      P.renderInfo(); P.showOsd();
    },

    /* ---------- Modi ---------- */
    mini: function (rect) {
      P.closeLayer();
      P.mode = 'mini';
      P.miniRect = rect;
      var s = P.vlayer.style;
      P.vlayer.className = 'mini ' + P.aspectClass();
      s.left = rect.left + 'px'; s.top = rect.top + 'px'; s.width = rect.width + 'px'; s.height = rect.height + 'px';
      P.ui.classList.add('hidden');
    },

    full: function () {
      P.mode = 'full';
      P.vlayer.className = 'full ' + P.aspectClass();
      P.vlayer.style.cssText = '';
      P.ui.classList.remove('hidden');
      document.body.classList.add('playing-full');
      if (!P.layer) {
        P.layer = F.nav.push({ root: P.ui, name: 'player', onKey: P.onKey, onBack: P.back, focusDefault: function () { P.ui.focus(); } });
      }
      try { P.ui.focus(); } catch (e) { /* */ }
    },

    closeLayer: function () {
      document.body.classList.remove('playing-full');
      if (P.layer) { var l = P.layer; P.layer = null; F.nav.pop(l); }
      P.closeZap();
    },

    stop: function () {
      var had = !!P.media;
      P.saveProgress(true);
      P.cancelNext();
      P.destroyEngine();
      if (had && F.app && P.media.type !== 'live') F.app.emit('progress');
      P.closeLayer();
      P.media = null;
      P.mode = null;
      P.vlayer.className = 'hidden';
      P.ui.classList.add('hidden');
      P.hideError();
    },

    back: function () {
      if (P.zap) { P.closeZap(); return; }
      if (P.nextTimer) { P.cancelNext(); }
      var m = P.media;
      if (m && m.type === 'live' && m.onExit) {
        var rect = m.onExit(m.item);
        if (rect) { P.mini(rect); return; }
      }
      P.stop();
    },

    onAppHidden: function () {
      if (!P.media) return;
      if (P.media.type === 'live') P.stop();
      else { try { P.video.pause(); } catch (e) { /* */ } P.saveProgress(true); }
    },

    /* ---------- Zeit / Fortschritt ---------- */
    onTime: function () {
      var v = P.video;
      if (v.currentTime !== P.lastTime) {
        P.lastTime = v.currentTime; P.lastTimeTs = Date.now();
        if (P.spinOn) P.busy(false); // Bild läuft → Ladesymbol sicher ausblenden
      }
      if (P.mode === 'full' && P.osdVisible) P.renderProgress();
      if (Date.now() - P.lastSave > 10000) { P.lastSave = Date.now(); P.saveProgress(false); }
    },

    saveProgress: function () {
      var m = P.media, v = P.video;
      if (!m || !m.key || !isFinite(v.duration) || !v.duration) return;
      S.setProgress(m.key, v.currentTime, v.duration, m.meta);
    },

    onEnded: function () {
      var m = P.media;
      if (!m) return;
      if (m.key) S.setWatched(m.key, true);
      if (m.type === 'episode' && S.settings.autoNext && m.episodes[m.index + 1]) { P.showNext(); return; }
      if (m.type === 'vod' || m.type === 'episode' || m.type === 'catchup') P.stop();
      if (F.app) F.app.emit('progress');
    },

    /* ---------- Tasten im Vollbild ---------- */
    onKey: function (k) {
      var m = P.media;
      if (!m) return false;
      if (k === 'BACK' && !P.zap && !P.nextTimer) { P.back(); return true; }
      if (P.errorShown) {
        if (k === 'BACK') { P.back(); return true; }
        return false; // Navigation zwischen Fehler-Buttons
      }
      if (P.nextTimer) {
        if (k === 'ENTER') { P.playNextNow(); return true; }
        if (k === 'BACK') { P.cancelNext(); P.stop(); return true; }
        return true;
      }
      if (P.zap) return P.zapKey(k);
      var isLive = m.type === 'live';

      if (/^[0-9]$/.test(k) && isLive) { P.numInput(k); return true; }

      switch (k) {
        case 'RED':
          if (isLive) { var on = S.toggleFav('live', m.item.id); F.ui.toast(t(on ? 'favAdded' : 'favRemoved')); P.renderInfo(); }
          else if (m.type === 'vod') { var on2 = S.toggleFav('vod', m.item.id); F.ui.toast(t(on2 ? 'favAdded' : 'favRemoved')); }
          P.showOsd(); return true;
        case 'GREEN': P.chooseAudio(); return true;
        case 'YELLOW': P.cycleAspect(); return true;
        case 'BLUE':
          if (isLive) { if (P.lastLive) P.switchTo(P.lastLive); else F.ui.toast(t('noLastChannel')); }
          else P.chooseSubs();
          return true;
        case 'INFO': P.toggleOsd(true); return true;
        case 'STOP': P.back(); return true;
      }

      if (isLive) {
        switch (k) {
          case 'UP': case 'CH_UP': P.step(1); return true;
          case 'DOWN': case 'CH_DOWN': P.step(-1); return true;
          case 'LEFT': P.openZap(); return true;
          case 'RIGHT': P.toggleOsd(true); return true;
          case 'ENTER': if (P.osdVisible) P.openZap(); else P.showOsd(); return true;
          case 'PLAY': case 'PAUSE': case 'PLAYPAUSE': P.showOsd(); return true;
        }
        return true;
      }

      // VOD / Episode / Catch-up
      var v = P.video, step = parseInt(S.settings.seekStep, 10) || 10;
      switch (k) {
        case 'ENTER': case 'PLAYPAUSE': P.togglePlay(); return true;
        case 'PLAY': v.play(); P.showOsd(); return true;
        case 'PAUSE': v.pause(); P.showOsd(); return true;
        case 'LEFT': P.seek(-step); return true;
        case 'RIGHT': P.seek(step); return true;
        case 'RW': P.seek(-step * 3); return true;
        case 'FF': P.seek(step * 3); return true;
        case 'UP': case 'DOWN': P.showOsd(); return true;
        case 'CH_UP': if (m.type === 'episode' && m.episodes[m.index + 1]) { P.saveProgress(); P.playEpisode(m.series, m.episodes, m.index + 1); } return true;
        case 'CH_DOWN': if (m.type === 'episode' && m.index > 0) { P.saveProgress(); P.playEpisode(m.series, m.episodes, m.index - 1); } return true;
      }
      return true;
    },

    togglePlay: function () {
      var v = P.video;
      if (v.paused) { var pr = v.play(); if (pr && pr.catch) pr.catch(function () {}); } else v.pause();
      P.flash(v.paused ? 'pause' : 'play');
      P.showOsd();
    },

    /** Spulen sammeln (mehrfaches Drücken = größerer Sprung) */
    seek: function (delta) {
      var v = P.video;
      if (!isFinite(v.duration)) return;
      P.seekAcc += delta;
      var target = U.clamp(v.currentTime + P.seekAcc, 0, Math.max(0, v.duration - 1));
      P.seekPreview = target;
      P.showOsd();
      P.renderProgress();
      clearTimeout(P.seekTimer);
      P.seekTimer = setTimeout(function () {
        try { v.currentTime = target; } catch (e) { /* */ }
        P.seekAcc = 0; P.seekPreview = null;
        P.renderProgress();
      }, 650);
    },

    step: function (dir) {
      var m = P.media;
      if (!m || !m.list || m.list.length < 2) return;
      var i = (m.index + dir + m.list.length) % m.list.length;
      P.switchTo(m.list[i]);
    },

    switchTo: function (item) {
      var m = P.media;
      if (!m) return;
      var locked = F.lib.isLocked('live', item.cat);
      var go = function () { P.playLive(item, { list: m.list.indexOf(item) >= 0 ? m.list : [item], mini: P.mode === 'mini' ? P.miniRect : null }); };
      if (locked) F.lib.unlock('live', item.cat).then(function (ok) { if (ok) go(); });
      else go();
    },

    numInput: function (d) {
      P.numBuf = (P.numBuf + d).slice(0, 5);
      P.els.num.textContent = P.numBuf;
      P.els.num.classList.add('show');
      clearTimeout(P.numTimer);
      P.numTimer = setTimeout(function () {
        var n = parseInt(P.numBuf, 10);
        P.numBuf = '';
        P.els.num.classList.remove('show');
        var found = null;
        (F.lib.data ? F.lib.data.live.items : []).some(function (it) { if (it.num === n && F.lib.visibleItem('live', it)) { found = it; return true; } return false; });
        if (found) P.switchTo(found); else F.ui.toast(t('noChannelNum', { n: n }));
      }, 1600);
    },

    /* ---------- Audio / Untertitel / Format ---------- */
    chooseAudio: function () {
      if (P.hls && P.hls.audioTracks && P.hls.audioTracks.length > 1) {
        var ht = P.hls.audioTracks;
        F.ui.select({ title: t('audioTrack'), options: ht.map(function (a, i) { return { label: a.name || a.lang || (t('track') + ' ' + (i + 1)), sub: a.lang || '', value: i, checked: i === P.hls.audioTrack }; }) })
          .then(function (v) { if (v !== undefined) P.hls.audioTrack = v; });
        return;
      }
      var at = P.video.audioTracks;
      if (!at || at.length < 2) { F.ui.toast(t('noAudioTracks')); return; }
      var opts = [];
      for (var i = 0; i < at.length; i++) opts.push({ label: at[i].label || at[i].language || (t('track') + ' ' + (i + 1)), sub: at[i].language || '', value: i, checked: at[i].enabled });
      F.ui.select({ title: t('audioTrack'), options: opts }).then(function (v) {
        if (v === undefined) return;
        for (var j = 0; j < at.length; j++) at[j].enabled = j === v;
      });
    },
    chooseSubs: function () {
      var tt = P.video.textTracks;
      if (!tt || !tt.length) { F.ui.toast(t('noSubtitles')); return; }
      var opts = [{ label: t('off'), value: -1, checked: true }];
      for (var i = 0; i < tt.length; i++) {
        if (tt[i].mode === 'showing') opts[0].checked = false;
        opts.push({ label: tt[i].label || tt[i].language || (t('track') + ' ' + (i + 1)), sub: tt[i].language || '', value: i, checked: tt[i].mode === 'showing' });
      }
      F.ui.select({ title: t('subtitles'), options: opts }).then(function (v) {
        if (v === undefined) return;
        for (var j = 0; j < tt.length; j++) tt[j].mode = j === v ? 'showing' : 'disabled';
      });
    },
    aspectClass: function () { return 'ar-' + String(P.aspect || 'auto').replace(':', ''); },
    setAspect: function (a) {
      P.aspect = a;
      ASPECTS.forEach(function (x) { P.vlayer.classList.remove('ar-' + x.replace(':', '')); });
      if (P.mode) P.vlayer.classList.add(P.aspectClass());
    },
    cycleAspect: function () {
      var i = ASPECTS.indexOf(P.aspect);
      P.setAspect(ASPECTS[(i + 1) % ASPECTS.length]);
      F.ui.toast(t('aspect') + ': ' + t('ar_' + P.aspect.replace(':', '')));
    },

    /* ---------- Oberfläche ---------- */
    buildUi: function () {
      var ui = P.ui;
      ui.setAttribute('tabindex', '-1');
      var e = P.els = {};
      e.top = h('div', { 'class': 'p-top' }, [
        e.logo = h('img', { 'class': 'p-logo' }),
        h('div', { 'class': 'p-titles' }, [e.num0 = h('div', { 'class': 'p-chnum' }), e.title = h('div', { 'class': 'p-title' }), e.sub = h('div', { 'class': 'p-sub' })]),
        e.fav = h('span', { 'class': 'p-fav' }),
        e.clock = h('div', { 'class': 'p-clock' })
      ]);
      e.bottom = h('div', { 'class': 'p-bottom' }, [
        e.now = h('div', { 'class': 'p-now' }),
        e.bar = h('div', { 'class': 'p-bar' }, [e.barFill = h('div', { 'class': 'p-bar-fill' }), e.barSeek = h('div', { 'class': 'p-bar-seek' })]),
        e.times = h('div', { 'class': 'p-times' }, [e.tL = h('span'), e.tR = h('span')]),
        e.next = h('div', { 'class': 'p-next-prog' }),
        e.desc = h('div', { 'class': 'p-desc' }),
        e.hints = h('div', { 'class': 'p-hints' })
      ]);
      e.center = h('div', { 'class': 'p-center' });
      e.spin = h('div', { 'class': 'p-spinner hidden' }, h('div', { 'class': 'spinner' }));
      e.num = h('div', { 'class': 'p-numbuf' });
      e.err = h('div', { 'class': 'p-error hidden' });
      e.nextEp = h('div', { 'class': 'p-nextep hidden' });
      e.zap = h('div', { 'class': 'p-zap hidden' });
      [e.top, e.bottom, e.center, e.spin, e.num, e.err, e.nextEp, e.zap].forEach(function (x) { ui.appendChild(x); });
      ui.addEventListener('mousemove', function () { if (P.mode === 'full') P.showOsd(); });
      ui.addEventListener('click', function (ev) { if (ev.target === ui && P.mode === 'full' && P.media && P.media.type !== 'live') P.togglePlay(); });
    },

    busy: function (on) {
      clearTimeout(P.busyTimer);
      P.spinOn = !!on;
      if (P.els) P.els.spin.classList.toggle('hidden', !on);
    },
    /** Ladesymbol erst zeigen, wenn das Bild wirklich ~0,8 s steht */
    busyLater: function () {
      clearTimeout(P.busyTimer);
      var t0 = P.video.currentTime;
      P.busyTimer = setTimeout(function () {
        var v = P.video;
        if (P.media && !v.paused && v.currentTime === t0) P.busy(true);
      }, 800);
    },

    flash: function (icon) {
      var c = P.els.center;
      c.innerHTML = U.icons[icon] || '';
      c.classList.remove('flash'); void c.offsetWidth; c.classList.add('flash');
    },

    showOsd: function (long) {
      if (P.mode !== 'full') return;
      P.osdVisible = true;
      P.ui.classList.add('osd');
      P.renderInfo();
      clearTimeout(P.osdTimer);
      var v = P.video;
      var ms = (parseInt(S.settings.osdTime, 10) || 5) * 1000 * (long ? 2 : 1);
      P.osdTimer = setTimeout(function () {
        if (P.media && P.media.type !== 'live' && v.paused) return; // pausiert: Overlay bleibt
        P.hideOsd();
      }, ms);
    },
    hideOsd: function () { P.osdVisible = false; P.ui.classList.remove('osd'); P.ui.classList.remove('osd-long'); },
    toggleOsd: function (long) {
      if (P.osdVisible && P.ui.classList.contains('osd-long')) { P.hideOsd(); return; }
      P.showOsd(long);
      if (long) P.ui.classList.add('osd-long');
    },

    renderState: function () { if (P.mode === 'full') P.renderProgress(); },

    renderInfo: function () {
      var m = P.media, e = P.els;
      if (!m || !e) return;
      e.clock.textContent = U.fmtTime(Date.now());
      P.ui.className = P.ui.className.replace(/\bpm-\w+/g, '').trim() + ' pm-' + m.type;
      var hints = [];
      if (m.type === 'live') {
        var it = m.item;
        e.logo.style.display = S.settings.showLogos ? '' : 'none';
        e.logo.onerror = function () { e.logo.onerror = null; e.logo.src = U.logoSvg(it.name); };
        e.logo.src = F.lib.logo(it);
        e.num0.textContent = S.settings.showNumbers ? String(it.num) : '';
        e.title.textContent = it.name;
        e.sub.textContent = F.lib.catName('live', it.cat);
        e.fav.innerHTML = S.isFav('live', it.id) ? U.icons.starFill : '';
        var list = F.epg.peek(it);
        P.fillEpg(list);
        F.epg.get(it, true).then(function (l) { if (P.media === m) P.fillEpg(l); });
        hints = [['ch', t('hintZap')], ['LEFT', t('hintChannelList')], ['red', t('favorite')], ['green', t('audio')], ['yellow', t('aspect')], ['blue', t('lastChannel')]];
      } else {
        e.logo.style.display = 'none';
        e.num0.textContent = '';
        e.fav.innerHTML = '';
        if (m.type === 'vod') { e.title.textContent = m.item.name; e.sub.textContent = [m.info.year, m.info.genre].filter(Boolean).join(' · '); }
        else if (m.type === 'episode') { e.title.textContent = m.series.name; e.sub.textContent = m.meta.sub; }
        else { e.title.textContent = m.prog.title; e.sub.textContent = m.item.name + ' · ' + U.fmtDate(m.prog.start) + ' ' + U.fmtTime(m.prog.start); }
        e.now.textContent = ''; e.next.textContent = '';
        e.desc.textContent = m.type === 'vod' ? (m.info.plot || '') : m.type === 'episode' ? (m.ep.plot || '') : (m.prog.desc || '');
        hints = [['ok', t('playPause')], ['LEFT', '−' + S.settings.seekStep + ' s'], ['RIGHT', '+' + S.settings.seekStep + ' s'], ['green', t('audio')], ['yellow', t('aspect')], ['blue', t('subtitles')]];
        if (m.type === 'episode') hints.push(['ch', t('hintEpisode')]);
        P.renderProgress();
      }
      U.empty(e.hints);
      hints.forEach(function (x) {
        var key = U.keyLabel(x[0]);
        e.hints.appendChild(h('span', { 'class': 'hint' }, [h('i', { 'class': 'key key-' + x[0].toLowerCase() }, key), x[1]]));
      });
    },

    fillEpg: function (list) {
      var e = P.els;
      var nn = F.epg.nowNext(list);
      if (nn.cur) {
        e.now.textContent = nn.cur.title;
        e.tL.textContent = U.fmtTime(nn.cur.start);
        e.tR.textContent = U.fmtTime(nn.cur.end) + '  ·  ' + t('minLeft', { n: Math.max(0, Math.round((nn.cur.end - Date.now()) / 60000)) });
        e.barFill.style.width = (F.epg.progress(nn.cur) * 100) + '%';
        e.desc.textContent = nn.cur.desc || '';
      } else {
        e.now.textContent = list === null ? t('epgLoading') : t('noEpg');
        e.tL.textContent = ''; e.tR.textContent = ''; e.barFill.style.width = '0%'; e.desc.textContent = '';
      }
      e.barSeek.style.width = '0%';
      e.next.textContent = nn.next ? t('next') + ': ' + U.fmtTime(nn.next.start) + '  ' + nn.next.title : '';
    },

    renderProgress: function () {
      var m = P.media, e = P.els, v = P.video;
      if (!m || m.type === 'live' || !e) return;
      var dur = isFinite(v.duration) ? v.duration : 0;
      var cur = P.seekPreview !== null && P.seekPreview !== undefined ? P.seekPreview : v.currentTime;
      e.barFill.style.width = dur ? (v.currentTime / dur * 100) + '%' : '0%';
      e.barSeek.style.width = dur && P.seekPreview !== null && P.seekPreview !== undefined ? (cur / dur * 100) + '%' : '0%';
      e.tL.textContent = (v.paused ? '❚❚  ' : '') + U.fmtDur(cur);
      e.tR.textContent = dur ? U.fmtDur(dur) + '  ·  −' + U.fmtDur(dur - cur) : '';
      e.clock.textContent = U.fmtTime(Date.now());
    },

    showError: function (detail) {
      var e = P.els;
      P.errorShown = true;
      if (P.mode !== 'full') {
        // In der Vorschau nur still anzeigen
        F.ui.toast(t('streamError'), 'error');
        P.destroyEngine();
        P.busy(false);
        if (P.media) P.media.failed = true;
        P.errorShown = false;
        return;
      }
      U.empty(e.err);
      e.err.appendChild(h('div', { 'class': 'p-error-title' }, t('streamError')));
      e.err.appendChild(h('div', { 'class': 'p-error-text' }, t('streamErrorText')));
      if (detail) e.err.appendChild(h('div', { 'class': 'p-error-detail' }, t('errorCode') + ': ' + String(detail)));
      var retry = U.btn('button primary', { onclick: function () { P.hideError(); P.triedAlt = false; P.start(P.media.url, P.media.type === 'live'); } }, t('retry'));
      var back = U.btn('button', { onclick: function () { P.hideError(); P.back(); } }, t('back'));
      e.err.appendChild(h('div', { 'class': 'modal-buttons' }, [retry, back]));
      e.err.classList.remove('hidden');
      setTimeout(function () { F.nav.focus(retry); }, 0);
    },
    hideError: function () { P.errorShown = false; if (P.els) P.els.err.classList.add('hidden'); try { if (P.mode === 'full') P.ui.focus(); } catch (e) { /* */ } },

    /* ---------- Nächste Episode ---------- */
    showNext: function () {
      var m = P.media, e = P.els;
      var nx = m.episodes[m.index + 1];
      var sec = parseInt(S.settings.nextCountdown, 10) || 10;
      P.hideOsd();
      U.empty(e.nextEp);
      var cnt = h('div', { 'class': 'p-nextep-count' }, String(sec));
      e.nextEp.appendChild(h('div', { 'class': 'p-nextep-label' }, t('nextEpisode')));
      e.nextEp.appendChild(h('div', { 'class': 'p-nextep-title' }, 'S' + U.pad2(nx.season) + ' E' + U.pad2(nx.episode) + ' · ' + (nx.title || '')));
      e.nextEp.appendChild(cnt);
      e.nextEp.appendChild(F.ui.hints([['ok', t('playNow')], ['back', t('cancel')]]));
      e.nextEp.classList.remove('hidden');
      P.nextTimer = setInterval(function () {
        sec--;
        cnt.textContent = String(sec);
        if (sec <= 0) P.playNextNow();
      }, 1000);
    },
    playNextNow: function () {
      var m = P.media;
      P.cancelNext();
      if (m && m.type === 'episode') P.playEpisode(m.series, m.episodes, m.index + 1);
    },
    cancelNext: function () {
      clearInterval(P.nextTimer); P.nextTimer = null;
      if (P.els) P.els.nextEp.classList.add('hidden');
    },

    /* ---------- Senderliste im Vollbild ---------- */
    openZap: function () {
      var m = P.media;
      if (!m || !m.list) return;
      P.hideOsd();
      var box = P.els.zap;
      U.empty(box);
      box.appendChild(h('div', { 'class': 'p-zap-head' }, F.lib.catName('live', m.item.cat) || t('channels')));
      var gEl = h('div', { 'class': 'p-zap-list' });
      box.appendChild(gEl);
      box.classList.remove('hidden');
      var list = m.list;
      var unlisten = F.epg.listen(function () { if (P.zap) P.zap.grid.refresh(); });
      var grid = new F.VGrid({
        container: gEl, rowRem: 5.2, count: list.length,
        render: function (i) {
          var it = list[i];
          var nn = F.epg.nowNext(F.epg.peek(it));
          if (!F.epg.peek(it)) F.epg.get(it);
          return h('div', { 'class': 'zap-row' + (it.id === m.item.id ? ' playing' : '') }, [
            h('span', { 'class': 'zap-num' }, String(it.num)),
            U.img(F.lib.logo(it), U.logoSvg(it.name), 'zap-logo'),
            h('div', { 'class': 'zap-text' }, [h('div', { 'class': 'zap-name' }, it.name), h('div', { 'class': 'zap-now' }, nn.cur ? nn.cur.title : '')])
          ]);
        },
        onSelect: function (i) { P.closeZap(); P.switchTo(list[i]); }
      });
      grid.index = Math.max(0, list.indexOf(m.item));
      grid.refresh();
      P.zap = { grid: grid, unlisten: unlisten };
      grid.focus();
    },
    zapKey: function (k) {
      if (k === 'LEFT' || k === 'BACK') { P.closeZap(); return true; }
      if (k === 'RIGHT') return true;
      return P.zap.grid.onKey(k) || true;
    },
    closeZap: function () {
      if (!P.zap) return;
      P.zap.unlisten(); P.zap.grid.destroy();
      P.zap = null;
      P.els.zap.classList.add('hidden');
      try { P.ui.focus(); } catch (e) { /* */ }
    }
  };
})();
