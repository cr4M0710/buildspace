/* Flimmer – EPG: pro Sender (Xtream), vollständiges XMLTV oder Demo */
(function () {
  'use strict';
  var U = F.util, S = F.store;
  var TTL = 30 * 60000;
  var DAY = 86400000;

  var E = F.epg = {
    mode: 'short', cache: {}, xml: null, xmlState: 'idle', listeners: [], q: U.queue(4),

    reset: function () {
      E.cache = {}; E.xml = null; E.xmlState = 'idle'; E.q.clear();
      var prov = F.lib.provider;
      var prof = S.profile();
      if (!prov) return;
      if (prov.kind === 'demo') E.mode = 'demo';
      else if (prov.kind === 'm3u' || (prof && prof.epgUrl) || S.settings.epgSource === 'xmltv') E.mode = 'xmltv';
      else E.mode = 'short';
      if (E.mode === 'xmltv') E.loadXml();
    },

    listen: function (fn) { E.listeners.push(fn); return function () { E.listeners = E.listeners.filter(function (f) { return f !== fn; }); }; },
    emit: function (id) { E.listeners.forEach(function (fn) { try { fn(id); } catch (e) { /* */ } }); },

    xmlUrl: function () {
      var prof = S.profile();
      return (prof && prof.epgUrl) || (F.lib.provider && F.lib.provider.xmltvUrl()) || '';
    },

    loadXml: function (force) {
      var url = E.xmlUrl();
      var pid = S.activeId;
      if (!url) { E.xmlState = 'none'; return Promise.resolve(); }
      E.xmlState = 'loading';
      var key = 'xmltv:' + pid;
      return F.db.get(key).then(function (c) {
        if (!force && c && c.url === url && Date.now() - c.ts < 12 * 3600000) { E.xml = c.data; E.xmlState = 'ready'; E.emit(null); return; }
        if (c && c.url === url) { E.xml = c.data; E.emit(null); }
        return U.text(url, { timeout: 300000 }).then(function (txt) {
          var live = (F.lib.data && F.lib.data.live.items) || [];
          var want = function (names) {
            var w = {};
            live.forEach(function (it) {
              if (it.epgId) w[String(it.epgId).toLowerCase()] = true;
              var byName = names[U.norm(it.name)];
              if (byName) w[byName] = true;
            });
            return w;
          };
          var now = Date.now();
          var parsed = F.xmltv.parse(txt, live.length ? want : null, now - 4 * DAY, now + 4 * DAY);
          txt = null;
          if (pid !== S.activeId) return;
          E.xml = { map: parsed.map, names: parsed.names };
          E.xmlState = 'ready';
          F.db.set(key, { ts: Date.now(), url: url, data: E.xml });
          E.emit(null);
        });
      }).catch(function () {
        E.xmlState = E.xml ? 'ready' : 'error';
        E.emit(null);
      });
    },

    off: function () { return (parseFloat(S.settings.epgOffset) || 0) * 3600000; },

    shift: function (list) {
      var o = E.off();
      if (!o || !list) return list;
      return list.map(function (p) { return { start: p.start + o, end: p.end + o, title: p.title, desc: p.desc, archive: p.archive, cat: p.cat }; });
    },

    /** Synchron aus Cache (oder null) */
    peek: function (item) {
      if (!item) return null;
      if (E.mode === 'demo') return E.shift(F.lib.provider.demoEpg(item));
      if (E.mode === 'xmltv') {
        if (!E.xml) return null;
        var id = String(item.epgId || '').toLowerCase();
        var l = E.xml.map[id];
        if (!l) { var nid = E.xml.names[U.norm(item.name)]; if (nid) l = E.xml.map[nid]; }
        return l ? E.shift(l) : [];
      }
      var c = E.cache[item.id];
      return c && c.ts ? E.shift(c.list) : null;
    },

    /** Asynchron (lädt bei Bedarf nach) */
    get: function (item, priority) {
      var p = E.peek(item);
      if (E.mode !== 'short') return Promise.resolve(p || []);
      var c = E.cache[item.id];
      if (c && Date.now() - c.ts < TTL) return Promise.resolve(E.shift(c.list));
      if (c && c.pending) return c.pending;
      var entry = E.cache[item.id] = { ts: 0, list: (c && c.list) || [] };
      entry.pending = E.q.push(function () { return F.lib.provider.shortEpg(item); }, priority).then(function (list) {
        entry.list = list || []; entry.ts = Date.now(); entry.pending = null;
        E.emit(item.id);
        return E.shift(entry.list);
      }, function () { entry.pending = null; entry.ts = Date.now() - TTL + 120000; return []; });
      return entry.pending;
    },

    /** Aktuelle und nächste Sendung */
    nowNext: function (list, ts) {
      ts = ts || Date.now();
      if (!list || !list.length) return { cur: null, next: null, idx: -1 };
      for (var i = 0; i < list.length; i++) {
        if (list[i].start <= ts && list[i].end > ts) return { cur: list[i], next: list[i + 1] || null, idx: i, later: list.slice(i + 1, i + 5) };
        if (list[i].start > ts) return { cur: null, next: list[i], idx: i, later: list.slice(i, i + 4) };
      }
      return { cur: null, next: null, idx: -1 };
    },

    progress: function (p, ts) {
      if (!p) return 0;
      ts = ts || Date.now();
      return U.clamp((ts - p.start) / (p.end - p.start), 0, 1);
    }
  };
})();
