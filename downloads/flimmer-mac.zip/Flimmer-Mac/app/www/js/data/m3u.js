/* Flimmer – M3U/M3U8-Playlist-Parser: trennt Live-TV, Filme und Serien */
(function () {
  'use strict';
  var U = F.util;

  var VOD_EXT = /\.(mp4|mkv|avi|mov|wmv|m4v|webm|mpg|mpeg|flv)(\?|$)/i;
  var SXE = /^(.*?)[\s._\-|]*(?:S|Staffel\s*)(\d{1,2})[\s._-]*(?:E|Ep\.?|Folge\s*)(\d{1,3})\b(.*)$/i;
  var ATTR = /([a-zA-Z0-9_-]+)="([^"]*)"/g;

  function attrs(line) {
    var o = {}, m;
    ATTR.lastIndex = 0;
    while ((m = ATTR.exec(line))) o[m[1].toLowerCase()] = m[2];
    return o;
  }

  function title(line) {
    // Titel steht nach dem letzten Komma außerhalb von Anführungszeichen
    var inQ = false, pos = -1;
    for (var i = 0; i < line.length; i++) {
      var c = line[i];
      if (c === '"') inQ = !inQ;
      else if (c === ',' && !inQ) pos = i;
    }
    return pos >= 0 ? line.slice(pos + 1).trim() : '';
  }

  function ext(url) {
    var m = /\.([a-z0-9]{2,4})(\?|$)/i.exec(url);
    return m ? m[1].toLowerCase() : '';
  }

  function year(name) {
    var m = /[(\[ ]((?:19|20)\d{2})[)\] ]?\s*$/.exec(name) || /\(((?:19|20)\d{2})\)/.exec(name);
    return m ? m[1] : '';
  }

  F.m3u = {
    parse: function (text) {
      var lines = text.split(/\r?\n/);
      var head = lines[0] || '';
      if (head.indexOf('#EXTM3U') !== 0 && text.indexOf('#EXTINF') < 0) {
        var e = new Error('no m3u'); e.kind = 'format'; throw e;
      }
      var headAttrs = attrs(head);
      var res = {
        epgUrl: headAttrs['url-tvg'] || headAttrs['x-tvg-url'] || '',
        live: { cats: [], items: [] },
        vod: { cats: [], items: [] },
        series: { cats: [], items: [] }
      };
      var catMap = { live: {}, vod: {}, series: {} };
      var seriesMap = {};
      var ids = {};
      function cat(type, name) {
        name = name || F.t('uncategorized');
        var id = U.hash(type + ':' + name);
        if (!catMap[type][id]) { catMap[type][id] = true; res[type].cats.push({ id: id, name: name }); }
        return id;
      }
      function uniq(id) {
        if (!ids[id]) { ids[id] = 1; return id; }
        ids[id]++;
        return id + '_' + ids[id];
      }

      var cur = null, grp = '', liveNum = 0, vodIdx = 0;
      for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();
        if (!line) continue;
        if (line.indexOf('#EXTINF') === 0) {
          cur = attrs(line);
          cur._title = title(line) || cur['tvg-name'] || '';
          grp = '';
          continue;
        }
        if (line.indexOf('#EXTGRP:') === 0) { grp = line.slice(8).trim(); continue; }
        if (line[0] === '#') continue;
        if (!cur) continue;

        var url = line, name = cur._title || cur['tvg-name'] || url;
        var group = cur['group-title'] || grp;
        var logo = cur['tvg-logo'] || cur['logo'] || '';
        var type = 'live';
        var sxe = SXE.exec(name);
        if (/\/series\//i.test(url)) type = 'series';
        else if (/\/movie\//i.test(url)) type = 'vod';
        else if (VOD_EXT.test(url)) type = sxe ? 'series' : 'vod';
        if (type === 'series' && !sxe) type = 'vod';

        if (type === 'live') {
          liveNum++;
          res.live.items.push({
            id: uniq('l' + U.hash(name + '|' + (cur['tvg-id'] || '') + '|' + group)),
            num: parseInt(cur['tvg-chno'] || cur['channel-number'] || liveNum, 10) || liveNum,
            name: name, logo: logo, cat: cat('live', group),
            epgId: cur['tvg-id'] || cur['tvg-name'] || '',
            url: url,
            archive: !!(cur.catchup || cur['catchup-source'] || cur['tvg-rec'] || cur.timeshift),
            archiveDays: parseInt(cur['catchup-days'] || cur['tvg-rec'] || cur.timeshift || '0', 10) || 0,
            catchupType: cur.catchup || (cur['catchup-source'] ? 'default' : (cur.timeshift || cur['tvg-rec'] ? 'shift' : '')),
            catchupSrc: cur['catchup-source'] || ''
          });
        } else if (type === 'vod') {
          vodIdx++;
          res.vod.items.push({
            id: uniq('v' + U.hash(name + '|' + group)),
            name: name, poster: logo, cat: cat('vod', group), url: url, ext: ext(url) || 'mp4',
            year: year(name), rating: 0, added: vodIdx
          });
        } else {
          var sName = sxe[1].replace(/[\s._\-|:]+$/, '').trim() || name;
          var catId = cat('series', group);
          var sKey = catId + '|' + sName.toLowerCase();
          var s = seriesMap[sKey];
          if (!s) {
            s = seriesMap[sKey] = { id: 's' + U.hash(sKey), name: sName, poster: logo, cat: catId, year: year(sName), rating: 0, added: res.series.items.length + 1, episodes: [] };
            res.series.items.push(s);
          }
          var se = parseInt(sxe[2], 10), ep = parseInt(sxe[3], 10);
          s.episodes.push({
            id: 'e' + U.hash(sKey + '|' + se + '|' + ep + '|' + url), season: se, episode: ep,
            title: (sxe[4] || '').replace(/^[\s\-:|.]+/, '').trim() || F.t('episodeN', { n: ep }),
            url: url, ext: ext(url) || 'mp4', image: logo
          });
        }
        cur = null;
      }
      res.series.items.forEach(function (s) {
        s.episodes.sort(function (a, b) { return a.season - b.season || a.episode - b.episode; });
      });
      return res;
    }
  };
})();
