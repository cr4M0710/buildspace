/* Flimmer – XMLTV-Parser (EPG). Arbeitet mit regulären Ausdrücken statt DOM, damit große Dateien auf dem TV nicht den Speicher sprengen. */
(function () {
  'use strict';
  var U = F.util;

  var ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
  function unesc(s) {
    if (!s) return '';
    s = s.replace(/^\s*<!\[CDATA\[([\s\S]*?)\]\]>\s*$/, '$1');
    return s.replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, function (m, e) {
      if (e[0] === '#') {
        var n = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
        try { return String.fromCharCode(n); } catch (er) { return m; }
      }
      return ENT[e.toLowerCase()] || m;
    }).trim();
  }

  /** "20261024193000 +0200" → ms (UTC) */
  function time(s) {
    var m = /^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})?\s*([+-]\d{2}):?(\d{2})?/.exec(s || '');
    if (!m) return 0;
    var ts = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
    if (m[7]) {
      var sign = m[7][0] === '-' ? -1 : 1;
      var off = (Math.abs(parseInt(m[7], 10)) * 60 + parseInt(m[8] || '0', 10)) * 60000;
      ts -= sign * off;
    }
    return ts;
  }

  function attr(src, name) {
    var m = new RegExp('\\b' + name + '="([^"]*)"').exec(src);
    return m ? unesc(m[1]) : '';
  }
  function tag(src, name) {
    var m = new RegExp('<' + name + '\\b[^>]*>([\\s\\S]*?)</' + name + '>').exec(src);
    return m ? unesc(m[1]) : '';
  }

  F.xmltv = {
    time: time,
    /**
     * want: {epgIdKleingeschrieben: true} oder null (alles)
     * Rückgabe: { map: {id: [prog...]}, names: {normName: id} }
     */
    parse: function (text, want, from, to) {
      var map = {}, names = {};
      var reCh = /<channel\b([^>]*)>([\s\S]*?)<\/channel>/g, m;
      while ((m = reCh.exec(text))) {
        var id = attr(m[1], 'id').toLowerCase();
        var reDn = /<display-name\b[^>]*>([\s\S]*?)<\/display-name>/g, d;
        while ((d = reDn.exec(m[2]))) names[U.norm(unesc(d[1]))] = id;
      }
      if (typeof want === 'function') want = want(names);
      var reP = /<programme\b([^>]*)>([\s\S]*?)<\/programme>/g;
      var count = 0;
      while ((m = reP.exec(text))) {
        var ch = attr(m[1], 'channel').toLowerCase();
        if (want && !want[ch]) continue;
        var start = time(attr(m[1], 'start')), end = time(attr(m[1], 'stop'));
        if (!start) continue;
        if (!end) end = start + 3600000;
        if (end < from || start > to) continue;
        var list = map[ch] || (map[ch] = []);
        list.push({ start: start, end: end, title: tag(m[2], 'title'), desc: tag(m[2], 'desc'), cat: tag(m[2], 'category') });
        count++;
      }
      Object.keys(map).forEach(function (k) { map[k].sort(function (a, b) { return a.start - b.start; }); });
      return { map: map, names: names, count: count };
    }
  };
})();
