/* Flimmer – Demo-Anbieter mit erfundenen Sendern und frei lizenzierten Testvideos.
 * Damit lässt sich die Oberfläche ohne eigenen Anbieter ausprobieren.
 */
(function () {
  'use strict';
  var U = F.util;

  // Öffentliche Test-Streams (Open-Movie-Projekte, Testsignale)
  var LIVE = [
    'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    'https://cph-p2p-msl.akamaized.net/hls/live/2000341/test/master.m3u8',
    'https://test-streams.mux.dev/tos_ismc/main.m3u8',
    'https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_ts/master.m3u8'
  ];
  var GS = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/';
  var VOD = ['BigBuckBunny.mp4', 'ElephantsDream.mp4', 'Sintel.mp4', 'TearsOfSteel.mp4', 'ForBiggerBlazes.mp4',
    'ForBiggerEscapes.mp4', 'ForBiggerFun.mp4', 'ForBiggerJoyrides.mp4', 'ForBiggerMeltdowns.mp4', 'SubaruOutbackOnStreetAndDirt.mp4'];

  var CH = {
    'Nachrichten': ['Tagesaktuell', 'Nordlicht News', 'Weltblick', 'Infokanal', 'Börse Live', 'Tagesecho', 'Report Plus', 'Fokus Politik'],
    'Sport': ['Sportarena 1', 'Sportarena 2', 'Ballkanal', 'Motor TV', 'Tennis Court', 'Hallensport', 'Fight Night', 'Arena Extra'],
    'Unterhaltung': ['Kanal Eins', 'Familie TV', 'Showbühne', 'Comedy Club', 'Serienwelt', 'Kino Kult', 'Abendprogramm', 'Quiz & Spiel', 'Lachkanal', 'Drama Max'],
    'Dokumentation': ['Entdecker', 'Zeitreise', 'Wissen Plus', 'Planet Blau', 'Technik Heute', 'Geschichte HD', 'Reiselust'],
    'Kinder': ['Kinderwelt', 'Kleine Helden', 'Spielplatz TV', 'Junior Plus', 'Trickfilm Box'],
    'Musik': ['Hitwelle TV', 'Klassik Live', 'Rockwerk', 'Jazz Lounge', 'Charts 24'],
    'Regional': ['Regio Nord', 'Regio Süd', 'Stadtkanal', 'Landesblick', 'Heimat TV'],
    'Natur': ['Wildnis', 'Ozean TV', 'Grünes Land', 'Tierwelt'],
    'Erwachsene (18+)': ['Nachtkanal 1', 'Nachtkanal 2']
  };
  var SHOWS = {
    'Nachrichten': ['Nachrichten', 'Guten Morgen', 'Wirtschaft kompakt', 'Wetter', 'Blick in die Welt', 'Interview am Abend', 'Presseschau', 'Im Fokus'],
    'Sport': ['Live: Handball Bundesliga', 'Sport am Mittag', 'Fußball – Highlights', 'Motorsport Magazin', 'Tennis live', 'Sport extra', 'Boxen: Titelkampf'],
    'Unterhaltung': ['Die große Show', 'Familie Brenner', 'Quiz der Städte', 'Comedy-Nacht', 'Spielfilm: Sommerregen', 'Talk um Acht', 'Krimi: Mord am Hafen'],
    'Dokumentation': ['Die Alpen von oben', 'Geheimnisse der Pharaonen', 'Wie funktioniert das?', 'Zeitzeugen', 'Expedition Arktis', 'Große Bauwerke'],
    'Kinder': ['Die kleinen Forscher', 'Abenteuer im Zauberwald', 'Rechnen mit Rudi', 'Tiergeschichten', 'Gute-Nacht-Geschichte'],
    'Musik': ['Top 40', 'Konzert live', 'Unplugged', 'Musikvideos nonstop', 'Klassik am Abend'],
    'Regional': ['Regional aktuell', 'Aus der Region', 'Marktplatz', 'Unterwegs im Land', 'Regionalwetter'],
    'Natur': ['Wilde Wälder', 'Leben im Ozean', 'Die Savanne', 'Vögel Europas', 'Unter Wasser'],
    'Erwachsene (18+)': ['Spätprogramm', 'Nachtfilm']
  };
  var MOVIES = {
    'Action': ['Grenzgänger', 'Stahlregen', 'Der letzte Auftrag', 'Nachtfahrt', 'Codename Falke', 'Feuerlinie', 'Sturmfront', 'Kurs Null'],
    'Komödie': ['Chaos im Kleingarten', 'Urlaub mit Hindernissen', 'Der Hochzeitsplaner', 'Oma zieht ein', 'Drei Männer und ein Dackel', 'Falsch verbunden', 'Das Familienfest'],
    'Drama': ['Stille Wasser', 'Die Brücke am Fluss', 'Zeit der Kraniche', 'Herbstlicht', 'Das letzte Kapitel', 'Zwischen zwei Welten', 'Heimkehr'],
    'Thriller': ['Schatten über Berlin', 'Der Zeuge', 'Kalte Spur', 'Doppelspiel', 'Die Akte Lindner', 'Nebelnacht', 'Lautlos'],
    'Science-Fiction': ['Orbit', 'Die Kolonie', 'Zeitfenster', 'Signal aus dem All', 'Station Helios', 'Neue Erde', 'Quantenfeld'],
    'Familie': ['Das Baumhaus', 'Ferien am Meer', 'Der Drache im Keller', 'Weihnachten bei den Bergers', 'Das Ponyabenteuer', 'Kleine Riesen'],
    'Open Movies': ['Big Buck Bunny', 'Elephants Dream', 'Sintel', 'Tears of Steel']
  };
  var SERIES = {
    'Krimi': ['Hafenwache', 'Kommissarin Lorenz', 'Die Spur', 'Revier 12'],
    'Drama': ['Das Gutshaus', 'Familie Kranz', 'Klinik am Wald', 'Lebenslinien'],
    'Comedy': ['WG Chaos', 'Büro Büro', 'Die Nachbarn', 'Papa allein zu Haus'],
    'Science-Fiction': ['Sternenweg', 'Die letzte Station', 'Parallel'],
    'Dokuserie': ['Wunder der Erde', 'Städte bei Nacht', 'Handwerk mit Herz'],
    'Kinder': ['Die Bücherwürmer', 'Robo & Rita', 'Abenteuer Bauernhof']
  };
  var PLOTS = [
    'Eine packende Geschichte über Mut, Freundschaft und die Frage, was uns wirklich wichtig ist.',
    'Als ein unerwarteter Brief eintrifft, gerät das ruhige Leben der Hauptfigur völlig aus den Fugen.',
    'Mit viel Humor und Herz erzählt – ideal für einen gemütlichen Abend auf dem Sofa.',
    'Ein Wettlauf gegen die Zeit beginnt, bei dem niemandem mehr zu trauen ist.',
    'Bildgewaltig und spannend bis zur letzten Minute.',
    'Eine kleine Gruppe macht sich auf eine Reise, die alles verändern wird.'
  ];

  function rnd(seed) {
    var s = parseInt(U.hash(seed), 36) || 1;
    return function () { s = (s * 1103515245 + 12345) & 0x7fffffff; return s / 0x7fffffff; };
  }

  function Demo(profile) { this.kind = 'demo'; this.p = profile; this.epgCache = {}; }

  Demo.prototype.account = function () {
    return Promise.resolve({ status: 'active', exp: Date.now() + 365 * 86400000, maxCons: 1, activeCons: 0, trial: true, server: 'Demo', demo: true });
  };

  Demo.prototype.loadLibrary = function (progress) {
    var lib = { live: { cats: [], items: [] }, vod: { cats: [], items: [] }, series: { cats: [], items: [] } };
    var n = 0;
    Object.keys(CH).forEach(function (cat, ci) {
      var cid = 'lc' + ci;
      lib.live.cats.push({ id: cid, name: cat });
      CH[cat].forEach(function (name, i) {
        n++;
        lib.live.items.push({
          id: 'l' + n, num: n, name: name, logo: '', cat: cid, epgId: 'demo.' + n, _cat: cat,
          url: LIVE[(n + i) % LIVE.length], archive: ci < 4, archiveDays: ci < 4 ? 3 : 0
        });
      });
    });
    var m = 0;
    Object.keys(MOVIES).forEach(function (cat, ci) {
      var cid = 'vc' + ci;
      lib.vod.cats.push({ id: cid, name: cat });
      MOVIES[cat].forEach(function (name) {
        m++;
        var r = rnd(name);
        lib.vod.items.push({
          id: 'v' + m, name: name, poster: '', cat: cid, ext: 'mp4', url: GS + VOD[m % VOD.length],
          rating: Math.round((5 + r() * 4.5) * 10) / 10, year: String(1995 + Math.floor(r() * 31)), added: m
        });
      });
    });
    var s = 0;
    Object.keys(SERIES).forEach(function (cat, ci) {
      var cid = 'sc' + ci;
      lib.series.cats.push({ id: cid, name: cat });
      SERIES[cat].forEach(function (name) {
        s++;
        var r = rnd(name);
        lib.series.items.push({
          id: 's' + s, name: name, poster: '', cat: cid, rating: Math.round((6 + r() * 3.5) * 10) / 10,
          year: String(2008 + Math.floor(r() * 18)), plot: PLOTS[s % PLOTS.length], added: s
        });
      });
    });
    if (progress) progress(1, 1, 'demo');
    return new Promise(function (res) { setTimeout(function () { res(lib); }, 400); });
  };

  Demo.prototype.liveUrl = function (item) { return item.url; };
  Demo.prototype.altLiveUrl = function () { return null; };
  Demo.prototype.vodUrl = function (item) { return item.url; };
  Demo.prototype.episodeUrl = function (ep) { return ep.url; };

  Demo.prototype.vodInfo = function (item) {
    var r = rnd(item.id + 'i');
    return Promise.resolve({
      title: item.name, poster: item.poster, backdrop: '', plot: PLOTS[Math.floor(r() * PLOTS.length)] + ' ' + PLOTS[Math.floor(r() * PLOTS.length)],
      cast: 'Anna Berger, Tom Keller, Lina Hoffmann', director: 'M. Sommer', genre: (F.lib.catName('vod', item.cat) || ''),
      year: item.year, duration: 5400 + Math.floor(r() * 2400), rating: item.rating, trailer: '', ext: 'mp4'
    });
  };

  Demo.prototype.seriesInfo = function (item) {
    var r = rnd(item.id + 's');
    var seasons = [], nS = 1 + Math.floor(r() * 4), k = 0;
    for (var sn = 1; sn <= nS; sn++) {
      var eps = [], nE = 6 + Math.floor(r() * 5);
      for (var e = 1; e <= nE; e++) {
        k++;
        eps.push({ id: item.id + 'e' + sn + '_' + e, season: sn, episode: e, title: F.t('episodeN', { n: e }) + ' – ' + ['Der Anfang', 'Neue Wege', 'Die Entscheidung', 'Verloren', 'Zurück', 'Wendepunkt', 'Im Nebel', 'Das Fest', 'Spuren', 'Finale'][(e - 1) % 10],
          ext: 'mp4', url: GS + VOD[(k + sn) % VOD.length], duration: 1500 + Math.floor(r() * 1500), plot: PLOTS[(e + sn) % PLOTS.length], image: '' });
      }
      seasons.push({ num: sn, name: F.t('seasonN', { n: sn }), episodes: eps });
    }
    return Promise.resolve({
      info: { title: item.name, poster: '', backdrop: '', plot: item.plot, cast: 'Jonas Weber, Mira Schulz', director: 'K. Albrecht', genre: F.lib.catName('series', item.cat), year: item.year, rating: item.rating },
      seasons: seasons
    });
  };

  /** Erfundenes Programm, für jeden Sender reproduzierbar */
  Demo.prototype.demoEpg = function (item) {
    if (this.epgCache[item.id]) return this.epgCache[item.id];
    var shows = SHOWS[item._cat] || SHOWS['Unterhaltung'];
    var r = rnd(item.id + 'epg');
    var day = 86400000;
    var t0 = new Date(); t0.setHours(0, 0, 0, 0);
    var t = t0.getTime() - 2 * day, end = t0.getTime() + 3 * day;
    var list = [];
    while (t < end) {
      var dur = [30, 45, 60, 60, 90, 120][Math.floor(r() * 6)] * 60000;
      var title = shows[Math.floor(r() * shows.length)];
      list.push({ start: t, end: t + dur, title: title, desc: PLOTS[Math.floor(r() * PLOTS.length)], archive: item.archive });
      t += dur;
    }
    this.epgCache[item.id] = list;
    return list;
  };
  Demo.prototype.shortEpg = function (item) { return Promise.resolve(this.demoEpg(item)); };
  Demo.prototype.xmltvUrl = function () { return ''; };
  Demo.prototype.catchupUrl = function (item) { return item.archive ? GS + VOD[parseInt(item.id.slice(1), 10) % VOD.length] : null; };

  F.DemoProvider = Demo;
})();
