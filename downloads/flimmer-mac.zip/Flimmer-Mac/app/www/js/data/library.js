/* Flimmer – Bibliothek: lädt/cached Listen, wendet Kategorie-Anpassungen, Sperren und Favoriten an */
(function () {
  'use strict';
  var U = F.util, S = F.store;
  var ADULT = /(adult|xxx|18\s*\+|\+\s*18|erotik|erotic|porn|sexy?\b|for adults)/i;
  var REFRESH = { start: 0, '6h': 6, '12h': 12, '24h': 24, manual: Infinity };

  var L = F.lib = {
    provider: null, data: null, account: null, byId: { live: {}, vod: {}, series: {} },
    unlocked: {}, loadedAt: 0,

    /** Profil aktivieren: Cache nutzen, ggf. im Hintergrund aktualisieren */
    activate: function (profile, onStatus) {
      S.setActive(profile.id);
      L.provider = F.providers.create(profile);
      L.unlocked = {};
      L.data = null;
      var key = 'lib:' + profile.id;
      return F.db.get(key).then(function (cached) {
        var maxAge = REFRESH[S.settings.refresh];
        if (maxAge === undefined) maxAge = 24;
        if (cached && cached.data && profile.type !== 'demo') {
          L.use(cached.data, cached.ts);
          var age = (Date.now() - cached.ts) / 3600000;
          if (age >= maxAge) setTimeout(function () { L.refresh(true); }, 1500);
          L.loadAccount();
          return true;
        }
        return L.fetch(onStatus).then(function () { L.loadAccount(); return true; });
      });
    },

    fetch: function (onStatus) {
      var profile = S.profile();
      return L.provider.loadLibrary(function (a, b, what) {
        if (!onStatus) return;
        if (what === 'download') onStatus(F.t('loadingDownload', { mb: (a / 1048576).toFixed(1) }));
        else onStatus(F.t('loadingStep', { a: a, b: b }));
      }).then(function (data) {
        L.use(data, Date.now());
        return F.db.set('lib:' + profile.id, { ts: L.loadedAt, data: data });
      });
    },

    refresh: function (silent) {
      var loader = silent ? null : F.ui.loader(F.t('refreshing'));
      return U.always(L.fetch(loader ? loader.text : null).then(function () {
        if (F.epg) F.epg.reset();
        F.ui.toast(F.t('listsUpdated'));
        if (F.app) F.app.emit('library');
      }, function (e) {
        F.ui.toast(F.t('refreshFailed') + ' (' + F.t('err_' + F.providers.errKind(e)) + ')', 'error');
      }), function () { if (loader) loader.close(); });
    },

    loadAccount: function () {
      return L.provider.account().then(function (a) { L.account = a; if (F.app) F.app.emit('account'); return a; }, function () { return null; });
    },

    use: function (data, ts) {
      L.data = data;
      L.loadedAt = ts || Date.now();
      ['live', 'vod', 'series'].forEach(function (t) {
        var m = {};
        (data[t].items || []).forEach(function (it) { m[it.id] = it; });
        L.byId[t] = m;
        var cm = {};
        (data[t].cats || []).forEach(function (c) { cm[c.id] = c; });
        L.byId[t + 'Cats'] = cm;
      });
      L._counts = {};
    },

    get: function (type, id) { return L.byId[type][String(id)] || null; },

    catName: function (type, catId) {
      var c = L.byId[type + 'Cats'] && L.byId[type + 'Cats'][catId];
      if (!c) return '';
      return S.p.cats[type].names[catId] || c.name;
    },

    isAdultCat: function (type, catId) {
      var c = L.byId[type + 'Cats'] && L.byId[type + 'Cats'][catId];
      return !!(c && ADULT.test(c.name));
    },

    /** Kategorie gesperrt? (nur wenn eine Jugendschutz-PIN gesetzt ist) */
    isLocked: function (type, catId) {
      if (!S.settings.parentalPin) return false;
      if (L.unlocked[type + ':' + catId]) return false;
      var l = S.p.cats[type].locked[catId];
      if (l === true) return true;
      if (l === false) return false;
      return !!(S.settings.autoLockAdult && L.isAdultCat(type, catId));
    },
    lockState: function (type, catId) {
      var l = S.p.cats[type].locked[catId];
      if (l === true || l === false) return l;
      return !!(S.settings.autoLockAdult && L.isAdultCat(type, catId));
    },
    unlock: function (type, catId) {
      if (!L.isLocked(type, catId)) return Promise.resolve(true);
      return F.ui.pin({ title: F.t('parentalTitle'), sub: L.catName(type, catId), check: function (v) { return v === S.settings.parentalPin; } })
        .then(function (v) { if (v) { L.unlocked[type + ':' + catId] = true; return true; } return false; });
    },
    isHidden: function (type, catId) { return !!S.p.cats[type].hidden[catId]; },

    /** Item für "Alle"/Suche sichtbar? */
    visibleItem: function (type, it) { return it && !L.isHidden(type, it.cat) && !L.isLocked(type, it.cat); },

    /** Echte Kategorien in Nutzer-Reihenfolge */
    rawCats: function (type, includeHidden) {
      if (!L.data) return [];
      var cats = L.data[type].cats.slice();
      var order = S.p.cats[type].order || [];
      var pos = {};
      order.forEach(function (id, i) { pos[id] = i; });
      cats.forEach(function (c, i) { c._i = i; });
      cats.sort(function (a, b) {
        var pa = pos.hasOwnProperty(a.id) ? pos[a.id] : 100000 + a._i;
        var pb = pos.hasOwnProperty(b.id) ? pos[b.id] : 100000 + b._i;
        return pa - pb;
      });
      if (!includeHidden) cats = cats.filter(function (c) { return !L.isHidden(type, c.id); });
      return cats;
    },

    counts: function (type) {
      if (L._counts[type]) return L._counts[type];
      var c = {};
      L.data[type].items.forEach(function (it) { c[it.cat] = (c[it.cat] || 0) + 1; });
      L._counts[type] = c;
      return c;
    },

    /** Kategorien inkl. Sonderkategorien für die Seitenleisten */
    cats: function (type) {
      if (!L.data) return [];
      var counts = L.counts(type);
      var out = [
        { id: '__all', name: F.t(type === 'live' ? 'allChannels' : 'all'), special: true, icon: 'list' },
        { id: '__fav', name: F.t('favorites'), special: true, icon: 'star' }
      ];
      if (type === 'live') {
        out.push({ id: '__recent', name: F.t('recentlyWatched'), special: true, icon: 'history' });
        S.p.lists.forEach(function (l) { out.push({ id: '__list:' + l.id, name: l.name, special: true, icon: 'list', userList: true }); });
      } else {
        out.push({ id: '__new', name: F.t('recentlyAdded'), special: true, icon: 'history' });
      }
      L.rawCats(type).forEach(function (c) {
        out.push({ id: c.id, name: L.catName(type, c.id), count: counts[c.id] || 0, locked: L.isLocked(type, c.id), adult: L.lockState(type, c.id) });
      });
      return out;
    },

    /** Einträge einer (Sonder-)Kategorie */
    items: function (type, catId, sort) {
      if (!L.data) return [];
      var all = L.data[type].items, res;
      var self = L;
      function byIds(ids) { return ids.map(function (id) { return self.byId[type][id]; }).filter(function (it) { return it && !L.isLocked(type, it.cat); }); }
      if (catId === '__all') res = all.filter(function (it) { return L.visibleItem(type, it); });
      else if (catId === '__fav') res = byIds(S.p.fav[type]);
      else if (catId === '__recent') res = byIds(S.p.recentLive);
      else if (catId === '__new') res = all.filter(function (it) { return L.visibleItem(type, it); }).slice().sort(function (a, b) { return (b.added || 0) - (a.added || 0); }).slice(0, 300);
      else if (String(catId).indexOf('__list:') === 0) {
        var lid = catId.slice(7), list = null;
        S.p.lists.forEach(function (l) { if (l.id === lid) list = l; });
        res = list ? byIds(list.items) : [];
      } else {
        if (L.isLocked(type, catId)) return [];
        res = all.filter(function (it) { return it.cat === catId; });
      }
      if (type !== 'live' && sort && sort !== 'default' && catId !== '__new') {
        res = res.slice();
        if (sort === 'az') res.sort(function (a, b) { return a.name.localeCompare(b.name); });
        else if (sort === 'za') res.sort(function (a, b) { return b.name.localeCompare(a.name); });
        else if (sort === 'new') res.sort(function (a, b) { return (b.added || 0) - (a.added || 0); });
        else if (sort === 'rating') res.sort(function (a, b) { return (b.rating || 0) - (a.rating || 0); });
        else if (sort === 'year') res.sort(function (a, b) { return (parseInt(b.year, 10) || 0) - (parseInt(a.year, 10) || 0); });
      }
      return res;
    },

    /** Globale Suche */
    search: function (q, type, limit) {
      q = U.norm(q);
      if (!q || !L.data) return [];
      var words = q.split(' ');
      var out = [];
      var types = type && type !== 'all' ? [type] : ['live', 'vod', 'series'];
      types.forEach(function (t) {
        var n = 0, starts = [], rest = [];
        var items = L.data[t].items;
        for (var i = 0; i < items.length && n < (limit || 300); i++) {
          var it = items[i];
          if (!it._n) it._n = U.norm(it.name);
          var ok = true;
          for (var w = 0; w < words.length; w++) if (it._n.indexOf(words[w]) < 0) { ok = false; break; }
          if (!ok || !L.visibleItem(t, it)) continue;
          n++;
          (it._n.indexOf(q) === 0 ? starts : rest).push({ type: t, item: it });
        }
        out = out.concat(starts, rest);
      });
      return out;
    },

    /** Kategorie-Anpassungen */
    setCatOrder: function (type, ids) { S.p.cats[type].order = ids; S.saveP(); },
    toggleHidden: function (type, catId) { var h = S.p.cats[type].hidden; if (h[catId]) delete h[catId]; else h[catId] = true; S.saveP(); },
    renameCat: function (type, catId, name) { if (name) S.p.cats[type].names[catId] = name; else delete S.p.cats[type].names[catId]; S.saveP(); },
    setLocked: function (type, catId, on) { S.p.cats[type].locked[catId] = !!on; S.saveP(); },
    resetCats: function (type) { S.p.cats[type] = { hidden: {}, order: [], names: {}, locked: {} }; S.saveP(); },

    /** Eigene Senderlisten */
    listCreate: function (name) { var l = { id: U.uid(), name: name, items: [] }; S.p.lists.push(l); S.saveP(); return l; },
    listToggle: function (lid, id) {
      id = String(id);
      S.p.lists.forEach(function (l) {
        if (l.id !== lid) return;
        var i = l.items.indexOf(id);
        if (i >= 0) l.items.splice(i, 1); else l.items.push(id);
      });
      S.saveP();
    },
    listDelete: function (lid) { S.p.lists = S.p.lists.filter(function (l) { return l.id !== lid; }); S.saveP(); },
    listRename: function (lid, name) { S.p.lists.forEach(function (l) { if (l.id === lid) l.name = name; }); S.saveP(); },

    /** Stream-URLs */
    liveUrl: function (item) { return L.provider.liveUrl(item); },
    vodUrl: function (item) { return L.provider.vodUrl(item); },
    episodeUrl: function (ep) { return L.provider.episodeUrl(ep); },

    poster: function (it, sub) { return it.poster || U.posterSvg(it.name, sub || it.year); },
    logo: function (it) { return it.logo || U.logoSvg(it.name); }
  };
})();
