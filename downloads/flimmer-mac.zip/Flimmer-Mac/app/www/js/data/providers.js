/* Flimmer – Anbieter-Schnittstellen: Xtream-Codes-API und M3U-Playlist
 * Zugangsdaten gehen ausschließlich an den vom Nutzer eingetragenen Server.
 */
(function () {
  'use strict';
  var U = F.util;
  var P = F.providers = {};

  /** Server-Adresse bereinigen: Protokoll ergänzen, Pfade wie /player_api.php entfernen */
  P.normalizeServer = function (s) {
    s = String(s || '').trim();
    if (!s) return '';
    if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
    s = s.replace(/\/(player_api|get|xmltv)\.php.*$/i, '').replace(/\/c\/?$/i, '').replace(/\/+$/, '');
    return s;
  };

  /** Xtream-Link (get.php?username=…&password=…) automatisch erkennen */
  P.parseXtreamLink = function (url) {
    var m = /^(https?:\/\/[^/?#]+)(?:\/[^?#]*)?\?(.*)$/i.exec(String(url || '').trim());
    if (!m) return null;
    var q = {};
    m[2].split('&').forEach(function (kv) { var p = kv.split('='); q[decodeURIComponent(p[0])] = decodeURIComponent(p[1] || ''); });
    if (q.username && q.password) return { server: m[1], username: q.username, password: q.password };
    return null;
  };

  function errKind(e) {
    if (!e) return 'unknown';
    if (e.kind === 'http' && (e.status === 401 || e.status === 403)) return 'auth';
    if (e.kind === 'http' && e.status === 404) return 'notfound';
    return e.kind || 'unknown';
  }
  P.errKind = errKind;

  /* ---------- Xtream Codes ---------- */
  function Xtream(profile) {
    this.kind = 'xtream';
    this.p = profile;
    this.base = P.normalizeServer(profile.server);
    this.u = encodeURIComponent(profile.username || '');
    this.pw = encodeURIComponent(profile.password || '');
    this.tz = null;
  }
  Xtream.prototype.api = function (action, extra, timeout) {
    var url = this.base + '/player_api.php?username=' + this.u + '&password=' + this.pw + (action ? '&action=' + action : '') + (extra || '');
    return U.json(url, { timeout: timeout || 45000 });
  };
  Xtream.prototype.account = function () {
    var self = this;
    return this.api('', '', 20000).then(function (d) {
      if (!d || !d.user_info) { var e = new Error('format'); e.kind = 'format'; throw e; }
      var ui = d.user_info, si = d.server_info || {};
      if (String(ui.auth) === '0') { var e2 = new Error('auth'); e2.kind = 'auth'; throw e2; }
      self.tz = si.timezone || null;
      var status = String(ui.status || '').toLowerCase();
      return {
        status: status, // active | expired | banned | disabled
        exp: ui.exp_date ? parseInt(ui.exp_date, 10) * 1000 : null,
        created: ui.created_at ? parseInt(ui.created_at, 10) * 1000 : null,
        maxCons: ui.max_connections, activeCons: ui.active_cons,
        trial: String(ui.is_trial) === '1',
        server: si.url ? (si.server_protocol || 'http') + '://' + si.url + (si.port ? ':' + si.port : '') : self.base,
        tz: si.timezone || ''
      };
    });
  };
  Xtream.prototype.loadLibrary = function (progress) {
    var self = this;
    var steps = [
      ['get_live_categories', 'live', 'cats'], ['get_live_streams', 'live', 'items'],
      ['get_vod_categories', 'vod', 'cats'], ['get_vod_streams', 'vod', 'items'],
      ['get_series_categories', 'series', 'cats'], ['get_series', 'series', 'items']
    ];
    var out = { live: { cats: [], items: [] }, vod: { cats: [], items: [] }, series: { cats: [], items: [] } };
    var done = 0;
    return Promise.all(steps.map(function (s) {
      return self.api(s[0], '', 120000).then(function (d) {
        done++;
        if (progress) progress(done, steps.length, s[1]);
        out[s[1]][s[2]] = Array.isArray(d) ? d : [];
      }, function (e) {
        done++;
        if (s[1] === 'live') throw e; // Live ist Pflicht, Filme/Serien optional
        out[s[1]][s[2]] = [];
      });
    })).then(function () {
      var res = { live: {}, vod: {}, series: {} };
      ['live', 'vod', 'series'].forEach(function (t) {
        res[t].cats = out[t].cats.map(function (c) { return { id: String(c.category_id), name: String(c.category_name || '') }; });
      });
      res.live.items = out.live.items.map(function (s, i) {
        return {
          id: String(s.stream_id), num: parseInt(s.num, 10) || i + 1, name: String(s.name || ''), logo: s.stream_icon || '',
          cat: String(s.category_id), epgId: s.epg_channel_id || '',
          archive: String(s.tv_archive) === '1', archiveDays: parseInt(s.tv_archive_duration, 10) || 0,
          adult: String(s.is_adult) === '1'
        };
      });
      res.vod.items = out.vod.items.map(function (s, i) {
        var y = /\((\d{4})\)/.exec(s.name || '');
        return {
          id: String(s.stream_id), name: String(s.name || ''), poster: s.stream_icon || '', cat: String(s.category_id),
          ext: s.container_extension || 'mp4', rating: parseFloat(s.rating) || 0,
          year: s.year || (y ? y[1] : ''), added: parseInt(s.added, 10) || i
        };
      });
      res.series.items = out.series.items.map(function (s, i) {
        return {
          id: String(s.series_id), name: String(s.name || ''), poster: s.cover || '', cat: String(s.category_id),
          rating: parseFloat(s.rating) || 0, year: (s.releaseDate || s.release_date || '').slice(0, 4),
          plot: s.plot || '', genre: s.genre || '', added: parseInt(s.last_modified, 10) || i
        };
      });
      return res;
    });
  };
  Xtream.prototype.liveUrl = function (item, fmt) {
    fmt = fmt || F.store.settings.liveFormat || 'm3u8';
    return this.base + '/live/' + this.u + '/' + this.pw + '/' + item.id + '.' + fmt;
  };
  Xtream.prototype.altLiveUrl = function (item, url) {
    return /\.m3u8$/.test(url) ? this.liveUrl(item, 'ts') : this.liveUrl(item, 'm3u8');
  };
  Xtream.prototype.vodUrl = function (item) { return this.base + '/movie/' + this.u + '/' + this.pw + '/' + item.id + '.' + (item.ext || 'mp4'); };
  Xtream.prototype.episodeUrl = function (ep) { return this.base + '/series/' + this.u + '/' + this.pw + '/' + ep.id + '.' + (ep.ext || 'mp4'); };
  Xtream.prototype.vodInfo = function (item) {
    return this.api('get_vod_info', '&vod_id=' + item.id).then(function (d) {
      var i = (d && d.info) || {};
      var bd = i.backdrop_path; if (Array.isArray(bd)) bd = bd[0];
      return {
        title: i.name || item.name, poster: i.movie_image || i.cover_big || item.poster, backdrop: bd || '',
        plot: i.plot || i.description || '', cast: i.cast || i.actors || '', director: i.director || '',
        genre: i.genre || '', year: (i.releasedate || i.release_date || item.year || '').slice(0, 4),
        duration: parseInt(i.duration_secs, 10) || 0, rating: parseFloat(i.rating) || item.rating || 0,
        trailer: i.youtube_trailer || '',
        ext: (d && d.movie_data && d.movie_data.container_extension) || item.ext
      };
    });
  };
  Xtream.prototype.seriesInfo = function (item) {
    return this.api('get_series_info', '&series_id=' + item.id).then(function (d) {
      d = d || {};
      var i = d.info || {};
      var eps = d.episodes || {};
      var seasonsMap = {};
      function add(e, sKey) {
        var sn = parseInt(e.season || sKey, 10) || 1;
        var s = seasonsMap[sn] || (seasonsMap[sn] = { num: sn, episodes: [] });
        var info = e.info || {};
        s.episodes.push({
          id: String(e.id), season: sn, episode: parseInt(e.episode_num, 10) || s.episodes.length + 1,
          title: e.title || '', ext: e.container_extension || 'mp4', plot: info.plot || '',
          duration: parseInt(info.duration_secs, 10) || 0, image: info.movie_image || ''
        });
      }
      if (Array.isArray(eps)) eps.forEach(function (arr) { (Array.isArray(arr) ? arr : [arr]).forEach(function (e) { add(e); }); });
      else Object.keys(eps).forEach(function (k) { (eps[k] || []).forEach(function (e) { add(e, k); }); });
      var names = {};
      (d.seasons || []).forEach(function (s) { names[s.season_number] = s.name; });
      var seasons = Object.keys(seasonsMap).map(function (k) {
        var s = seasonsMap[k];
        s.name = names[s.num] || '';
        s.episodes.sort(function (a, b) { return a.episode - b.episode; });
        return s;
      }).sort(function (a, b) { return a.num - b.num; });
      var bd = i.backdrop_path; if (Array.isArray(bd)) bd = bd[0];
      return {
        info: {
          title: i.name || item.name, poster: i.cover || item.poster, backdrop: bd || '', plot: i.plot || item.plot || '',
          cast: i.cast || '', director: i.director || '', genre: i.genre || item.genre || '',
          year: (i.releaseDate || i.release_date || item.year || '').slice(0, 4), rating: parseFloat(i.rating) || item.rating || 0,
          trailer: i.youtube_trailer || ''
        },
        seasons: seasons
      };
    });
  };
  Xtream.prototype.shortEpg = function (item) {
    var self = this;
    function norm(list) {
      return (list || []).map(function (p) {
        var s = parseInt(p.start_timestamp, 10) * 1000, e = parseInt(p.stop_timestamp || p.end_timestamp, 10) * 1000;
        if (!s && p.start) s = Date.parse(p.start.replace(' ', 'T'));
        if (!e && p.end) e = Date.parse(p.end.replace(' ', 'T'));
        return { start: s, end: e, title: U.b64(p.title), desc: U.b64(p.description), archive: String(p.has_archive) === '1' };
      }).filter(function (p) { return p.start && p.end; }).sort(function (a, b) { return a.start - b.start; });
    }
    return this.api('get_simple_data_table', '&stream_id=' + item.id, 20000).then(function (d) {
      var l = norm(d && d.epg_listings);
      if (l.length) return l;
      return self.api('get_short_epg', '&stream_id=' + item.id + '&limit=20', 20000).then(function (d2) { return norm(d2 && d2.epg_listings); });
    });
  };
  Xtream.prototype.xmltvUrl = function () { return this.base + '/xmltv.php?username=' + this.u + '&password=' + this.pw; };
  Xtream.prototype.catchupUrl = function (item, prog) {
    if (!item.archive) return null;
    var dur = Math.max(1, Math.round((prog.end - prog.start) / 60000));
    var d = tzParts(prog.start, this.tz);
    var start = d.Y + '-' + d.m + '-' + d.d + ':' + d.H + '-' + d.M;
    return this.base + '/timeshift/' + this.u + '/' + this.pw + '/' + dur + '/' + start + '/' + item.id + '.ts';
  };

  /** Datum in Zeitzone des Servers zerlegen */
  function tzParts(ts, tz) {
    var d = new Date(ts);
    if (tz) {
      try {
        var s = d.toLocaleString('en-US', { timeZone: tz, hour12: false, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
        var m = /(\d+)\/(\d+)\/(\d+),?\s+(\d+):(\d+):(\d+)/.exec(s);
        if (m) return { Y: m[3], m: U.pad2(m[1]), d: U.pad2(m[2]), H: U.pad2(m[4] === '24' ? '00' : m[4]), M: U.pad2(m[5]), S: U.pad2(m[6]) };
      } catch (e) { /* Zeitzone unbekannt */ }
    }
    return { Y: String(d.getFullYear()), m: U.pad2(d.getMonth() + 1), d: U.pad2(d.getDate()), H: U.pad2(d.getHours()), M: U.pad2(d.getMinutes()), S: U.pad2(d.getSeconds()) };
  }

  /* ---------- M3U ---------- */
  function M3U(profile) {
    this.kind = 'm3u';
    this.p = profile;
    this.headerEpg = '';
  }
  M3U.prototype.account = function () {
    return Promise.resolve({ status: 'active', exp: null, server: this.p.url, m3u: true });
  };
  M3U.prototype.loadLibrary = function (progress) {
    var self = this;
    var url = String(this.p.url || '').trim();
    if (!/^https?:\/\//i.test(url)) url = 'http://' + url;
    return U.text(url, {
      timeout: 180000,
      onprogress: function (e) { if (progress) progress(e.loaded, e.total || 0, 'download'); }
    }).then(function (txt) {
      var res = F.m3u.parse(txt);
      self.headerEpg = res.epgUrl;
      res.headerEpg = res.epgUrl;
      return res;
    });
  };
  M3U.prototype.test = function () {
    return this.loadLibrary().then(function (res) {
      if (!res.live.items.length && !res.vod.items.length && !res.series.items.length) { var e = new Error('empty'); e.kind = 'empty'; throw e; }
      return res;
    });
  };
  M3U.prototype.liveUrl = function (item) { return item.url; };
  M3U.prototype.altLiveUrl = function (item, url) {
    if (/\.m3u8(\?|$)/.test(url)) return url.replace(/\.m3u8(\?|$)/, '.ts$1');
    if (/\.ts(\?|$)/.test(url)) return url.replace(/\.ts(\?|$)/, '.m3u8$1');
    return null;
  };
  M3U.prototype.vodUrl = function (item) { return item.url; };
  M3U.prototype.episodeUrl = function (ep) { return ep.url; };
  M3U.prototype.vodInfo = function (item) {
    return Promise.resolve({ title: item.name, poster: item.poster, backdrop: '', plot: '', year: item.year, duration: 0, rating: 0, ext: item.ext });
  };
  M3U.prototype.seriesInfo = function (item) {
    var map = {};
    (item.episodes || []).forEach(function (e) { (map[e.season] || (map[e.season] = { num: e.season, name: '', episodes: [] })).episodes.push(e); });
    return Promise.resolve({
      info: { title: item.name, poster: item.poster, plot: '', year: item.year },
      seasons: Object.keys(map).map(function (k) { return map[k]; }).sort(function (a, b) { return a.num - b.num; })
    });
  };
  M3U.prototype.shortEpg = function () { return Promise.resolve(null); };
  M3U.prototype.xmltvUrl = function () { return this.p.epgUrl || this.headerEpg || (F.lib.data && F.lib.data.headerEpg) || ''; };
  M3U.prototype.catchupUrl = function (item, prog) {
    if (!item.archive) return null;
    var s = Math.floor(prog.start / 1000), e = Math.floor(prog.end / 1000), now = Math.floor(Date.now() / 1000);
    var d = tzParts(prog.start, null), dur = e - s;
    function fill(tpl) {
      return tpl.replace(/\$?\{(utc|start|timestamp)\}/g, s).replace(/\$?\{(utcend|end)\}/g, e)
        .replace(/\$?\{(lutc|now)\}/g, now).replace(/\$?\{duration\}/g, dur).replace(/\$?\{offset\}/g, now - s)
        .replace(/\{Y\}/g, d.Y).replace(/\{m\}/g, d.m).replace(/\{d\}/g, d.d).replace(/\{H\}/g, d.H).replace(/\{M\}/g, d.M).replace(/\{S\}/g, d.S)
        .replace(/\{\(b\)yyyy\}/g, d.Y).replace(/\{\(b\)MM\}/g, d.m).replace(/\{\(b\)dd\}/g, d.d).replace(/\{\(b\)HH\}/g, d.H).replace(/\{\(b\)mm\}/g, d.M);
    }
    var type = (item.catchupType || '').toLowerCase();
    if (type === 'append' && item.catchupSrc) return item.url + fill(item.catchupSrc);
    if ((type === 'default' || !type) && item.catchupSrc) return fill(item.catchupSrc);
    if (type === 'flussonic' || type === 'fs' || type === 'flussonic-hls') {
      return item.url.replace(/\/(index|playlist|mono|video)(\.m3u8|\.ts)/, '/$1-' + s + '-' + dur + '$2');
    }
    // shift / timeshift: Parameter anhängen
    return item.url + (item.url.indexOf('?') >= 0 ? '&' : '?') + 'utc=' + s + '&lutc=' + now;
  };

  P.create = function (profile) {
    if (profile.type === 'demo') return new F.DemoProvider(profile);
    if (profile.type === 'm3u') return new M3U(profile);
    return new Xtream(profile);
  };
  P.Xtream = Xtream;
  P.M3U = M3U;
})();
