/* Flimmer – IndexedDB-Cache für große Listen (Playlists, EPG). Fällt auf Arbeitsspeicher zurück. */
(function () {
  'use strict';
  var mem = {};
  var dbp = null;

  function open() {
    if (dbp) return dbp;
    dbp = new Promise(function (resolve) {
      try {
        if (!window.indexedDB) return resolve(null);
        var req = indexedDB.open('flimmer', 1);
        req.onupgradeneeded = function () { req.result.createObjectStore('kv'); };
        req.onsuccess = function () { resolve(req.result); };
        req.onerror = function () { resolve(null); };
        req.onblocked = function () { resolve(null); };
      } catch (e) { resolve(null); }
    });
    return dbp;
  }

  function tx(mode, fn) {
    return open().then(function (db) {
      if (!db) return null;
      return new Promise(function (resolve) {
        try {
          var t = db.transaction('kv', mode);
          var store = t.objectStore('kv');
          var req = fn(store);
          t.oncomplete = function () { resolve(req ? req.result : null); };
          t.onerror = function () { resolve(null); };
          t.onabort = function () { resolve(null); };
        } catch (e) { resolve(null); }
      });
    });
  }

  F.db = {
    get: function (k) {
      if (mem.hasOwnProperty(k)) return Promise.resolve(mem[k]);
      return tx('readonly', function (s) { return s.get(k); }).then(function (v) { return v === undefined ? null : v; });
    },
    set: function (k, v) {
      return tx('readwrite', function (s) { return s.put(v, k); }).then(function (r) {
        if (r === null) mem[k] = v; // IndexedDB nicht verfügbar
        return true;
      });
    },
    del: function (k) { delete mem[k]; return tx('readwrite', function (s) { return s.delete(k); }); },
    clear: function () { mem = {}; return tx('readwrite', function (s) { return s.clear(); }); }
  };
})();
