/* Flimmer – Dialoge, PIN-Eingabe, Hinweise, Toasts */
(function () {
  'use strict';
  var U = F.util, h = U.h, t = function (k, v) { return F.t(k, v); };

  var UI = F.ui = {};

  UI.toast = function (msg, kind) {
    var box = document.getElementById('toasts');
    var el = h('div', { 'class': 'toast ' + (kind || '') }, msg);
    box.appendChild(el);
    setTimeout(function () { el.classList.add('show'); }, 20);
    setTimeout(function () { el.classList.remove('show'); setTimeout(function () { if (el.parentNode) box.removeChild(el); }, 400); }, 3200);
  };

  /** Hinweisleiste: [['red','Favorit'],['ok','Abspielen']] */
  UI.hints = function (items) {
    return h('div', { 'class': 'hints' }, items.filter(Boolean).map(function (it) {
      return h('span', { 'class': 'hint' }, [h('i', { 'class': 'key key-' + it[0] }, U.keyLabel(it[0])), it[1]]);
    }));
  };

  /** Basis-Dialog */
  UI.modal = function (opts) {
    var host = document.getElementById('modals');
    var back = h('div', { 'class': 'modal-back' });
    var box = h('div', { 'class': 'modal ' + (opts.cls || '') });
    if (opts.title) box.appendChild(h('div', { 'class': 'modal-title' }, opts.title));
    if (opts.sub) box.appendChild(h('div', { 'class': 'modal-sub' }, opts.sub));
    var body = h('div', { 'class': 'modal-body' });
    box.appendChild(body);
    back.appendChild(box);
    host.appendChild(back);
    var closed = false;
    var m = {
      el: box, body: body,
      close: function (val) {
        if (closed) return;
        closed = true;
        if (back.parentNode) host.removeChild(back);
        F.nav.pop(layer);
        if (opts.onClose) opts.onClose(val);
      }
    };
    var layer = F.nav.push({
      root: box,
      name: 'modal',
      onKey: function (k, e) { return opts.onKey ? opts.onKey(k, e, m) : false; },
      onBack: function () { m.close(undefined); }
    });
    m.layer = layer;
    back.addEventListener('click', function (e) { if (e.target === back) m.close(undefined); });
    return m;
  };

  /** Auswahlliste */
  UI.select = function (opts) {
    return new Promise(function (resolve) {
      var m = UI.modal({ title: opts.title, sub: opts.sub, cls: 'modal-select', onClose: resolve });
      var list = h('div', { 'class': 'select-list' });
      var focusEl = null;
      opts.options.forEach(function (o) {
        if (o.sep) { list.appendChild(h('div', { 'class': 'select-sep' }, o.label || '')); return; }
        var sel = o.checked || (opts.current !== undefined && o.value === opts.current);
        var it = U.btn('select-item' + (sel ? ' checked' : ''), {
          onclick: function () { m.close(o.value); }
        }, [
          o.color ? h('span', { 'class': 'swatch', style: 'background:' + o.color }) : null,
          h('span', { 'class': 'select-label' }, o.label),
          o.sub ? h('span', { 'class': 'select-subl' }, o.sub) : null,
          sel ? U.icon('check', 'select-check') : null
        ]);
        if (sel && !focusEl) focusEl = it;
        list.appendChild(it);
      });
      m.body.appendChild(list);
      setTimeout(function () {
        if (focusEl) F.nav.focus(focusEl); else F.nav.focusFirst(m.el);
        if (focusEl) U.reveal(focusEl, true);
      }, 0);
    });
  };

  UI.confirm = function (opts) {
    return new Promise(function (resolve) {
      var m = UI.modal({ title: opts.title, cls: 'modal-confirm', onClose: function (v) { resolve(!!v); } });
      if (opts.text) m.body.appendChild(h('p', { 'class': 'modal-text' }, opts.text));
      var row = h('div', { 'class': 'modal-buttons' }, [
        U.btn('button' + (opts.danger ? ' danger' : ' primary'), { onclick: function () { m.close(true); } }, opts.ok || t('ok')),
        U.btn('button', { onclick: function () { m.close(false); } }, opts.cancel || t('cancel'))
      ]);
      m.body.appendChild(row);
      setTimeout(function () { F.nav.focus(row.children[opts.focusCancel ? 1 : 0]); }, 0);
    });
  };

  UI.prompt = function (opts) {
    return new Promise(function (resolve) {
      var m = UI.modal({ title: opts.title, sub: opts.sub, cls: 'modal-prompt', onClose: resolve });
      var input = h('input', { 'class': 'focusable input', type: opts.password ? 'password' : 'text', value: opts.value || '', placeholder: opts.placeholder || '', tabindex: '-1', spellcheck: 'false', autocomplete: 'off' });
      if (opts.multiline) input = h('textarea', { 'class': 'focusable input textarea', placeholder: opts.placeholder || '', tabindex: '-1', spellcheck: 'false' }, opts.value || '');
      input._onEnter = function () { if (!opts.multiline) m.close(input.value); };
      m.body.appendChild(input);
      m.body.appendChild(h('div', { 'class': 'modal-buttons' }, [
        U.btn('button primary', { onclick: function () { m.close(input.value); } }, t('ok')),
        U.btn('button', { onclick: function () { m.close(null); } }, t('cancel'))
      ]));
      setTimeout(function () { F.nav.focus(input); }, 0);
    });
  };

  UI.info = function (opts) {
    return new Promise(function (resolve) {
      var m = UI.modal({ title: opts.title, cls: 'modal-info ' + (opts.cls || ''), onClose: resolve });
      if (opts.el) m.body.appendChild(opts.el);
      if (opts.text) m.body.appendChild(h('p', { 'class': 'modal-text' }, opts.text));
      var btns = h('div', { 'class': 'modal-buttons' }, (opts.buttons || []).map(function (b) {
        return U.btn('button' + (b.primary ? ' primary' : ''), { onclick: function () { m.close(b.value); } }, b.label);
      }).concat([U.btn('button', { onclick: function () { m.close(null); } }, opts.closeLabel || t('close'))]));
      m.body.appendChild(btns);
      setTimeout(function () { F.nav.focus(btns.children[0]); }, 0);
    });
  };

  /** PIN-Eingabe (Zifferntasten der Fernbedienung oder Ziffernfeld) */
  UI.pin = function (opts) {
    opts = opts || {};
    var len = opts.length || 4;
    return new Promise(function (resolve) {
      var val = '';
      var dots = h('div', { 'class': 'pin-dots' });
      var err = h('div', { 'class': 'pin-error' }, '');
      function draw() {
        U.empty(dots);
        for (var i = 0; i < len; i++) dots.appendChild(h('span', { 'class': 'pin-dot' + (i < val.length ? ' on' : '') }));
      }
      function add(d) {
        if (val.length >= len) return;
        val += d; draw();
        if (val.length === len) setTimeout(submit, 150);
      }
      function submit() {
        if (val.length < len) return;
        if (opts.check && !opts.check(val)) {
          err.textContent = t('pinWrong');
          dots.classList.add('shake');
          setTimeout(function () { dots.classList.remove('shake'); }, 400);
          val = ''; draw();
          return;
        }
        m.close(val);
      }
      var m = UI.modal({
        title: opts.title || t('pinEnter'), sub: opts.sub, cls: 'modal-pin',
        onClose: function (v) { resolve(v === undefined ? null : v); },
        onKey: function (k) {
          if (/^[0-9]$/.test(k)) { add(k); return true; }
          if (k === 'BACK' && val.length) { val = val.slice(0, -1); draw(); return true; }
          if (k === 'BACK' && opts.required) return true;
          return false;
        }
      });
      draw();
      m.body.appendChild(dots);
      m.body.appendChild(err);
      var pad = h('div', { 'class': 'pin-pad' });
      ['1', '2', '3', '4', '5', '6', '7', '8', '9', '⌫', '0', 'OK'].forEach(function (d) {
        pad.appendChild(U.btn('pin-key' + (d === 'OK' ? ' ok' : ''), {
          onclick: function () {
            if (d === '⌫') { val = val.slice(0, -1); draw(); }
            else if (d === 'OK') submit();
            else add(d);
          }
        }, d));
      });
      m.body.appendChild(pad);
      setTimeout(function () { F.nav.focus(pad.children[4]); }, 0);
    });
  };

  /** Neue PIN zweimal abfragen */
  UI.newPin = function (title) {
    return UI.pin({ title: title, sub: t('pinNew') }).then(function (p1) {
      if (!p1) return null;
      return UI.pin({ title: title, sub: t('pinRepeat') }).then(function (p2) {
        if (p2 === null) return null;
        if (p1 !== p2) { UI.toast(t('pinMismatch'), 'error'); return null; }
        return p1;
      });
    });
  };

  /** Ladeanzeige über dem gesamten Bildschirm */
  UI.loader = function (text) {
    var host = document.getElementById('modals');
    var lbl = h('div', { 'class': 'loader-text' }, text || '');
    var el = h('div', { 'class': 'loader-screen' }, [h('div', { 'class': 'spinner' }), lbl]);
    host.appendChild(el);
    var layer = F.nav.push({ root: el, name: 'loader', onKey: function () { return true; } });
    return {
      text: function (s) { lbl.textContent = s; },
      close: function () { if (el.parentNode) host.removeChild(el); F.nav.pop(layer); }
    };
  };
})();
