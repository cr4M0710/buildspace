/* Flimmer – Fernbedienungs-Navigation (räumlich), Ebenen-Stapel, Magic-Remote-Unterstützung */
(function () {
  'use strict';
  var U = F.util;

  var CODES = {
    37: 'LEFT', 38: 'UP', 39: 'RIGHT', 40: 'DOWN', 13: 'ENTER',
    461: 'BACK', 27: 'BACK', 10009: 'BACK',
    403: 'RED', 404: 'GREEN', 405: 'YELLOW', 406: 'BLUE',
    33: 'CH_UP', 34: 'CH_DOWN', 427: 'CH_UP', 428: 'CH_DOWN',
    415: 'PLAY', 19: 'PAUSE', 413: 'STOP', 417: 'FF', 412: 'RW', 10252: 'PLAYPAUSE',
    457: 'INFO'
  };
  // Tastatur-Ersatz für die Browser-Demo (nur außerhalb von Eingabefeldern)
  var DESKTOP = { 82: 'RED', 71: 'GREEN', 89: 'YELLOW', 66: 'BLUE', 73: 'INFO', 32: 'PLAYPAUSE', 219: 'RW', 221: 'FF', 8: 'BACK', 83: 'STOP' };

  function isInput(el) { return el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT'); }

  function keyName(e) {
    var c = e.keyCode;
    var inInput = isInput(document.activeElement);
    if (CODES[c]) return CODES[c];
    if (!inInput) {
      if (c >= 48 && c <= 57) return String(c - 48);
      if (c >= 96 && c <= 105) return String(c - 96);
      if (DESKTOP[c] && !e.ctrlKey && !e.metaKey && !e.altKey) return DESKTOP[c];
    }
    return null;
  }

  var N = F.nav = {
    layers: [],
    grids: {},
    lastKeyTs: 0,
    pointer: false,

    push: function (layer) {
      N.layers.push(layer);
      return layer;
    },
    pop: function (layer) {
      var i = N.layers.indexOf(layer);
      if (i >= 0) N.layers.splice(i, 1);
      var top = N.top();
      if (top) N.restore(top);
    },
    top: function () { return N.layers[N.layers.length - 1] || null; },

    restore: function (layer) {
      layer = layer || N.top();
      if (!layer) return;
      if (layer.last && document.body.contains(layer.last) && visible(layer.last)) N.focus(layer.last, { noScroll: true });
      else if (layer.focusDefault) layer.focusDefault();
      else N.focusFirst(layer.root);
    },

    focus: function (el, opts) {
      if (!el) return;
      opts = opts || {};
      var g = el.closest && el.closest('[data-vgrid]');
      if (g && N.grids[g.getAttribute('data-vgrid')] && el.hasAttribute('data-i') && !opts.fromGrid) {
        N.grids[g.getAttribute('data-vgrid')].setIndex(parseInt(el.getAttribute('data-i'), 10), true);
        return;
      }
      try { el.focus(); } catch (e) { /* */ }
      if (!opts.noScroll) U.reveal(el);
    },

    focusFirst: function (root) {
      root = root || (N.top() && N.top().root) || document.body;
      var g = root.querySelector('[data-vgrid]');
      var first = root.querySelector('.focusable.default-focus') || root.querySelector('.focusable');
      if (g && first && g.contains(first) && N.grids[g.getAttribute('data-vgrid')]) { N.grids[g.getAttribute('data-vgrid')].focus(); return; }
      if (first) N.focus(first);
    },

    /** Räumliche Navigation: nächstes fokussierbares Element in Richtung dir */
    move: function (dir, from) {
      var layer = N.top();
      var root = layer ? layer.root : document.body;
      var cur = from || document.activeElement;
      if (!cur || !root.contains(cur) || !cur.classList.contains('focusable')) { N.focusFirst(root); return true; }
      var r = cur.getBoundingClientRect();
      var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      var best = null, bestScore = Infinity;
      var curGrid = cur.closest('[data-vgrid]');
      var list = root.querySelectorAll('.focusable');
      for (var i = 0; i < list.length; i++) {
        var c = list[i];
        if (c === cur || c.hasAttribute('disabled') || !visible(c)) continue;
        if (c.closest('.nav-skip')) continue;
        var rc = c.getBoundingClientRect();
        var ccx = rc.left + rc.width / 2, ccy = rc.top + rc.height / 2;
        var primary, secondary, overlap;
        if (dir === 'RIGHT') { if (rc.left < r.right - 4 && ccx <= cx + 1) continue; if (ccx <= cx) continue; primary = Math.max(0, rc.left - r.right); overlap = rc.top < r.bottom && rc.bottom > r.top; secondary = overlap ? 0 : Math.abs(ccy - cy); }
        else if (dir === 'LEFT') { if (rc.right > r.left + 4 && ccx >= cx - 1) continue; if (ccx >= cx) continue; primary = Math.max(0, r.left - rc.right); overlap = rc.top < r.bottom && rc.bottom > r.top; secondary = overlap ? 0 : Math.abs(ccy - cy); }
        else if (dir === 'DOWN') { if (rc.top < r.bottom - 4 && ccy <= cy + 1) continue; if (ccy <= cy) continue; primary = Math.max(0, rc.top - r.bottom); overlap = rc.left < r.right && rc.right > r.left; secondary = overlap ? Math.abs(ccx - cx) * 0.1 : Math.abs(ccx - cx); }
        else { if (rc.bottom > r.top + 4 && ccy >= cy - 1) continue; if (ccy >= cy) continue; primary = Math.max(0, r.top - rc.bottom); overlap = rc.left < r.right && rc.right > r.left; secondary = overlap ? Math.abs(ccx - cx) * 0.1 : Math.abs(ccx - cx); }
        var score = primary + secondary * 2.5;
        if (score < bestScore) { bestScore = score; best = c; }
      }
      if (!best) return false;
      // In eine virtuelle Liste hinein → dort zur gemerkten Position springen
      var g = best.closest('[data-vgrid]');
      if (g && g !== curGrid && N.grids[g.getAttribute('data-vgrid')]) { N.grids[g.getAttribute('data-vgrid')].focus(); return true; }
      // Gruppe mit gemerktem Element
      var grp = best.closest('[data-group]');
      if (grp && !grp.contains(cur) && grp._last && grp.contains(grp._last) && visible(grp._last)) best = grp._last;
      N.focus(best);
      return true;
    },

    dispatch: function (e) {
      var k = keyName(e);
      if (!k) return;
      var active = document.activeElement;
      var inInput = isInput(active);

      // Eingabefelder: Cursor links/rechts innerhalb des Texts lassen
      if (inInput && (k === 'LEFT' || k === 'RIGHT')) {
        var v = active.value || '', s = active.selectionStart, en = active.selectionEnd;
        var atEdge = (k === 'LEFT' && s === 0 && en === 0) || (k === 'RIGHT' && s === v.length);
        if (!atEdge) return;
      }
      if (inInput && k === 'ENTER') {
        if (active._onEnter) { e.preventDefault(); active._onEnter(); }
        return;
      }

      // Tastenwiederholung drosseln
      var now = Date.now();
      if (e.repeat && now - N.lastKeyTs < 55) { e.preventDefault(); return; }
      N.lastKeyTs = now;
      N.pointer = false;

      var layer = N.top();
      if (layer && layer.onKey && layer.onKey(k, e) === true) { e.preventDefault(); return; }

      // Komponenten (virtuelle Listen)
      var gEl = active && active.closest && active.closest('[data-vgrid]');
      if (gEl) {
        var grid = N.grids[gEl.getAttribute('data-vgrid')];
        if (grid && grid.onKey(k) === true) { e.preventDefault(); return; }
      }

      if (k === 'UP' || k === 'DOWN' || k === 'LEFT' || k === 'RIGHT') {
        e.preventDefault();
        if (N.move(k, active) && inInput && document.activeElement === active) active.blur();
        return;
      }
      if (k === 'ENTER') {
        e.preventDefault();
        if (active && active.classList.contains('focusable')) active.click();
        return;
      }
      if (k === 'BACK') {
        e.preventDefault();
        if (layer && layer.onBack) layer.onBack();
        else if (F.app) F.app.back();
      }
    }
  };

  function visible(el) {
    if (!el.offsetParent && el.style.position !== 'fixed') return false;
    var r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }
  N.visible = visible;

  document.addEventListener('keydown', N.dispatch, true);

  // Fokus in Gruppen merken
  document.addEventListener('focusin', function (e) {
    var el = e.target;
    var layer = N.top();
    if (layer && layer.root && layer.root.contains(el)) layer.last = el;
    var grp = el.closest && el.closest('[data-group]');
    if (grp) grp._last = el;
  });

  // Magic Remote / Maus: Zeiger fokussiert
  document.addEventListener('mouseover', function (e) {
    var el = e.target.closest && e.target.closest('.focusable');
    if (!el || el === document.activeElement) return;
    var layer = N.top();
    if (layer && layer.root && !layer.root.contains(el)) return;
    N.pointer = true;
    if (isInput(document.activeElement)) return;
    var g = el.closest('[data-vgrid]');
    if (g && N.grids[g.getAttribute('data-vgrid')] && el.hasAttribute('data-i')) {
      N.grids[g.getAttribute('data-vgrid')].setIndex(parseInt(el.getAttribute('data-i'), 10), true, true);
    } else {
      try { el.focus(); } catch (err) { /* */ }
    }
  });

  // Maus: Rechtsklick oder seitliche Zurück-Taste = Zurück
  function mouseBack(e) {
    e.preventDefault();
    var layer = N.top();
    if (layer && layer.onBack) layer.onBack(); else if (F.app) F.app.back();
  }
  document.addEventListener('contextmenu', mouseBack);
  document.addEventListener('mouseup', function (e) { if (e.button === 3) mouseBack(e); });

  // webOS: App wird verdeckt / wieder sichtbar
  document.addEventListener('visibilitychange', function () {
    if (F.player && document.hidden) F.player.onAppHidden();
  });
})();
