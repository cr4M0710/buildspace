/* Flimmer – lokale Speicherung (nur auf diesem Gerät, keine fremden Server) */
(function () {
  'use strict';
  var KEY = 'flimmer.';

  var DEFAULTS = {
    theme: 'dark', accent: 'amber', fontSize: 'm', uiScale: 100, animations: true,
    lang: 'de', clock: '24h', start: 'home', refresh: '24h',
    liveLayout: 'list', showLogos: true, showNumbers: true, preview: true, previewAuto: false,
    epgOffset: 0, liveFormat: 'm3u8', epgSource: 'auto',
    tileSize: 'm', sort: 'default', autoNext: true, nextCountdown: 10,
    engine: 'auto', buffer: 'normal', aspect: 'auto', seekStep: 10, osdTime: 5,
    appPin: '', parentalPin: '', autoLockAdult: true
  };

  function read(k, def) {
    try {
      var v = localStorage.getItem(KEY + k);
      return v === null ? def : JSON.parse(v);
    } catch (e) { return def; }
  }
  function write(k, v) {
    try { localStorage.setItem(KEY + k, JSON.stringify(v)); return true; } catch (e) { return false; }
  }
  function del(k) { try { localStorage.removeItem(KEY + k); } catch (e) { /* */ } }

  function emptyProfileData() {
    function cats() { return { hidden: {}, order: [], names: {}, locked: {} }; }
    return {
      fav: { live: [], vod: [], series: [] },
      lists: [],            // eigene Senderlisten [{id,name,items:[]}]
      recentLive: [],       // zuletzt gesehene Sender (IDs)
      progress: {},         // Weiterschauen: key → {pos,dur,ts,meta}
      watched: {},          // gesehene Episoden/Filme
      cats: { live: cats(), vod: cats(), series: cats() },
      searches: [],
      lastChannel: null,
      catSort: {}
    };
  }

  var S = F.store = {
    DEFAULTS: DEFAULTS,
    settings: Object.assign({}, DEFAULTS, read('settings', {})),
    profiles: read('profiles', []),
    activeId: read('active', null),
    p: emptyProfileData(),

    saveSettings: function () { write('settings', S.settings); },
    set: function (k, v) { S.settings[k] = v; S.saveSettings(); },
    saveProfiles: function () { write('profiles', S.profiles); write('active', S.activeId); },

    profile: function () {
      for (var i = 0; i < S.profiles.length; i++) if (S.profiles[i].id === S.activeId) return S.profiles[i];
      return null;
    },
    setActive: function (id) {
      S.activeId = id;
      S.saveProfiles();
      var d = read('p.' + id, null);
      S.p = Object.assign(emptyProfileData(), d || {});
      ['live', 'vod', 'series'].forEach(function (t) {
        S.p.cats[t] = Object.assign({ hidden: {}, order: [], names: {}, locked: {} }, S.p.cats[t] || {});
        S.p.fav[t] = S.p.fav[t] || [];
      });
    },
    saveP: function () { if (S.activeId) write('p.' + S.activeId, S.p); },

    upsertProfile: function (prof) {
      var found = false;
      S.profiles = S.profiles.map(function (p) { if (p.id === prof.id) { found = true; return prof; } return p; });
      if (!found) S.profiles.push(prof);
      S.saveProfiles();
    },
    removeProfile: function (id) {
      S.profiles = S.profiles.filter(function (p) { return p.id !== id; });
      del('p.' + id);
      if (S.activeId === id) S.activeId = null;
      S.saveProfiles();
      if (F.db) F.db.del('lib:' + id);
      if (F.db) F.db.del('xmltv:' + id);
    },

    /* Favoriten */
    isFav: function (type, id) { return S.p.fav[type].indexOf(String(id)) >= 0; },
    toggleFav: function (type, id) {
      id = String(id);
      var list = S.p.fav[type], i = list.indexOf(id);
      if (i >= 0) list.splice(i, 1); else list.unshift(id);
      S.saveP();
      return i < 0;
    },

    /* Zuletzt gesehen */
    pushRecentLive: function (id) {
      id = String(id);
      var r = S.p.recentLive.filter(function (x) { return x !== id; });
      r.unshift(id);
      S.p.recentLive = r.slice(0, 40);
      S.p.lastChannel = id;
      S.saveP();
    },

    /* Weiterschauen */
    setProgress: function (key, pos, dur, meta) {
      if (!key) return;
      if (dur > 0 && pos / dur > 0.95) {
        delete S.p.progress[key];
        S.p.watched[key] = Date.now();
      } else if (pos > 15) {
        S.p.progress[key] = { pos: pos, dur: dur, ts: Date.now(), meta: meta || (S.p.progress[key] && S.p.progress[key].meta) || {} };
      }
      S.saveP();
    },
    getProgress: function (key) { return S.p.progress[key] || null; },
    continueList: function () {
      return Object.keys(S.p.progress).map(function (k) { var o = S.p.progress[k]; o.key = k; return o; })
        .sort(function (a, b) { return b.ts - a.ts; }).slice(0, 30);
    },
    setWatched: function (key, on) {
      if (on) { S.p.watched[key] = Date.now(); delete S.p.progress[key]; } else delete S.p.watched[key];
      S.saveP();
    },
    isWatched: function (key) { return !!S.p.watched[key]; },

    /* Export / Import */
    exportCode: function (withCredentials) {
      var data = { v: 1, settings: S.settings, profiles: [] };
      S.profiles.forEach(function (p) {
        var c = Object.assign({}, p);
        if (!withCredentials) { delete c.password; }
        data.profiles.push({ profile: c, data: read('p.' + p.id, null) });
      });
      if (!withCredentials) { data.settings = Object.assign({}, data.settings, { appPin: '', parentalPin: '' }); }
      return btoa(unescape(encodeURIComponent(JSON.stringify(data))));
    },
    importCode: function (code) {
      var data = JSON.parse(decodeURIComponent(escape(atob(String(code).replace(/\s+/g, '')))));
      if (!data || data.v !== 1) throw new Error('format');
      var keepPins = { appPin: S.settings.appPin, parentalPin: S.settings.parentalPin };
      S.settings = Object.assign({}, DEFAULTS, data.settings || {});
      if (!S.settings.appPin) S.settings.appPin = keepPins.appPin;
      if (!S.settings.parentalPin) S.settings.parentalPin = keepPins.parentalPin;
      S.saveSettings();
      (data.profiles || []).forEach(function (e) {
        var existing = null;
        S.profiles.forEach(function (p) { if (p.id === e.profile.id) existing = p; });
        var prof = Object.assign({}, existing || {}, e.profile);
        if (!e.profile.password && existing) prof.password = existing.password;
        S.upsertProfile(prof);
        if (e.data) write('p.' + prof.id, e.data);
      });
      if (S.activeId) S.setActive(S.activeId);
    },

    /** Alles löschen (Abmelden & Daten löschen) */
    wipe: function () {
      try {
        Object.keys(localStorage).forEach(function (k) { if (k.indexOf(KEY) === 0) localStorage.removeItem(k); });
      } catch (e) { /* */ }
      S.settings = Object.assign({}, DEFAULTS);
      S.profiles = [];
      S.activeId = null;
      S.p = emptyProfileData();
      if (F.db) return F.db.clear();
      return Promise.resolve();
    }
  };
})();
