/* Flimmer – virtuelle Liste / Raster: rendert nur sichtbare Zeilen (flüssig auch bei 50.000 Einträgen) */
(function () {
  'use strict';
  var U = F.util, h = U.h;
  var seq = 0;

  function VGrid(o) {
    var self = this;
    this.id = 'g' + (++seq);
    this.el = o.container;
    this.el.setAttribute('data-vgrid', this.id);
    this.el.classList.add('vgrid');
    this.inner = h('div', { 'class': 'vgrid-inner' });
    this.el.appendChild(this.inner);
    this.cols = o.cols || 1;
    this.rowRem = o.rowRem || 5;
    this.count = o.count || 0;
    this.render = o.render;
    this.onSelect = o.onSelect || function () {};
    this.onFocus = o.onFocus || function () {};
    this.onEdge = o.onEdge || null;
    this.index = 0;
    this.items = {};
    this.margin = o.margin === undefined ? 1 : o.margin;
    F.nav.grids[this.id] = this;

    this.el.addEventListener('wheel', function (e) {
      e.preventDefault();
      self.el.scrollTop += (e.deltaY > 0 ? 1 : -1) * self.rowH * (self.cols > 1 ? 1 : 2);
      self.renderWindow();
    });
    this.layout();
  }

  VGrid.prototype.layout = function () {
    this.rowH = Math.max(10, this.rowRem * U.rem());
    var rows = Math.ceil(this.count / this.cols);
    this.inner.style.height = (rows * this.rowH) + 'px';
    this.colW = (this.el.clientWidth || 1) / this.cols;
  };

  VGrid.prototype.setCount = function (n, keepIndex) {
    this.count = n;
    if (!keepIndex) { this.index = 0; this.el.scrollTop = 0; }
    this.index = U.clamp(this.index, 0, Math.max(0, n - 1));
    this.refresh();
  };

  VGrid.prototype.setCols = function (c) { this.cols = c; this.refresh(); };

  VGrid.prototype.refresh = function () {
    var hadFocus = this.el.contains(document.activeElement);
    var self = this;
    Object.keys(this.items).forEach(function (k) { self.inner.removeChild(self.items[k]); });
    this.items = {};
    this.layout();
    this.ensureVisible(this.index);
    this.renderWindow();
    if (hadFocus) this.focus();
  };

  /** Einzelne Zelle neu zeichnen (z. B. Favoriten-Stern) */
  VGrid.prototype.update = function (i) {
    var old = this.items[i];
    if (!old) return;
    var hadFocus = old === document.activeElement;
    this.inner.removeChild(old);
    delete this.items[i];
    this.renderWindow();
    if (hadFocus) this.focus();
  };

  VGrid.prototype.renderWindow = function () {
    if (!this.count) { this.inner.style.height = '0px'; return; }
    var top = this.el.scrollTop, hgt = this.el.clientHeight || 600;
    var r0 = Math.max(0, Math.floor(top / this.rowH) - 2);
    var r1 = Math.ceil((top + hgt) / this.rowH) + 2;
    var i0 = r0 * this.cols, i1 = Math.min(this.count - 1, r1 * this.cols + this.cols - 1);
    var self = this;
    Object.keys(this.items).forEach(function (k) {
      var i = +k;
      if (i < i0 || i > i1) {
        if (self.items[k] === document.activeElement) return; // fokussiertes Element behalten
        self.inner.removeChild(self.items[k]);
        delete self.items[k];
      }
    });
    for (var i = i0; i <= i1; i++) {
      if (this.items[i]) continue;
      var content = this.render(i);
      var cell = h('div', { 'class': 'vcell focusable', tabindex: '-1', data: { i: i } }, content);
      var row = Math.floor(i / this.cols), col = i % this.cols;
      cell.style.top = (row * this.rowH) + 'px';
      cell.style.left = (col * this.colW) + 'px';
      cell.style.width = this.colW + 'px';
      cell.style.height = this.rowH + 'px';
      (function (idx) {
        cell.addEventListener('click', function () { self.index = idx; self.onSelect(idx); });
      })(i);
      this.items[i] = cell;
      this.inner.appendChild(cell);
    }
  };

  VGrid.prototype.ensureVisible = function (i) {
    var row = Math.floor(i / this.cols);
    var hgt = this.el.clientHeight;
    if (!hgt) return;
    var visRows = Math.max(1, Math.floor(hgt / this.rowH));
    var m = Math.min(this.margin, Math.floor((visRows - 1) / 2));
    var top = this.el.scrollTop;
    var firstVis = Math.ceil(top / this.rowH);
    var lastVis = Math.floor((top + hgt) / this.rowH) - 1;
    if (row < firstVis + m) this.el.scrollTop = Math.max(0, (row - m) * this.rowH);
    else if (row > lastVis - m) this.el.scrollTop = (row + m + 1) * this.rowH - hgt;
  };

  VGrid.prototype.setIndex = function (i, focus, noScroll) {
    if (!this.count) return;
    i = U.clamp(i, 0, this.count - 1);
    var changed = i !== this.index;
    this.index = i;
    if (!noScroll) this.ensureVisible(i);
    this.renderWindow();
    if (focus && this.items[i]) F.nav.focus(this.items[i], { fromGrid: true, noScroll: true });
    if (changed || focus) this.onFocus(i);
  };

  VGrid.prototype.focus = function () {
    if (!this.count) return false;
    this.setIndex(this.index, true);
    return true;
  };

  VGrid.prototype.cell = function (i) { return this.items[i] || null; };

  VGrid.prototype.onKey = function (k) {
    var i = this.index, c = this.cols, n = this.count;
    if (!n) return false;
    var row = Math.floor(i / c), col = i % c, lastRow = Math.floor((n - 1) / c);
    var visRows = Math.max(1, Math.floor((this.el.clientHeight || 600) / this.rowH));
    switch (k) {
      case 'UP':
        if (row === 0) return this.onEdge ? this.onEdge('UP') : false;
        this.setIndex(i - c, true); return true;
      case 'DOWN':
        if (row === lastRow) return this.onEdge ? this.onEdge('DOWN') : false;
        this.setIndex(Math.min(n - 1, i + c), true); return true;
      case 'LEFT':
        if (col === 0) return this.onEdge ? this.onEdge('LEFT') : false;
        this.setIndex(i - 1, true); return true;
      case 'RIGHT':
        if (col === c - 1 || i === n - 1) return this.onEdge ? this.onEdge('RIGHT') : false;
        this.setIndex(i + 1, true); return true;
      case 'CH_UP':
        this.setIndex(Math.max(0, i - visRows * c), true); return true;
      case 'CH_DOWN':
        this.setIndex(Math.min(n - 1, i + visRows * c), true); return true;
      case 'ENTER':
        this.onSelect(i); return true;
    }
    return false;
  };

  VGrid.prototype.destroy = function () { delete F.nav.grids[this.id]; };

  F.VGrid = VGrid;
})();
