/* Flimmer – Hilfsfunktionen
 * Bewusst ES2015/2016-kompatibel (webOS 4 = Chromium 53):
 * kein async/await, kein ?. / ??, kein Object-Spread, kein Object.values/entries.
 */
var F = window.F = window.F || {};

(function () {
  'use strict';
  var U = F.util = {};

  U.$ = function (sel, root) { return (root || document).querySelector(sel); };
  U.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  /** Element erzeugen: h('div', {class:'x', text:'..', onclick:fn, data:{i:1}}, [kinder]) */
  U.h = function (tag, attrs, children) {
    var el = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === undefined || v === null || v === false) return;
        if (k === 'class') el.className = v;
        else if (k === 'text') el.textContent = v;
        else if (k === 'html') el.innerHTML = v;
        else if (k === 'style') {
          if (typeof v === 'string') el.style.cssText = v;
          else Object.keys(v).forEach(function (s) { el.style[s] = v[s]; });
        } else if (k === 'data') Object.keys(v).forEach(function (d) { el.setAttribute('data-' + d, v[d]); });
        else if (k.indexOf('on') === 0 && typeof v === 'function') el.addEventListener(k.slice(2), v);
        else if (v === true) el.setAttribute(k, '');
        else el.setAttribute(k, v);
      });
    }
    if (children !== undefined && children !== null) {
      if (!Array.isArray(children)) children = [children];
      children.forEach(function (c) {
        if (c === null || c === undefined || c === false) return;
        el.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
      });
    }
    return el;
  };

  /** Fokussierbares Element (Fernbedienung + Magic Remote) */
  U.btn = function (cls, attrs, children) {
    attrs = attrs || {};
    attrs['class'] = 'focusable ' + (cls || '');
    attrs.tabindex = '-1';
    return U.h('div', attrs, children);
  };

  U.empty = function (el) { while (el && el.firstChild) el.removeChild(el.firstChild); return el; };
  U.esc = function (s) {
    return String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  U.pad2 = function (n) { n = String(n); return n.length < 2 ? '0' + n : n; };
  U.clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
  U.uid = function () { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); };
  U.values = function (o) { return Object.keys(o || {}).map(function (k) { return o[k]; }); };
  U.always = function (p, fn) { return p.then(function (v) { fn(); return v; }, function (e) { fn(); throw e; }); };

  U.debounce = function (fn, ms) {
    var t = null;
    var d = function () {
      var a = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, a); }, ms);
    };
    d.cancel = function () { clearTimeout(t); };
    return d;
  };

  /** Zeitformat je nach Einstellung 24h / 12h */
  U.fmtTime = function (ts) {
    var d = new Date(ts);
    var h = d.getHours(), m = U.pad2(d.getMinutes());
    if (F.store && F.store.settings.clock === '12h') {
      var ap = h >= 12 ? 'PM' : 'AM';
      h = h % 12; if (h === 0) h = 12;
      return h + ':' + m + ' ' + ap;
    }
    return U.pad2(h) + ':' + m;
  };
  U.fmtDate = function (ts, withYear) {
    var d = new Date(ts);
    var days = F.t('weekdays').split(',');
    return days[d.getDay()] + ', ' + U.pad2(d.getDate()) + '.' + U.pad2(d.getMonth() + 1) + '.' + (withYear ? d.getFullYear() : '');
  };
  U.fmtDur = function (sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
    return (h ? h + ':' + U.pad2(m) : m) + ':' + U.pad2(s);
  };
  U.fmtMinutes = function (min) {
    min = Math.round(min);
    if (min < 60) return min + ' min';
    return Math.floor(min / 60) + ' h ' + (min % 60 ? (min % 60) + ' min' : '');
  };

  /** Base64 → UTF-8 (Xtream liefert EPG-Titel base64-kodiert) */
  U.b64 = function (s) {
    if (!s) return '';
    try {
      var bin = atob(s);
      var bytes = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return new TextDecoder('utf-8').decode(bytes);
    } catch (e) { return s; }
  };

  /** Suchnormalisierung: Kleinbuchstaben, ohne Akzente, ohne Sonderzeichen */
  U.norm = function (s) {
    s = String(s || '').toLowerCase();
    try { s = s.normalize('NFD').replace(/[̀-ͯ]/g, ''); } catch (e) { /* alt */ }
    return s.replace(/ß/g, 'ss').replace(/[^a-z0-9]+/g, ' ').trim();
  };

  U.hash = function (s) {
    var h = 5381; s = String(s);
    for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  };

  U.hue = function (s) { return parseInt(U.hash(s), 36) % 360; };

  /** Platzhalter-Logo (SVG, Initialen auf Farbfläche) */
  U.logoSvg = function (name) {
    var words = String(name || '?').replace(/[^A-Za-z0-9ÄÖÜäöü ]/g, ' ').trim().split(/\s+/);
    var w0 = words[0] || '?', w1 = words[1] || '';
    var ini = (/^\d+$/.test(w1) ? w0[0] + w1.slice(0, 3) : /^\d+$/.test(w0) ? w0.slice(0, 3) : w0[0] + (w1 ? w1[0] : (w0[1] || ''))).toUpperCase();
    var hu = U.hue(name);
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 100"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0" stop-color="hsl(' + hu + ',55%,42%)"/><stop offset="1" stop-color="hsl(' + ((hu + 40) % 360) + ',60%,28%)"/></linearGradient></defs>' +
      '<rect width="160" height="100" rx="14" fill="url(#g)"/><text x="80" y="64" font-family="Arial,sans-serif" font-size="40" font-weight="700" fill="#fff" text-anchor="middle">' + U.esc(ini) + '</text></svg>';
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  };

  /** Platzhalter-Cover für Filme/Serien */
  U.posterSvg = function (name, sub) {
    var hu = U.hue(name);
    var lines = [], line = '';
    String(name || '').split(/\s+/).forEach(function (w) {
      if ((line + ' ' + w).trim().length > 14) { if (line) lines.push(line); line = w; } else line = (line + ' ' + w).trim();
    });
    if (line) lines.push(line);
    lines = lines.slice(0, 4);
    var txt = lines.map(function (l, i) {
      return '<text x="20" y="' + (200 + i * 34) + '" font-family="Georgia,serif" font-size="28" font-weight="700" fill="#fff">' + U.esc(l) + '</text>';
    }).join('');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 360"><defs><linearGradient id="g" x1="0" y1="0" x2="0.4" y2="1">' +
      '<stop offset="0" stop-color="hsl(' + hu + ',45%,38%)"/><stop offset="1" stop-color="hsl(' + ((hu + 60) % 360) + ',55%,12%)"/></linearGradient></defs>' +
      '<rect width="240" height="360" fill="url(#g)"/><circle cx="190" cy="70" r="90" fill="hsla(' + ((hu + 180) % 360) + ',70%,60%,0.18)"/>' + txt +
      (sub ? '<text x="20" y="330" font-family="Arial,sans-serif" font-size="18" fill="rgba(255,255,255,0.7)">' + U.esc(sub) + '</text>' : '') + '</svg>';
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  };

  /** <img> mit Fallback auf Platzhalter */
  U.img = function (src, fallback, cls) {
    var im = document.createElement('img');
    if (cls) im.className = cls;
    im.onerror = function () { im.onerror = null; if (fallback) im.src = fallback; };
    im.src = src || fallback || '';
    return im;
  };

  /** HTTP mit Timeout (XHR, da fetch auf webOS 4 kein Abbrechen kennt) */
  U.xhr = function (url, opts) {
    opts = opts || {};
    return new Promise(function (resolve, reject) {
      var x = new XMLHttpRequest();
      x.open(opts.method || 'GET', url, true);
      x.timeout = opts.timeout || 30000;
      if (opts.responseType) x.responseType = opts.responseType;
      x.onload = function () {
        if (x.status >= 200 && x.status < 300) resolve(opts.responseType ? x.response : x.responseText);
        else { var e = new Error('HTTP ' + x.status); e.status = x.status; e.kind = 'http'; reject(e); }
      };
      x.onerror = function () { var e = new Error('network'); e.kind = 'network'; reject(e); };
      x.ontimeout = function () { var e = new Error('timeout'); e.kind = 'timeout'; reject(e); };
      if (opts.onprogress) x.onprogress = opts.onprogress;
      try { x.send(opts.body || null); } catch (err) { err.kind = 'network'; reject(err); }
    });
  };

  U.json = function (url, opts) {
    return U.xhr(url, opts).then(function (txt) {
      try { return JSON.parse(txt); } catch (e) { var er = new Error('invalid json'); er.kind = 'format'; throw er; }
    });
  };

  /** Text holen, gzip automatisch entpacken (XMLTV .xml.gz) */
  U.text = function (url, opts) {
    opts = opts || {};
    return U.xhr(url, { timeout: opts.timeout || 120000, responseType: 'arraybuffer', onprogress: opts.onprogress }).then(function (buf) {
      var bytes = new Uint8Array(buf);
      if (bytes[0] === 0x1f && bytes[1] === 0x8b && window.pako) {
        var out = window.pako.ungzip(bytes);
        return typeof out === 'string' ? out : new TextDecoder('utf-8').decode(out);
      }
      return new TextDecoder('utf-8').decode(bytes);
    });
  };

  /** Einfache Warteschlange mit begrenzter Parallelität */
  U.queue = function (concurrency) {
    var running = 0, list = [];
    function next() {
      if (running >= concurrency || !list.length) return;
      var job = list.shift();
      running++;
      U.always(Promise.resolve().then(job.fn), function () { running--; next(); }).then(job.res, job.rej);
      next();
    }
    return {
      push: function (fn, front) {
        return new Promise(function (res, rej) {
          var job = { fn: fn, res: res, rej: rej };
          if (front) list.unshift(job); else list.push(job);
          next();
        });
      },
      clear: function () { list = []; },
      size: function () { return list.length + running; }
    };
  };

  /** webOS-Systemdienst aufrufen (z. B. YouTube starten) */
  U.luna = function (uri, params) {
    try {
      if (!window.PalmServiceBridge) return false;
      var b = new window.PalmServiceBridge();
      b.onservicecallback = function () {};
      b.call(uri, JSON.stringify(params || {}));
      return true;
    } catch (e) { return false; }
  };

  /** Beschriftung der Tasten-Hinweise: Fernbedienung (TV) oder Tastatur (Mac/PC) */
  U.keyLabel = function (k) {
    k = String(k).toLowerCase();
    var desk = !U.isWebOS();
    var tv = { ok: 'OK', back: '↩', ch: 'CH', num: '0–9', lr: '◀ ▶', ud: '▲ ▼', info: 'i', left: '◀', right: '▶' };
    var kb = { ok: '↵', back: 'esc', ch: 'Bild ↑↓', red: 'R', green: 'G', yellow: 'Y', blue: 'B' };
    return (desk && kb[k]) || tv[k] || '';
  };
  U.isWebOS = function () { return !!(window.PalmSystem || window.PalmServiceBridge || /web0s|webos/i.test(navigator.userAgent)); };

  /** Element innerhalb seines Scroll-Containers sichtbar machen */
  U.reveal = function (el, center) {
    if (!el) return;
    var p = el.parentNode;
    while (p && p !== document.body) {
      var cs = getComputedStyle(p);
      var oy = cs.overflowY, ox = cs.overflowX;
      if ((oy === 'auto' || oy === 'scroll' || oy === 'hidden') && p.scrollHeight > p.clientHeight + 2) {
        var er = el.getBoundingClientRect(), pr = p.getBoundingClientRect();
        var pad = center ? (pr.height - er.height) / 2 : Math.min(60, pr.height * 0.15);
        if (er.top < pr.top + pad) p.scrollTop -= (pr.top + pad - er.top);
        else if (er.bottom > pr.bottom - pad) p.scrollTop += (er.bottom - (pr.bottom - pad));
      }
      if ((ox === 'auto' || ox === 'scroll' || ox === 'hidden') && p.scrollWidth > p.clientWidth + 2) {
        var er2 = el.getBoundingClientRect(), pr2 = p.getBoundingClientRect();
        var padx = Math.min(80, pr2.width * 0.1);
        if (er2.left < pr2.left + padx) p.scrollLeft -= (pr2.left + padx - er2.left);
        else if (er2.right > pr2.right - padx) p.scrollLeft += (er2.right - (pr2.right - padx));
      }
      p = p.parentNode;
    }
  };

  U.rem = function () { return parseFloat(getComputedStyle(document.documentElement).fontSize) || 16; };

  U.icons = {
    live: '<svg viewBox="0 0 24 24"><path d="M3 7h18v12H3z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M8 3l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    movie: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4" stroke="currentColor" stroke-width="1.6"/></svg>',
    series: '<svg viewBox="0 0 24 24"><rect x="2" y="6" width="15" height="12" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M20 8v10a2 2 0 0 1-2 2H6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M8 10l4 2-4 2z" fill="currentColor"/></svg>',
    star: '<svg viewBox="0 0 24 24"><path d="M12 3l2.8 5.8 6.2.9-4.5 4.4 1.1 6.2L12 17.4l-5.6 2.9 1.1-6.2L3 9.7l6.2-.9z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>',
    starFill: '<svg viewBox="0 0 24 24"><path d="M12 3l2.8 5.8 6.2.9-4.5 4.4 1.1 6.2L12 17.4l-5.6 2.9 1.1-6.2L3 9.7l6.2-.9z" fill="currentColor"/></svg>',
    search: '<svg viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M15.5 15.5L21 21" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    settings: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    guide: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M3 9h18M9 9v11M3 14.5h18" stroke="currentColor" stroke-width="1.6"/></svg>',
    lock: '<svg viewBox="0 0 24 24"><rect x="5" y="10" width="14" height="10" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M8 10V7a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>',
    eyeOff: '<svg viewBox="0 0 24 24"><path d="M3 3l18 18M10.6 6.1A9.7 9.7 0 0 1 12 6c5 0 9 6 9 6a16 16 0 0 1-2.6 3.2M6.2 7.6A16 16 0 0 0 3 12s4 6 9 6a8.6 8.6 0 0 0 4-1" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M7 4.5v15l12-7.5z" fill="currentColor"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z" fill="currentColor"/></svg>',
    check: '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    user: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8.5" r="4" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M4 20.5c1.3-4 4.4-6 8-6s6.7 2 8 6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    history: '<svg viewBox="0 0 24 24"><path d="M4 12a8 8 0 1 0 2.4-5.7L4 8.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M4 4v4.5h4.5M12 8v4.5l3 2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    archive: '<svg viewBox="0 0 24 24"><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M3.5 12a8.5 8.5 0 1 0 2.5-6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M3 4v4h4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    list: '<svg viewBox="0 0 24 24"><path d="M8 6h13M8 12h13M8 18h13" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="4" cy="6" r="1.3" fill="currentColor"/><circle cx="4" cy="12" r="1.3" fill="currentColor"/><circle cx="4" cy="18" r="1.3" fill="currentColor"/></svg>'
  };
  U.icon = function (name, cls) {
    var s = U.h('span', { 'class': 'ico ' + (cls || '') });
    s.innerHTML = U.icons[name] || '';
    return s;
  };
})();
