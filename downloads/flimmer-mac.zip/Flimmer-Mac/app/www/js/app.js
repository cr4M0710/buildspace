/* Flimmer – App-Start, Ansichten-Stapel (Router), Darstellung */
(function () {
  'use strict';
  var U = F.util, h = U.h, S = F.store, t = function (k, v) { return F.t(k, v); };

  var ACCENTS = {
    amber: '#f5a524', coral: '#ff6b5b', teal: '#2ec4b6', sky: '#4ea8ff',
    violet: '#9b7bff', green: '#5bd77a', pink: '#ff5fa2', white: '#e9e9ec'
  };

  var A = F.app = {
    stack: [], ACCENTS: ACCENTS,

    applySettings: function () {
      var st = S.settings, b = document.body;
      b.className = b.className.replace(/\b(theme|fs)-\w+|\bno-anim\b/g, '').trim();
      b.classList.add('theme-' + st.theme);
      b.classList.add('fs-' + st.fontSize);
      if (!st.animations) b.classList.add('no-anim');
      if (F.player && F.player.mode === 'full') b.classList.add('playing-full');
      var w = window.innerWidth || 1920;
      document.documentElement.style.fontSize = (16 * (w / 1920) * (st.uiScale / 100)).toFixed(3) + 'px';
      var hex = ACCENTS[st.accent] || ACCENTS.amber;
      var rgb = [parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16)];
      var root = document.documentElement.style;
      root.setProperty('--accent', hex);
      root.setProperty('--accent-rgb', rgb.join(','));
      var lum = (rgb[0] * 0.299 + rgb[1] * 0.587 + rgb[2] * 0.114);
      root.setProperty('--on-accent', lum > 150 ? '#14161b' : '#ffffff');
      F.i18n.setLang(st.lang);
      document.documentElement.lang = st.lang;
    },

    /** Neue Ansicht öffnen */
    go: function (name, params, opts) {
      opts = opts || {};
      var factory = F.views[name];
      if (!factory) { console.warn('view missing', name); return; }
      var cur = A.top();
      if (opts.replace && cur) A.destroyEntry(A.stack.pop());
      else if (cur) { cur.view.el.classList.add('hidden'); if (cur.view.onHide) cur.view.onHide(); }
      var view = factory(params || {});
      view.el.classList.add('view');
      document.getElementById('views').appendChild(view.el);
      var layer = {
        root: view.el, name: 'view:' + name,
        onKey: function (k, e) { return view.onKey ? view.onKey(k, e) : false; },
        onBack: function () { if (view.onBack && view.onBack() === true) return; A.back(); },
        focusDefault: function () { if (view.focusDefault) view.focusDefault(); else F.nav.focusFirst(view.el); }
      };
      // Ansichten-Ebenen liegen unter offenen Dialogen/Player
      var idx = F.nav.layers.length;
      while (idx > 0 && F.nav.layers[idx - 1].name.indexOf('view:') !== 0) idx--;
      F.nav.layers.splice(idx, 0, layer);
      var entry = { name: name, view: view, layer: layer };
      A.stack.push(entry);
      setTimeout(function () {
        A.refreshGrids(view.el);
        if (view.onShow) view.onShow(true);
        if (F.nav.top() === layer) layer.focusDefault();
      }, 0);
      return view;
    },

    top: function () { return A.stack[A.stack.length - 1] || null; },

    /** Virtuelle Listen nach dem Einblenden neu vermessen */
    refreshGrids: function (root) {
      Object.keys(F.nav.grids).forEach(function (id) {
        var g = F.nav.grids[id];
        if (root.contains(g.el)) g.refresh();
      });
    },

    destroyEntry: function (e) {
      if (!e) return;
      if (e.view.destroy) e.view.destroy();
      if (e.view.el.parentNode) e.view.el.parentNode.removeChild(e.view.el);
      var i = F.nav.layers.indexOf(e.layer);
      if (i >= 0) F.nav.layers.splice(i, 1);
    },

    back: function () {
      if (A.stack.length <= 1) { A.askExit(); return; }
      A.destroyEntry(A.stack.pop());
      var cur = A.top();
      cur.view.el.classList.remove('hidden');
      A.refreshGrids(cur.view.el);
      if (cur.view.onShow) cur.view.onShow(false);
      if (F.nav.top() === cur.layer) F.nav.restore(cur.layer);
    },

    /** Zur Startseite (Stapel leeren) */
    home: function () {
      while (A.stack.length > 1) A.destroyEntry(A.stack.pop());
      var cur = A.top();
      if (!cur || cur.name !== 'home') { if (cur) A.destroyEntry(A.stack.pop()); A.go('home'); return; }
      cur.view.el.classList.remove('hidden');
      A.refreshGrids(cur.view.el);
      if (cur.view.onShow) cur.view.onShow(false);
      F.nav.restore(cur.layer);
    },

    reset: function (name, params) {
      while (A.stack.length) A.destroyEntry(A.stack.pop());
      A.go(name, params);
    },

    emit: function (evt, data) {
      A.stack.forEach(function (e) { if (e.view.onEvent) e.view.onEvent(evt, data); });
    },

    askExit: function () {
      F.ui.confirm({ title: t('exitTitle'), ok: t('exit'), cancel: t('cancel'), focusCancel: true }).then(function (ok) {
        if (!ok) return;
        F.player.stop();
        try { if (window.PalmSystem && window.PalmSystem.platformBack) { window.PalmSystem.platformBack(); return; } } catch (e) { /* */ }
        try { window.close(); } catch (e2) { /* */ }
      });
    },

    /** Profil öffnen und Bibliothek laden */
    openProfile: function (prof) {
      F.player.stop();
      var loader = F.ui.loader(t('loadingProfile', { name: prof.name }));
      return F.lib.activate(prof, loader.text).then(function () {
        loader.close();
        F.epg.reset();
        A.reset('home');
        A.applyStart();
      }, function (e) {
        loader.close();
        var kind = F.providers.errKind(e);
        F.ui.info({ title: t('loadFailed'), text: t('err_' + kind) + (e && e.status ? ' (HTTP ' + e.status + ')' : ''), buttons: [{ label: t('retry'), value: 'retry', primary: true }, { label: t('profiles'), value: 'profiles' }] })
          .then(function (v) {
            if (v === 'retry') A.openProfile(prof);
            else A.reset('login');
          });
      });
    },

    applyStart: function () {
      var st = S.settings.start;
      if (st === 'live') A.go('live');
      else if (st === 'last' && S.p.lastChannel) {
        var it = F.lib.get('live', S.p.lastChannel);
        if (it && !F.lib.isLocked('live', it.cat)) {
          var v = A.go('live', { focusId: it.id, catId: it.cat });
          setTimeout(function () { if (v && v.playFull) v.playFull(it); }, 300);
        }
      }
    },

    start: function () {
      A.applySettings();
      F.player.init();
      window.addEventListener('resize', U.debounce(function () {
        A.applySettings();
        A.emit('resize');
      }, 200));
      var go = function () {
        var prof = S.profile();
        if (prof) A.openProfile(prof);
        else A.reset('login');
      };
      if (S.settings.appPin) {
        var ask = function () {
          F.ui.pin({ title: t('appLocked'), sub: t('appLockedSub'), required: true, check: function (v) { return v === S.settings.appPin; } })
            .then(function (v) { if (v) go(); else ask(); });
        };
        ask();
      } else go();
    }
  };

  document.addEventListener('DOMContentLoaded', A.start);
})();
