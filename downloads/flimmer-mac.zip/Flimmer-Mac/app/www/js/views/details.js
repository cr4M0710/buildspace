/* Flimmer – Detailseite für Filme und Serien (Staffeln, Episoden) */
(function () {
  'use strict';
  var U = F.util, h = U.h, S = F.store, C = F.vc, t = function (k, v) { return F.t(k, v); };

  F.views.details = function (params) {
    var type = params.type, it = params.item;
    var el = h('div', { 'class': 'details ' + type });
    var bg = h('div', { 'class': 'd-bg' });
    el.appendChild(bg);
    el.appendChild(C.header(type === 'vod' ? t('movies') : t('series')));
    var main = h('div', { 'class': 'd-main' });
    el.appendChild(main);
    var posterBox = h('div', { 'class': 'd-poster' }, U.img(F.lib.poster(it), U.posterSvg(it.name, it.year)));
    var info = h('div', { 'class': 'd-info' });
    main.appendChild(posterBox);
    main.appendChild(info);
    var titleEl = h('div', { 'class': 'd-title' }, it.name);
    var metaEl = h('div', { 'class': 'd-meta' });
    var plotEl = h('div', { 'class': 'd-plot' }, h('span', { 'class': 'muted' }, t('loading')));
    var creditsEl = h('div', { 'class': 'd-credits' });
    var buttons = h('div', { 'class': 'd-buttons', data: { group: 'd-buttons' } });
    [titleEl, metaEl, plotEl, creditsEl, buttons].forEach(function (x) { info.appendChild(x); });

    var seriesBox = h('div', { 'class': 'd-series hidden' });
    var seasonTabs = h('div', { 'class': 'd-seasons', data: { group: 'seasons' } });
    var epList = h('div', { 'class': 'd-episodes' });
    seriesBox.appendChild(seasonTabs);
    seriesBox.appendChild(epList);
    el.appendChild(seriesBox);
    var hintBox = h('div', {});
    el.appendChild(hintBox);

    var st = { info: null, seasons: [], season: 0, all: [] };
    var epGrid = null;

    function setBg(src) {
      if (!src) return;
      var im = new Image();
      im.onload = function () { bg.style.backgroundImage = 'url("' + src.replace(/"/g, '%22') + '")'; bg.classList.add('on'); };
      im.src = src;
    }

    function renderMeta(i) {
      var parts = [];
      if (i.year) parts.push(i.year);
      if (i.duration) parts.push(U.fmtMinutes(i.duration / 60));
      if (i.genre) parts.push(i.genre);
      U.empty(metaEl);
      metaEl.appendChild(h('span', {}, parts.join('  ·  ')));
      if (i.rating) metaEl.appendChild(h('span', { 'class': 'd-rating' }, [U.icon('starFill'), (Math.round(i.rating * 10) / 10).toFixed(1)]));
      U.empty(plotEl).appendChild(document.createTextNode(i.plot || t('noDescription')));
      U.empty(creditsEl);
      if (i.director) creditsEl.appendChild(h('div', {}, [h('b', {}, t('director') + ': '), i.director]));
      if (i.cast) creditsEl.appendChild(h('div', {}, [h('b', {}, t('cast') + ': '), String(i.cast).slice(0, 180)]));
    }

    function favBtn() {
      var on = S.isFav(type, it.id);
      var b = U.btn('button icon-btn', {
        onclick: function () {
          var v = S.toggleFav(type, it.id);
          F.ui.toast(t(v ? 'favAdded' : 'favRemoved'));
          var nb = favBtn(); buttons.replaceChild(nb, b); F.nav.focus(nb);
        }
      }, [U.icon(on ? 'starFill' : 'star'), on ? t('inFavorites') : t('addFavorite')]);
      return b;
    }

    function trailerBtn(i) {
      if (!i.trailer) return null;
      return U.btn('button', {
        onclick: function () {
          var id = String(i.trailer).replace(/^.*(v=|youtu\.be\/)/, '').replace(/[&?].*$/, '');
          var ok = U.luna('luna://com.webos.applicationManager/launch', { id: 'youtube.leanback.v4', params: { contentTarget: 'v=' + id } });
          if (!ok) { try { window.open('https://www.youtube.com/watch?v=' + id, '_blank'); } catch (e) { F.ui.toast(t('trailerFail')); } }
        }
      }, t('trailer'));
    }

    /* ---------- Film ---------- */
    function renderVodButtons() {
      U.empty(buttons);
      var key = 'vod:' + it.id;
      var pr = S.getProgress(key);
      var play = function (at) { F.player.playVod(it, st.info || {}, at); };
      if (pr && pr.pos > 30) {
        buttons.appendChild(U.btn('button primary default-focus', { onclick: function () { play(pr.pos); } }, [U.icon('play'), t('resumeAt', { t: U.fmtDur(pr.pos) })]));
        buttons.appendChild(U.btn('button', { onclick: function () { play(0); } }, t('fromStart')));
      } else {
        buttons.appendChild(U.btn('button primary default-focus', { onclick: function () { play(0); } }, [U.icon('play'), t('play')]));
      }
      buttons.appendChild(favBtn());
      var tb = trailerBtn(st.info || {});
      if (tb) buttons.appendChild(tb);
      if (S.isWatched(key)) buttons.appendChild(h('span', { 'class': 'd-watched' }, [U.icon('check'), t('watched')]));
    }

    /* ---------- Serie ---------- */
    function renderSeriesButtons() {
      U.empty(buttons);
      var next = nextEpisode();
      if (next) {
        var pr = S.getProgress('ep:' + next.ep.id);
        buttons.appendChild(U.btn('button primary default-focus', {
          onclick: function () { F.player.playEpisode(seriesObj(), st.all, next.idx, pr ? pr.pos : 0); }
        }, [U.icon('play'), (pr ? t('resume') : t('play')) + '  S' + U.pad2(next.ep.season) + ' E' + U.pad2(next.ep.episode)]));
      }
      buttons.appendChild(favBtn());
      var tb = trailerBtn((st.info && st.info.info) || {});
      if (tb) buttons.appendChild(tb);
    }

    function seriesObj() { return Object.assign({}, it, { poster: (st.info && st.info.info.poster) || it.poster }); }

    /** Erste nicht gesehene bzw. angefangene Episode */
    function nextEpisode() {
      if (!st.all.length) return null;
      var best = null;
      st.all.forEach(function (e, i) {
        var pr = S.getProgress('ep:' + e.id);
        if (pr && (!best || pr.ts > best.ts)) best = { ts: pr.ts, idx: i };
      });
      if (best) return { ep: st.all[best.idx], idx: best.idx };
      var lastW = -1;
      st.all.forEach(function (e, i) { if (S.isWatched('ep:' + e.id)) lastW = i; });
      var idx = Math.min(st.all.length - 1, lastW + 1);
      return { ep: st.all[idx], idx: idx };
    }

    function renderSeasons() {
      U.empty(seasonTabs);
      st.seasons.forEach(function (s, i) {
        var tab = U.btn('season-tab' + (i === st.season ? ' on' : ''), {
          onclick: function () { selectSeason(i, true); }
        }, s.name || t('seasonN', { n: s.num }));
        tab._season = i;
        seasonTabs.appendChild(tab);
      });
    }

    function selectSeason(i, focusList) {
      st.season = i;
      U.$$('.season-tab', seasonTabs).forEach(function (x) { x.classList.toggle('on', x._season === i); });
      var eps = st.seasons[i] ? st.seasons[i].episodes : [];
      epGrid.count = eps.length;
      epGrid.index = 0;
      epList.scrollTop = 0;
      epGrid.refresh();
      if (focusList && eps.length) epGrid.focus();
    }

    function epRow(e) {
      var key = 'ep:' + e.id, pr = S.getProgress(key), w = S.isWatched(key);
      return h('div', { 'class': 'ep-row' + (w ? ' watched' : '') }, [
        h('div', { 'class': 'ep-num' }, U.pad2(e.episode)),
        h('div', { 'class': 'ep-text' }, [
          h('div', { 'class': 'ep-title' }, e.title || t('episodeN', { n: e.episode })),
          e.plot ? h('div', { 'class': 'ep-plot' }, e.plot) : null,
          pr && pr.dur ? h('div', { 'class': 'ep-progress' }, h('div', { style: 'width:' + Math.round(pr.pos / pr.dur * 100) + '%' })) : null
        ]),
        h('div', { 'class': 'ep-dur' }, e.duration ? U.fmtMinutes(e.duration / 60) : ''),
        w ? U.icon('check', 'ep-check') : null
      ]);
    }

    function playEp(e) {
      var idx = st.all.indexOf(e);
      C.resumeAsk('ep:' + e.id).then(function (at) {
        if (at === null) return;
        F.player.playEpisode(seriesObj(), st.all, idx, at);
      });
    }

    function initSeries(data) {
      st.info = data;
      st.seasons = data.seasons || [];
      st.all = [];
      st.seasons.forEach(function (s) { st.all = st.all.concat(s.episodes); });
      renderMeta(data.info || {});
      setBg((data.info && (data.info.backdrop || data.info.poster)) || it.poster);
      seriesBox.classList.remove('hidden');
      el.classList.add('has-series');
      epGrid = new F.VGrid({
        container: epList, rowRem: 6.4, count: 0, margin: 1,
        render: function (i) { return epRow(st.seasons[st.season].episodes[i]); },
        onSelect: function (i) { playEp(st.seasons[st.season].episodes[i]); },
        onEdge: function (dir) { if (dir === 'UP') { var tab = seasonTabs.querySelector('.on'); if (tab) F.nav.focus(tab); return true; } return false; }
      });
      renderSeasons();
      var nx = nextEpisode();
      var si = 0;
      if (nx) st.seasons.forEach(function (s, i) { if (s.episodes.indexOf(nx.ep) >= 0) si = i; });
      selectSeason(si, false);
      if (nx) { var ei = st.seasons[si].episodes.indexOf(nx.ep); if (ei >= 0) { epGrid.index = ei; epGrid.refresh(); } }
      renderSeriesButtons();
      U.empty(hintBox).appendChild(F.ui.hints([['ok', t('play')], ['red', t('favorite')], ['yellow', t('toggleWatched')]]));
      if (!st.all.length) U.empty(epList).appendChild(C.empty(t('noEpisodes'), '', 'series'));
      F.nav.focus(buttons.querySelector('.default-focus') || buttons.firstChild);
    }

    function load() {
      if (type === 'vod') {
        F.lib.provider.vodInfo(it).then(function (i) {
          st.info = i;
          renderMeta(i);
          if (i.poster && !it.poster) posterBox.replaceChild(U.img(i.poster, U.posterSvg(it.name, it.year)), posterBox.firstChild);
          setBg(i.backdrop || i.poster || it.poster);
          renderVodButtons();
          F.nav.focus(buttons.querySelector('.default-focus'));
        }, function () {
          st.info = { title: it.name, year: it.year, rating: it.rating };
          renderMeta(st.info);
          renderVodButtons();
          F.nav.focus(buttons.querySelector('.default-focus'));
        });
        renderVodButtons();
        U.empty(hintBox).appendChild(F.ui.hints([['ok', t('select')], ['back', t('back')]]));
      } else {
        renderSeriesButtons();
        F.lib.provider.seriesInfo(it).then(initSeries, function () {
          U.empty(plotEl).appendChild(document.createTextNode(t('loadFailed')));
        });
      }
    }
    load();

    return {
      el: el,
      focusDefault: function () { F.nav.focus(buttons.querySelector('.default-focus') || buttons.firstChild); },
      onKey: function (k) {
        var a = document.activeElement;
        if (k === 'RED') { var on = S.toggleFav(type, it.id); F.ui.toast(t(on ? 'favAdded' : 'favRemoved')); if (type === 'vod') renderVodButtons(); else renderSeriesButtons(); if (!document.body.contains(a)) F.nav.focus(buttons.firstChild); return true; }
        if (k === 'YELLOW' && epGrid && a && epList.contains(a)) {
          var e = st.seasons[st.season].episodes[epGrid.index];
          var key = 'ep:' + e.id;
          S.setWatched(key, !S.isWatched(key));
          epGrid.update(epGrid.index);
          renderSeriesButtons();
          return true;
        }
        if (k === 'DOWN' && a && buttons.contains(a) && epGrid && epGrid.count) {
          var tab = seasonTabs.querySelector('.on');
          if (tab) { F.nav.focus(tab); return true; }
        }
        if (k === 'DOWN' && a && seasonTabs.contains(a) && epGrid && epGrid.count) {
          if (a._season !== st.season) selectSeason(a._season, false);
          epGrid.focus(); return true;
        }
        return false;
      },
      onShow: function (first) {
        if (first) return;
        if (type === 'vod') renderVodButtons();
        else if (st.info) { renderSeriesButtons(); if (epGrid) epGrid.refresh(); }
      },
      onEvent: function (e) { if (e === 'progress') { if (type === 'vod') renderVodButtons(); else if (epGrid) { epGrid.refresh(); renderSeriesButtons(); } } },
      destroy: function () { if (epGrid) epGrid.destroy(); }
    };
  };
})();
