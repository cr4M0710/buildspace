/* Flimmer – gemeinsame Bausteine der Ansichten */
(function () {
  'use strict';
  var U = F.util, h = U.h, S = F.store, t = function (k, v) { return F.t(k, v); };
  F.views = F.views || {};
  var C = F.vc = {};

  /** Kopfzeile mit Titel und Uhr */
  C.header = function (title, extra) {
    return h('div', { 'class': 'header' }, [
      h('div', { 'class': 'brand' }, [h('span', { 'class': 'brand-mark' }), h('span', { 'class': 'brand-name' }, 'Flimmer')]),
      title ? h('div', { 'class': 'header-title' }, title) : null,
      h('div', { 'class': 'header-extra' }, extra || null),
      h('div', { 'class': 'clock' }, U.fmtTime(Date.now()))
    ]);
  };

  setInterval(function () {
    var s = U.fmtTime(Date.now());
    U.$$('.clock').forEach(function (c) { c.textContent = s; });
  }, 15000);

  /** Kategorie-Seitenleiste (virtuelle Liste) */
  C.catPanel = function (o) {
    var el = h('div', { 'class': 'cat-panel' });
    var listEl = h('div', { 'class': 'cat-list' });
    el.appendChild(h('div', { 'class': 'panel-title' }, o.title || t('categories')));
    el.appendChild(listEl);
    var api = { el: el, cats: [], active: o.active || '__all' };
    var grid = api.grid = new F.VGrid({
      container: listEl, rowRem: 4, count: 0, margin: 2,
      render: function (i) {
        var c = api.cats[i];
        return h('div', { 'class': 'cat-row' + (c.id === api.active ? ' active' : '') + (c.special ? ' special' : '') }, [
          c.icon ? U.icon(c.icon, 'cat-ico') : null,
          h('span', { 'class': 'cat-name' }, c.name),
          c.locked ? U.icon('lock', 'cat-lock') : (c.count !== undefined ? h('span', { 'class': 'cat-count' }, String(c.count)) : null)
        ]);
      },
      onFocus: function (i) { if (o.onFocusCat) o.onFocusCat(api.cats[i], i); },
      onSelect: function (i) { if (o.onPick) o.onPick(api.cats[i], i); },
      onEdge: o.onEdge
    });
    api.reload = function () {
      api.cats = F.lib.cats(o.type);
      var idx = 0;
      api.cats.forEach(function (c, i) { if (c.id === api.active) idx = i; });
      grid.count = api.cats.length;
      grid.index = idx;
      grid.refresh();
    };
    api.setActive = function (id) {
      var old = api.active;
      api.active = id;
      api.cats.forEach(function (c, i) { if (c.id === old || c.id === id) grid.update(i); });
    };
    api.current = function () { return api.cats[grid.index]; };
    api.reload();
    return api;
  };

  /** Poster-Karte (Filme/Serien) */
  C.posterCard = function (type, it) {
    var key = type === 'vod' ? 'vod:' + it.id : null;
    var pr = key ? S.getProgress(key) : null;
    return h('div', { 'class': 'poster-card' }, [
      h('div', { 'class': 'poster-img' }, [
        U.img(F.lib.poster(it), U.posterSvg(it.name, it.year)),
        S.isFav(type, it.id) ? U.icon('starFill', 'poster-fav') : null,
        it.rating ? h('span', { 'class': 'poster-rating' }, (Math.round(it.rating * 10) / 10).toFixed(1)) : null,
        pr && pr.dur ? h('div', { 'class': 'poster-progress' }, h('div', { style: 'width:' + Math.round(pr.pos / pr.dur * 100) + '%' })) : null,
        key && S.isWatched(key) ? U.icon('check', 'poster-watched') : null
      ]),
      h('div', { 'class': 'poster-title' }, it.name),
      h('div', { 'class': 'poster-meta' }, it.year || '')
    ]);
  };

  /** Spaltenanzahl für Poster je nach Kachelgröße */
  C.posterCols = function () { return { s: 7, m: 6, l: 5 }[S.settings.tileSize] || 6; };

  /** Eintrag im Live-TV-Stil */
  C.channelRow = function (it, opts) {
    opts = opts || {};
    var list = F.epg.peek(it);
    var nn = F.epg.nowNext(list);
    var layout = opts.layout || S.settings.liveLayout;
    var logo = S.settings.showLogos ? U.img(F.lib.logo(it), U.logoSvg(it.name), 'ch-logo') : null;
    var num = S.settings.showNumbers ? h('span', { 'class': 'ch-num' }, String(it.num)) : null;
    var fav = S.isFav('live', it.id) ? U.icon('starFill', 'ch-fav') : null;
    var arch = it.archive ? U.icon('archive', 'ch-arch') : null;
    if (layout === 'grid') {
      return h('div', { 'class': 'ch-tile' + (opts.playing ? ' playing' : '') }, [
        logo || h('div', { 'class': 'ch-tile-noLogo' }), h('div', { 'class': 'ch-tile-name' }, [num, it.name]), fav
      ]);
    }
    if (layout === 'compact') {
      return h('div', { 'class': 'ch-row compact' + (opts.playing ? ' playing' : '') }, [num, h('span', { 'class': 'ch-name' }, it.name), h('span', { 'class': 'ch-nowc' }, nn.cur ? nn.cur.title : ''), arch, fav]);
    }
    return h('div', { 'class': 'ch-row' + (opts.playing ? ' playing' : '') }, [
      num, logo,
      h('div', { 'class': 'ch-text' }, [
        h('div', { 'class': 'ch-name' }, [it.name, arch, fav]),
        h('div', { 'class': 'ch-now' }, nn.cur ? nn.cur.title : (list === null ? '…' : '')),
        nn.cur ? h('div', { 'class': 'ch-prog' }, h('div', { style: 'width:' + Math.round(F.epg.progress(nn.cur) * 100) + '%' })) : null
      ])
    ]);
  };

  /** Favorit/Liste-Dialog für Sender */
  C.channelFavMenu = function (it) {
    var opts = [{ label: t('favorites'), value: '__fav', checked: S.isFav('live', it.id) }];
    S.p.lists.forEach(function (l) { opts.push({ label: l.name, value: l.id, checked: l.items.indexOf(String(it.id)) >= 0 }); });
    opts.push({ label: '＋ ' + t('newList'), value: '__new' });
    return F.ui.select({ title: it.name, sub: t('favMenuSub'), options: opts }).then(function (v) {
      if (v === undefined) return false;
      if (v === '__fav') { var on = S.toggleFav('live', it.id); F.ui.toast(t(on ? 'favAdded' : 'favRemoved')); return true; }
      if (v === '__new') {
        return F.ui.prompt({ title: t('newList'), placeholder: t('listName') }).then(function (name) {
          if (!name) return false;
          var l = F.lib.listCreate(name.trim());
          F.lib.listToggle(l.id, it.id);
          F.ui.toast(t('addedToList', { name: l.name }));
          return true;
        });
      }
      F.lib.listToggle(v, it.id);
      return true;
    });
  };

  /** Leerer Zustand */
  C.empty = function (title, text, icon) {
    return h('div', { 'class': 'empty-state' }, [icon ? U.icon(icon, 'empty-ico') : null, h('div', { 'class': 'empty-title' }, title), text ? h('div', { 'class': 'empty-text' }, text) : null]);
  };

  /** Live-Sender abspielen (mit Sperrprüfung) */
  C.playChannel = function (it, list, opts) {
    return F.lib.unlock('live', it.cat).then(function (ok) {
      if (!ok) return false;
      F.player.playLive(it, Object.assign({ list: list }, opts || {}));
      return true;
    });
  };

  /** Fortsetzen-Abfrage */
  C.resumeAsk = function (key) {
    var pr = S.getProgress(key);
    if (!pr || pr.pos < 30) return Promise.resolve(0);
    return F.ui.select({
      title: t('resumeTitle'),
      options: [{ label: t('resumeAt', { t: U.fmtDur(pr.pos) }), value: pr.pos }, { label: t('fromStart'), value: 0 }]
    }).then(function (v) { return v === undefined ? null : v; });
  };

  /** Details der Sendung als Dialog */
  C.progInfo = function (it, p) {
    var el = h('div', { 'class': 'prog-info' }, [
      h('div', { 'class': 'prog-info-time' }, U.fmtDate(p.start) + '  ' + U.fmtTime(p.start) + ' – ' + U.fmtTime(p.end) + '  ·  ' + U.fmtMinutes((p.end - p.start) / 60000)),
      h('div', { 'class': 'prog-info-ch' }, it.name),
      p.desc ? h('p', { 'class': 'prog-info-desc' }, p.desc) : h('p', { 'class': 'prog-info-desc muted' }, t('noDescription'))
    ]);
    var now = Date.now();
    var buttons = [];
    if (p.start <= now && p.end > now) buttons.push({ label: t('watchLive'), value: 'live', primary: true });
    else if (p.end <= now && it.archive) buttons.push({ label: t('watchArchive'), value: 'archive', primary: true });
    return F.ui.info({ title: p.title, el: el, buttons: buttons }).then(function (v) {
      if (v === 'live') C.playChannel(it, null);
      if (v === 'archive') F.lib.unlock('live', it.cat).then(function (ok) { if (ok) F.player.playCatchup(it, p); });
    });
  };
})();
