/* Flimmer – Live-TV: Kategorien | Senderliste | Vorschau mit EPG */
(function () {
  'use strict';
  var U = F.util, h = U.h, S = F.store, C = F.vc, t = function (k, v) { return F.t(k, v); };

  F.views.live = function (params) {
    params = params || {};
    var el = h('div', { 'class': 'live layout-' + S.settings.liveLayout });
    var catTitle = h('span');
    el.appendChild(C.header(t('liveTv'), catTitle));
    var body = h('div', { 'class': 'live-body' });
    el.appendChild(body);

    var state = { catId: params.catId || '__all', items: [], playing: null, focused: null };

    /* --- Kategorien --- */
    var cats = C.catPanel({
      type: 'live', active: state.catId,
      onFocusCat: U.debounce(function (c) { if (c && !c.locked && c.id !== state.catId) loadCat(c.id, false); }, 350),
      onPick: function (c) {
        F.lib.unlock('live', c.id).then(function (ok) {
          if (!ok) return;
          if (c.locked) cats.reload();
          loadCat(c.id, true);
        });
      },
      onEdge: function (dir) { if (dir === 'RIGHT') { if (grid.count) grid.focus(); return true; } return false; }
    });
    body.appendChild(cats.el);

    /* --- Senderliste --- */
    var chanPanel = h('div', { 'class': 'chan-panel' });
    var chanTitle = h('div', { 'class': 'panel-title' });
    var chanList = h('div', { 'class': 'chan-list' });
    var chanEmpty = h('div', { 'class': 'chan-empty hidden' });
    chanPanel.appendChild(chanTitle);
    chanPanel.appendChild(chanList);
    chanPanel.appendChild(chanEmpty);
    body.appendChild(chanPanel);

    function layoutCfg() {
      var l = S.settings.liveLayout;
      if (l === 'grid') return { cols: 3, rowRem: 10.5 };
      if (l === 'compact') return { cols: 1, rowRem: 3.8 };
      return { cols: 1, rowRem: 6.2 };
    }
    var cfg = layoutCfg();
    var grid = new F.VGrid({
      container: chanList, cols: cfg.cols, rowRem: cfg.rowRem, count: 0, margin: 2,
      render: function (i) {
        var it = state.items[i];
        if (F.epg.mode === 'short' && !F.epg.peek(it)) F.epg.get(it);
        return C.channelRow(it, { playing: state.playing && state.playing.id === it.id });
      },
      onFocus: function (i) { focusChannel(state.items[i]); },
      onSelect: function (i) { selectChannel(state.items[i]); },
      onEdge: function (dir) {
        if (dir === 'LEFT') { cats.grid.focus(); return true; }
        if (dir === 'RIGHT') { var b = preview.querySelector('.focusable'); if (b) F.nav.focus(b); return true; }
        return false;
      }
    });

    /* --- Vorschau --- */
    var preview = h('div', { 'class': 'preview-panel' });
    var pvBox = h('div', { 'class': 'pv-video' }, [h('div', { 'class': 'pv-placeholder' })]);
    var pvInfo = h('div', { 'class': 'pv-info' });
    preview.appendChild(pvBox);
    preview.appendChild(pvInfo);
    body.appendChild(preview);

    el.appendChild(F.ui.hints([['ok', S.settings.preview ? t('hintPreviewFull') : t('play')], ['red', t('favorite')], ['green', t('manageCats')], ['yellow', t('tvGuide')], ['blue', t('search')], ['num', t('channelNumber')]]));

    function loadCat(id, focusList) {
      state.catId = id;
      cats.setActive(id);
      state.items = F.lib.items('live', id);
      var name = '';
      cats.cats.forEach(function (c) { if (c.id === id) name = c.name; });
      chanTitle.textContent = name + '  ·  ' + state.items.length;
      catTitle.textContent = name;
      grid.count = state.items.length;
      grid.index = 0;
      chanList.scrollTop = 0;
      if (params.focusId) {
        state.items.forEach(function (it, i) { if (it.id === params.focusId) grid.index = i; });
        params.focusId = null;
      }
      grid.refresh();
      chanEmpty.classList.toggle('hidden', !!state.items.length);
      if (!state.items.length) {
        U.empty(chanEmpty).appendChild(C.empty(
          id === '__fav' ? t('noFavorites') : id === '__recent' ? t('noRecent') : t('noChannels'),
          id === '__fav' ? t('noFavoritesHint') : ''
        , 'star'));
      }
      if (focusList && state.items.length) grid.focus();
      if (state.items.length) focusChannel(state.items[grid.index]);
      else { state.focused = null; U.empty(pvInfo); }
    }

    var autoPlay = U.debounce(function (it) {
      if (state.focused === it && S.settings.preview && S.settings.previewAuto && !el.classList.contains('hidden')) playMini(it);
    }, 900);

    function focusChannel(it) {
      state.focused = it;
      renderInfo(it);
      F.epg.get(it, true);
      if (S.settings.previewAuto) autoPlay(it);
    }

    function renderInfo(it) {
      U.empty(pvInfo);
      if (!it) return;
      var list = F.epg.peek(it);
      var nn = F.epg.nowNext(list);
      pvInfo.appendChild(h('div', { 'class': 'pv-ch' }, [
        S.settings.showLogos ? U.img(F.lib.logo(it), U.logoSvg(it.name), 'pv-logo') : null,
        h('div', {}, [h('div', { 'class': 'pv-name' }, (S.settings.showNumbers ? it.num + '  ' : '') + it.name), h('div', { 'class': 'pv-cat' }, F.lib.catName('live', it.cat))]),
        S.isFav('live', it.id) ? U.icon('starFill', 'pv-fav') : null
      ]));
      if (nn.cur) {
        pvInfo.appendChild(h('div', { 'class': 'pv-now-label' }, t('nowOn')));
        pvInfo.appendChild(h('div', { 'class': 'pv-now' }, nn.cur.title));
        pvInfo.appendChild(h('div', { 'class': 'pv-time' }, U.fmtTime(nn.cur.start) + ' – ' + U.fmtTime(nn.cur.end) + '  ·  ' + t('minLeft', { n: Math.max(0, Math.round((nn.cur.end - Date.now()) / 60000)) })));
        pvInfo.appendChild(h('div', { 'class': 'pv-bar' }, h('div', { style: 'width:' + Math.round(F.epg.progress(nn.cur) * 100) + '%' })));
        if (nn.cur.desc) pvInfo.appendChild(h('div', { 'class': 'pv-desc' }, nn.cur.desc));
      } else {
        pvInfo.appendChild(h('div', { 'class': 'pv-now muted' }, list === null ? t('epgLoading') : t('noEpg')));
      }
      var later = (nn.later || []).filter(function (p) { return p !== nn.cur; }).slice(0, 3);
      if (later.length) {
        pvInfo.appendChild(h('div', { 'class': 'pv-later' }, later.map(function (p) {
          return h('div', { 'class': 'pv-later-row' }, [h('span', { 'class': 'pv-later-time' }, U.fmtTime(p.start)), h('span', {}, p.title)]);
        })));
      }
    }

    function previewRect() {
      if (el.classList.contains('hidden') || !S.settings.preview) return null;
      var r = pvBox.getBoundingClientRect();
      if (!r.width) return null;
      return { left: r.left, top: r.top, width: r.width, height: r.height };
    }

    function onChannel(it) {
      var prev = state.playing;
      state.playing = it;
      var i = state.items.indexOf(it);
      if (i >= 0) { grid.index = i; }
      redrawPlaying(prev, it);
      if (i >= 0 && state.focused !== it) { state.focused = it; renderInfo(it); }
    }

    function redrawPlaying(a, b) {
      [a, b].forEach(function (x) { if (!x) return; var i = state.items.indexOf(x); if (i >= 0) grid.update(i); });
    }

    function playMini(it) {
      var rect = previewRect();
      if (!rect) return;
      C.playChannel(it, state.items, { mini: rect, onExit: function () { return previewRect(); }, onChannel: onChannel }).then(function (ok) {
        if (ok) pvBox.classList.add('active');
      });
    }

    function playFull(it) {
      C.playChannel(it, state.items.indexOf(it) >= 0 ? state.items : [it], { onExit: function () { return previewRect(); }, onChannel: onChannel }).then(function (ok) {
        if (ok) pvBox.classList.add('active');
      });
    }

    function selectChannel(it) {
      if (!it) return;
      var pm = F.player.media;
      var isPlaying = pm && pm.type === 'live' && pm.item.id === it.id && F.player.mode === 'mini';
      if (!S.settings.preview || isPlaying) playFull(it);
      else playMini(it);
    }

    /* Ziffern: Sender direkt anwählen */
    var num = '', numTimer = null, numEl = h('div', { 'class': 'num-overlay' });
    el.appendChild(numEl);
    function numKey(d) {
      num = (num + d).slice(0, 5);
      numEl.textContent = num; numEl.classList.add('show');
      clearTimeout(numTimer);
      numTimer = setTimeout(function () {
        var n = parseInt(num, 10); num = ''; numEl.classList.remove('show');
        var idx = -1;
        state.items.forEach(function (it, i) { if (it.num === n && idx < 0) idx = i; });
        if (idx >= 0) { grid.setIndex(idx, true); return; }
        var found = null;
        F.lib.data.live.items.some(function (it) { if (it.num === n && F.lib.visibleItem('live', it)) { found = it; return true; } return false; });
        if (found) { loadCat('__all', false); var j = state.items.indexOf(found); if (j >= 0) grid.setIndex(j, true); }
        else F.ui.toast(t('noChannelNum', { n: n }));
      }, 1300);
    }

    var epgPending = {};
    var epgFlush = U.debounce(function () {
      var ids = epgPending; epgPending = {};
      if (el.classList.contains('hidden')) return;
      if (state.focused && (ids['*'] || ids[state.focused.id])) renderInfo(state.focused);
      if (ids['*']) { grid.refresh(); return; }
      state.items.forEach(function (it, i) { if (ids[it.id] && grid.cell(i)) grid.update(i); });
    }, 120);
    var unlisten = F.epg.listen(function (id) { epgPending[id || '*'] = true; epgFlush(); });

    loadCat(state.catId, false);
    var ticker = setInterval(function () { if (!el.classList.contains('hidden') && state.focused) renderInfo(state.focused); }, 60000);

    return {
      el: el,
      playFull: playFull,
      focusDefault: function () { if (grid.count) grid.focus(); else cats.grid.focus(); },
      onKey: function (k) {
        var a = document.activeElement;
        var inList = a && chanList.contains(a);
        if (/^[0-9]$/.test(k)) { numKey(k); return true; }
        if (k === 'RED' && inList && state.focused) {
          C.channelFavMenu(state.focused).then(function (changed) {
            if (!changed) return;
            var i = grid.index;
            if (state.catId === '__fav' || state.catId.indexOf('__list:') === 0) { loadCat(state.catId, false); grid.setIndex(Math.min(i, grid.count - 1), true); }
            else grid.update(i);
            cats.reload();
            renderInfo(state.focused);
          });
          return true;
        }
        if (k === 'RED' && a && cats.el.contains(a)) {
          var c = cats.current();
          if (c && c.userList) {
            F.ui.select({ title: c.name, options: [{ label: t('rename'), value: 'rename' }, { label: t('deleteList'), value: 'delete' }] }).then(function (v) {
              var lid = c.id.slice(7);
              if (v === 'rename') F.ui.prompt({ title: t('rename'), value: c.name }).then(function (n) { if (n) { F.lib.listRename(lid, n); cats.reload(); } });
              if (v === 'delete') { F.lib.listDelete(lid); loadCat('__all', false); cats.reload(); }
            });
            return true;
          }
        }
        if (k === 'YELLOW') { F.player.stop(); F.app.go('guide', { catId: state.catId }); return true; }
        if (k === 'GREEN') { F.player.stop(); F.app.go('categories', { type: 'live' }); return true; }
        if (k === 'BLUE') { F.player.stop(); F.app.go('search', { type: 'live' }); return true; }
        if (k === 'INFO' && state.focused) {
          var nn = F.epg.nowNext(F.epg.peek(state.focused));
          if (nn.cur) C.progInfo(state.focused, nn.cur);
          return true;
        }
        if (k === 'CH_UP' || k === 'CH_DOWN') {
          if (F.player.mode === 'mini' && state.playing) {
            var i2 = state.items.indexOf(state.playing);
            var n2 = state.items[(i2 + (k === 'CH_UP' ? 1 : -1) + state.items.length) % state.items.length];
            if (n2) { grid.setIndex(state.items.indexOf(n2), true); playMini(n2); }
            return true;
          }
        }
        return false;
      },
      onBack: function () {
        if (F.player.mode === 'mini') { F.player.stop(); pvBox.classList.remove('active'); var was = state.playing; state.playing = null; redrawPlaying(was); return true; }
        return false;
      },
      onHide: function () { F.player.stop(); pvBox.classList.remove('active'); state.playing = null; },
      onShow: function (first) {
        if (first) return;
        el.className = el.className.replace(/layout-\w+/, 'layout-' + S.settings.liveLayout);
        var c2 = layoutCfg();
        grid.cols = c2.cols; grid.rowRem = c2.rowRem;
        cats.reload();
        state.items = F.lib.items('live', state.catId);
        grid.count = state.items.length;
        grid.refresh();
        if (state.focused) renderInfo(state.focused);
      },
      onEvent: function (e) {
        if (e === 'library') { cats.reload(); loadCat(state.catId, false); }
        if (e === 'resize') { cats.grid.refresh(); grid.refresh(); if (F.player.mode === 'mini') { var r = previewRect(); if (r) F.player.mini(r); } }
      },
      destroy: function () {
        if (F.player.media && F.player.media.type === 'live') F.player.stop();
        unlisten(); clearInterval(ticker); grid.destroy(); cats.grid.destroy();
      }
    };
  };
})();
