/* Flimmer – Profile & Anmeldung (Xtream Codes / M3U) */
(function () {
  'use strict';
  var U = F.util, h = U.h, S = F.store, C = F.vc, t = function (k, v) { return F.t(k, v); };

  var TYPE_LABEL = { xtream: 'Xtream Codes', m3u: 'M3U-Playlist', demo: 'Demo' };

  /* ---------- Profilauswahl ---------- */
  F.views.login = function () {
    var el = h('div', { 'class': 'login' });
    var row = h('div', { 'class': 'profile-row', data: { group: 'profiles' } });

    function tile(p) {
      var b = U.btn('profile-tile', { onclick: function () { F.app.openProfile(p); } }, [
        h('div', { 'class': 'profile-avatar', style: 'background:hsl(' + U.hue(p.name) + ',45%,38%)' }, (p.name || '?')[0].toUpperCase()),
        h('div', { 'class': 'profile-name' }, p.name),
        h('div', { 'class': 'profile-type' }, TYPE_LABEL[p.type] || '')
      ]);
      b._profile = p;
      return b;
    }

    function render() {
      U.empty(row);
      S.profiles.forEach(function (p) { row.appendChild(tile(p)); });
      row.appendChild(U.btn('profile-tile add' + (S.profiles.length ? '' : ' default-focus'), { onclick: function () { F.app.go('profileEdit', {}); } }, [
        h('div', { 'class': 'profile-avatar add' }, U.icon('plus')),
        h('div', { 'class': 'profile-name' }, t('addProfile')),
        h('div', { 'class': 'profile-type' }, 'Xtream · M3U')
      ]));
      row.appendChild(U.btn('profile-tile demo', {
        onclick: function () {
          var demo = null;
          S.profiles.forEach(function (p) { if (p.type === 'demo') demo = p; });
          if (!demo) { demo = { id: 'demo', type: 'demo', name: t('demoProfile') }; S.upsertProfile(demo); }
          F.app.openProfile(demo);
        }
      }, [
        h('div', { 'class': 'profile-avatar demo' }, U.icon('play')),
        h('div', { 'class': 'profile-name' }, t('tryDemo')),
        h('div', { 'class': 'profile-type' }, t('tryDemoSub'))
      ]));
    }

    el.appendChild(h('div', { 'class': 'login-hero' }, [
      h('div', { 'class': 'login-logo' }, [h('span', { 'class': 'brand-mark big' }), h('span', {}, 'Flimmer')]),
      h('div', { 'class': 'login-claim' }, t('claim')),
      h('div', { 'class': 'login-question' }, S.profiles.length ? t('whoWatches') : t('welcomeStart'))
    ]));
    el.appendChild(row);
    el.appendChild(h('div', { 'class': 'login-note' }, t('playerNote')));
    el.appendChild(UIhints());
    render();

    function UIhints() { return F.ui.hints([['ok', t('open')], ['green', t('edit')], ['red', t('delete')]]); }

    return {
      el: el,
      focusDefault: function () {
        var d = row.querySelector('.profile-tile');
        var active = null;
        U.$$('.profile-tile', row).forEach(function (x) { if (x._profile && x._profile.id === S.activeId) active = x; });
        F.nav.focus(active || d);
      },
      onKey: function (k) {
        var a = document.activeElement;
        if (!a || !a._profile) return false;
        var p = a._profile;
        if (k === 'GREEN' && p.type !== 'demo') { F.app.go('profileEdit', { profile: p }); return true; }
        if (k === 'RED') {
          F.ui.confirm({ title: t('deleteProfileQ', { name: p.name }), text: t('deleteProfileText'), ok: t('delete'), danger: true, focusCancel: true }).then(function (ok) {
            if (!ok) return;
            S.removeProfile(p.id);
            render();
            F.nav.focusFirst(el);
          });
          return true;
        }
        return false;
      },
      onShow: function (first) { if (!first) { render(); } },
      onBack: function () { F.app.askExit(); return true; }
    };
  };

  /* ---------- Profil anlegen / bearbeiten ---------- */
  F.views.profileEdit = function (params) {
    var orig = params.profile || null;
    var p = Object.assign({ id: U.uid(), type: 'xtream', name: '', server: '', username: '', password: '', url: '', epgUrl: '' }, orig || {});
    var el = h('div', { 'class': 'profile-edit' });
    el.appendChild(C.header(orig ? t('editProfile') : t('addProfile')));
    var card = h('div', { 'class': 'form-card' });
    el.appendChild(card);

    function field(label, key, opts) {
      opts = opts || {};
      var input = h('input', {
        'class': 'focusable input', tabindex: '-1', type: opts.password ? 'password' : 'text', value: p[key] || '',
        placeholder: opts.placeholder || '', spellcheck: 'false', autocomplete: 'off', autocapitalize: 'off'
      });
      input.addEventListener('input', function () {
        p[key] = input.value.trim();
        if (key === 'server' || key === 'url') autoDetect(input.value);
      });
      input._onEnter = function () { F.nav.move('DOWN', input); };
      var wrap = h('label', { 'class': 'field' }, [h('span', { 'class': 'field-label' }, label), input, opts.extra || null]);
      wrap._input = input;
      return wrap;
    }

    var typeRow = h('div', { 'class': 'segmented' });
    var bodyBox = h('div', { 'class': 'form-fields' });
    var status = h('div', { 'class': 'form-status' });
    var showPw = false;

    function autoDetect(v) {
      var x = F.providers.parseXtreamLink(v);
      if (x) {
        p.type = 'xtream'; p.server = x.server; p.username = x.username; p.password = x.password;
        status.className = 'form-status ok';
        status.textContent = t('linkDetected');
        renderType();
        renderFields(true);
        F.nav.focus(card.querySelector('.form-buttons .button'));
      }
    }

    function renderType() {
      U.empty(typeRow);
      [['xtream', 'Xtream Codes'], ['m3u', 'M3U-Playlist']].forEach(function (o) {
        typeRow.appendChild(U.btn('seg' + (p.type === o[0] ? ' on' : ''), { onclick: function () { p.type = o[0]; renderType(); renderFields(); F.nav.focus(typeRow.querySelector('.seg.on')); } }, o[1]));
      });
    }

    function renderFields(keepFocus) {
      U.empty(bodyBox);
      bodyBox.appendChild(field(t('profileName'), 'name', { placeholder: t('profileNamePh') }));
      if (p.type === 'xtream') {
        bodyBox.appendChild(field(t('serverUrl'), 'server', { placeholder: 'http://server.example:8080' }));
        bodyBox.appendChild(field(t('username'), 'username'));
        var pw = field(t('password'), 'password', { password: !showPw });
        var toggle = U.btn('pw-toggle', {
          onclick: function () { showPw = !showPw; pw._input.type = showPw ? 'text' : 'password'; toggle.textContent = t(showPw ? 'hide' : 'show'); }
        }, t(showPw ? 'hide' : 'show'));
        bodyBox.appendChild(h('div', { 'class': 'field-row' }, [pw, toggle]));
        bodyBox.appendChild(field(t('epgUrlOpt'), 'epgUrl', { placeholder: t('epgUrlXtreamPh') }));
      } else {
        bodyBox.appendChild(field(t('playlistUrl'), 'url', { placeholder: 'http://…/playlist.m3u' }));
        bodyBox.appendChild(field(t('epgUrlOpt'), 'epgUrl', { placeholder: 'http://…/epg.xml(.gz)' }));
      }
      if (!keepFocus) status.textContent = '';
    }

    function validate() {
      if (!p.name) p.name = p.type === 'xtream' ? (p.username || 'Xtream') : 'M3U';
      if (p.type === 'xtream') {
        if (!p.server || !p.username || !p.password) return t('fillAllFields');
        p.server = F.providers.normalizeServer(p.server);
      } else if (!p.url) return t('fillPlaylist');
      return null;
    }

    function save() {
      var err = validate();
      if (err) { status.className = 'form-status error'; status.textContent = err; return; }
      var loader = F.ui.loader(t('checking'));
      var prov = F.providers.create(p);
      var test;
      if (p.type === 'xtream') {
        test = prov.account().then(function (a) {
          if (a.status && a.status !== 'active') { var e = new Error(a.status); e.kind = a.status === 'expired' ? 'expired' : 'banned'; throw e; }
          return a;
        });
      } else {
        test = prov.test().then(function (res) { return F.db.set('lib:' + p.id, { ts: Date.now(), data: res }); });
      }
      test.then(function () {
        loader.close();
        if (orig && p.type === 'xtream' && (orig.server !== p.server || orig.username !== p.username)) F.db.del('lib:' + p.id);
        if (orig && orig.epgUrl !== p.epgUrl) F.db.del('xmltv:' + p.id);
        delete p.lastError;
        S.upsertProfile(p);
        F.ui.toast(t('connected'));
        F.app.openProfile(p);
      }, function (e) {
        loader.close();
        var kind = F.providers.errKind(e);
        status.className = 'form-status error';
        status.textContent = t('err_' + kind) + (e && e.status ? ' (HTTP ' + e.status + ')' : '');
        if (kind === 'network' && !U.isWebOS()) status.textContent += ' ' + t('corsHint');
      });
    }

    card.appendChild(h('div', { 'class': 'form-section-title' }, t('connectionType')));
    card.appendChild(typeRow);
    card.appendChild(bodyBox);
    card.appendChild(status);
    card.appendChild(h('div', { 'class': 'modal-buttons form-buttons' }, [
      U.btn('button primary', { onclick: save }, t('saveConnect')),
      U.btn('button', { onclick: function () { F.app.back(); } }, t('cancel'))
    ]));
    card.appendChild(h('div', { 'class': 'form-privacy' }, [U.icon('lock'), h('span', {}, t('privacyNote'))]));

    renderType();
    renderFields();

    return {
      el: el,
      focusDefault: function () { F.nav.focus(typeRow.querySelector('.seg.on')); }
    };
  };
})();
