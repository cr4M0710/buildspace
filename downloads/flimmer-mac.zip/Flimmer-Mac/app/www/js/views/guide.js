/* Flimmer – TV-Guide (EPG-Raster über mehrere Stunden und Sender) */
(function () {
  'use strict';
  var U = F.util, h = U.h, S = F.store, C = F.vc, t = function (k, v) { return F.t(k, v); };
  var MIN = 60000, SLOT = 30 * MIN, SPAN = 180 * MIN, DAY = 86400000;

  F.views.guide = function (params) {
    params = params || {};
    var el = h('div', { 'class': 'guide' });
    var hdrExtra = h('span');
    el.appendChild(C.header(t('tvGuide'), hdrExtra));
    var ruler = h('div', { 'class': 'g-ruler' });
    var rowsEl = h('div', { 'class': 'g-rows' });
    var nowLine = h('div', { 'class': 'g-nowline' });
    var detail = h('div', { 'class': 'g-detail' });
    el.appendChild(detail);
    el.appendChild(ruler);
    el.appendChild(h('div', { 'class': 'g-rows-wrap' }, [rowsEl, nowLine]));
    el.appendChild(F.ui.hints([['ok', t('guideOk')], ['red', t('details')], ['green', t('category')], ['yellow', t('now')], ['blue', t('day')], ['ch', t('page')]]));

    var st = {
      catId: params.catId && params.catId.indexOf('__') !== 0 ? params.catId : (params.catId || '__all'),
      items: [], row: 0, top: 0, winStart: 0, tCur: Date.now(), prog: null
    };

    function floor30(ts) { return Math.floor(ts / SLOT) * SLOT; }
    function setCat(id) {
      st.catId = id;
      st.items = F.lib.items('live', id);
      st.row = 0; st.top = 0;
      var name = id === '__all' ? t('allChannels') : id === '__fav' ? t('favorites') : F.lib.catName('live', id);
      hdrExtra.textContent = name;
    }
    function goNow() {
      st.tCur = Date.now();
      st.winStart = floor30(st.tCur) - SLOT;
      st.prog = null;
    }

    function dims() {
      var rem = U.rem();
      var chanW = 22 * rem;
      var w = rowsEl.clientWidth || (window.innerWidth - 4 * rem);
      var rowH = 6 * rem;
      var vis = Math.max(1, Math.floor((rowsEl.clientHeight || 600) / rowH));
      return { chanW: chanW, ppm: (w - chanW) / (SPAN / MIN), rowH: rowH, vis: vis, w: w };
    }

    function progsFor(it) {
      var l = F.epg.peek(it);
      if (l === null && F.epg.mode === 'short') F.epg.get(it);
      return l;
    }

    /** Sendung an Zeitpunkt (oder nächstliegende im Fenster) */
    function progAt(list, ts) {
      if (!list || !list.length) return null;
      var best = null;
      for (var i = 0; i < list.length; i++) {
        var p = list[i];
        if (p.start <= ts && p.end > ts) return p;
        if (p.end > st.winStart && p.start < st.winStart + SPAN) {
          if (!best || Math.abs(p.start - ts) < Math.abs(best.start - ts)) best = p;
        }
      }
      return best;
    }

    function render() {
      var d = dims();
      var ws = st.winStart, we = ws + SPAN;
      // Zeitleiste
      U.empty(ruler);
      ruler.appendChild(h('div', { 'class': 'g-ruler-day', style: 'width:' + d.chanW + 'px' }, U.fmtDate(ws)));
      for (var s = ws; s < we; s += SLOT) {
        ruler.appendChild(h('div', { 'class': 'g-slot', style: 'left:' + (d.chanW + (s - ws) / MIN * d.ppm) + 'px;width:' + (SLOT / MIN * d.ppm) + 'px' }, U.fmtTime(s)));
      }
      // Jetzt-Linie
      var now = Date.now();
      if (now >= ws && now < we) { nowLine.style.display = ''; nowLine.style.left = (d.chanW + (now - ws) / MIN * d.ppm) + 'px'; }
      else nowLine.style.display = 'none';

      // sichtbare Zeilen
      if (st.row < st.top) st.top = st.row;
      if (st.row >= st.top + d.vis) st.top = st.row - d.vis + 1;
      U.empty(rowsEl);
      if (!st.items.length) { rowsEl.appendChild(C.empty(t('noChannels'), '', 'guide')); renderDetail(null, null); return; }
      var focusEl = null;
      for (var r = st.top; r < Math.min(st.items.length, st.top + d.vis + 1); r++) {
        var it = st.items[r];
        var row = h('div', { 'class': 'g-row' + (r === st.row ? ' cur' : ''), style: 'top:' + ((r - st.top) * d.rowH) + 'px;height:' + d.rowH + 'px' });
        row.appendChild(h('div', { 'class': 'g-chan', style: 'width:' + d.chanW + 'px' }, [
          S.settings.showNumbers ? h('span', { 'class': 'g-num' }, String(it.num)) : null,
          S.settings.showLogos ? U.img(F.lib.logo(it), U.logoSvg(it.name), 'g-logo') : null,
          h('span', { 'class': 'g-name' }, it.name),
          it.archive ? U.icon('archive', 'g-arch') : null
        ]));
        var list = progsFor(it);
        var any = false;
        var focusedProg = r === st.row ? (st.prog && list && list.indexOf(st.prog) >= 0 ? st.prog : progAt(list, st.tCur)) : null;
        if (r === st.row) st.prog = focusedProg;
        (list || []).forEach(function (p) {
          if (p.end <= ws || p.start >= we) return;
          any = true;
          var x0 = Math.max(p.start, ws), x1 = Math.min(p.end, we);
          var cls = 'g-prog focusable' + (p.end <= now ? ' past' : p.start <= now ? ' live' : '') + (p.end <= now && it.archive ? ' archive' : '');
          var cell = h('div', { 'class': cls, tabindex: '-1', style: 'left:' + (d.chanW + (x0 - ws) / MIN * d.ppm) + 'px;width:' + Math.max(4, (x1 - x0) / MIN * d.ppm - 4) + 'px' }, [
            h('div', { 'class': 'g-prog-title' }, p.title),
            h('div', { 'class': 'g-prog-time' }, U.fmtTime(p.start) + ' – ' + U.fmtTime(p.end))
          ]);
          (function (rr, pp) {
            cell.addEventListener('mouseenter', function () { if (st.row !== rr || st.prog !== pp) { st.row = rr; st.prog = pp; st.tCur = Math.max(pp.start, ws) + MIN; render(); } });
            cell.addEventListener('click', function () { st.row = rr; st.prog = pp; activate(); });
          })(r, p);
          if (r === st.row && p === focusedProg) focusEl = cell;
          row.appendChild(cell);
        });
        if (!any) {
          var noCell = h('div', { 'class': 'g-prog empty focusable', tabindex: '-1', style: 'left:' + d.chanW + 'px;width:' + (d.w - d.chanW - 4) + 'px' }, h('div', { 'class': 'g-prog-title' }, list === null ? t('epgLoading') : t('noEpg')));
          (function (rr) { noCell.addEventListener('click', function () { st.row = rr; st.prog = null; activate(); }); })(r);
          if (r === st.row) focusEl = noCell;
          row.appendChild(noCell);
        }
        rowsEl.appendChild(row);
      }
      if (focusEl && F.nav.top() && F.nav.top().root === el) { try { focusEl.focus(); } catch (e) { /* */ } }
      renderDetail(st.items[st.row], st.prog);
    }

    function renderDetail(it, p) {
      U.empty(detail);
      if (!it) return;
      if (!p) { detail.appendChild(h('div', { 'class': 'g-detail-title' }, it.name)); return; }
      var now = Date.now();
      var badge = p.start <= now && p.end > now ? h('span', { 'class': 'badge live' }, t('liveNow')) : p.end <= now && it.archive ? h('span', { 'class': 'badge archive' }, t('archive')) : null;
      detail.appendChild(h('div', { 'class': 'g-detail-title' }, [p.title, badge]));
      detail.appendChild(h('div', { 'class': 'g-detail-meta' }, it.name + '  ·  ' + U.fmtDate(p.start) + '  ' + U.fmtTime(p.start) + ' – ' + U.fmtTime(p.end) + '  ·  ' + U.fmtMinutes((p.end - p.start) / MIN)));
      if (p.desc) detail.appendChild(h('div', { 'class': 'g-detail-desc' }, p.desc));
    }

    function activate() {
      var it = st.items[st.row], p = st.prog, now = Date.now();
      if (!it) return;
      if (!p || (p.start <= now && p.end > now)) { C.playChannel(it, st.items); return; }
      if (p.end <= now) {
        if (it.archive) F.lib.unlock('live', it.cat).then(function (ok) { if (ok) F.player.playCatchup(it, p); });
        else C.progInfo(it, p);
        return;
      }
      C.progInfo(it, p);
    }

    function moveH(dir) {
      var it = st.items[st.row];
      var list = it ? progsFor(it) : null;
      var p = st.prog;
      if (!list || !list.length || !p) {
        st.winStart += dir * 60 * MIN; st.tCur += dir * 60 * MIN; render(); return;
      }
      var i = list.indexOf(p) + dir;
      if (i < 0 || i >= list.length) { st.winStart += dir * 60 * MIN; render(); return; }
      var np = list[i];
      st.prog = np;
      if (np.start < st.winStart) st.winStart = floor30(np.start);
      else if (np.start >= st.winStart + SPAN - 15 * MIN) st.winStart = floor30(np.start) - SLOT;
      st.tCur = Math.max(np.start, st.winStart) + MIN;
      render();
    }

    function moveV(delta) {
      var n = U.clamp(st.row + delta, 0, st.items.length - 1);
      if (n === st.row) return;
      st.row = n; st.prog = null;
      render();
    }

    var unlisten = F.epg.listen(U.debounce(function () { if (!el.classList.contains('hidden')) render(); }, 150));
    rowsEl.addEventListener('wheel', function (e) { e.preventDefault(); moveV(e.deltaY > 0 ? 1 : -1); });

    setCat(st.catId);
    goNow();
    var timer = setInterval(function () { if (!el.classList.contains('hidden')) render(); }, 60000);

    return {
      el: el,
      focusDefault: function () { render(); },
      onShow: function () { render(); },
      onKey: function (k) {
        var d = dims();
        switch (k) {
          case 'UP': moveV(-1); return true;
          case 'DOWN': moveV(1); return true;
          case 'LEFT': moveH(-1); return true;
          case 'RIGHT': moveH(1); return true;
          case 'CH_UP': moveV(-d.vis); return true;
          case 'CH_DOWN': moveV(d.vis); return true;
          case 'ENTER': activate(); return true;
          case 'RED': case 'INFO': if (st.prog) C.progInfo(st.items[st.row], st.prog); return true;
          case 'YELLOW': goNow(); render(); return true;
          case 'GREEN':
            var opts = F.lib.cats('live').filter(function (c) { return !c.locked; }).map(function (c) { return { label: c.name, value: c.id, sub: c.count !== undefined ? String(c.count) : '' }; });
            F.ui.select({ title: t('category'), options: opts, current: st.catId }).then(function (v) { if (v !== undefined) { setCat(v); render(); } });
            return true;
          case 'BLUE':
            var base = new Date(); base.setHours(0, 0, 0, 0);
            var dayOpts = [];
            for (var i = -3; i <= 3; i++) dayOpts.push({ label: i === -1 ? t('yesterday') : i === 0 ? t('today') : i === 1 ? t('tomorrow') : U.fmtDate(base.getTime() + i * DAY), value: i });
            F.ui.select({ title: t('day'), options: dayOpts }).then(function (v) {
              if (v === undefined) return;
              if (v === 0) goNow();
              else { var hr = new Date(st.tCur).getHours(); st.tCur = base.getTime() + v * DAY + hr * 3600000; st.winStart = floor30(st.tCur) - SLOT; st.prog = null; }
              render();
            });
            return true;
        }
        return /^[0-9]$/.test(k);
      },
      onEvent: function (e) { if (e === 'resize' || e === 'library') { setCat(st.catId); render(); } },
      destroy: function () { unlisten(); clearInterval(timer); }
    };
  };
})();
