/* Flimmer – Kategorien verwalten: ausblenden, sortieren, umbenennen, sperren */
(function () {
  'use strict';
  var U = F.util, h = U.h, S = F.store, C = F.vc, t = function (k, v) { return F.t(k, v); };

  F.views.categories = function (params) {
    var type = params.type || 'live', mode = params.mode || 'manage';
    var label = { live: t('liveTv'), vod: t('movies'), series: t('series') }[type];
    var el = h('div', { 'class': 'catman' });
    el.appendChild(C.header((mode === 'lock' ? t('lockCats') : t('manageCats')) + ' · ' + label));
    var note = h('div', { 'class': 'catman-note' }, mode === 'lock' ? t('lockCatsNote') : t('manageCatsNote'));
    var listEl = h('div', { 'class': 'catman-list' });
    el.appendChild(note);
    el.appendChild(listEl);
    el.appendChild(F.ui.hints(mode === 'lock'
      ? [['ok', t('toggleLock')], ['back', t('back')]]
      : [['ok', t('toggleVisible')], ['green', t('moveUp')], ['yellow', t('moveDown')], ['blue', t('rename')], ['red', t('resetAll')]]));

    var cats = [];
    var counts = F.lib.counts(type);
    function load() { cats = F.lib.rawCats(type, true); }

    var grid = new F.VGrid({
      container: listEl, rowRem: 4.6, count: 0, margin: 2,
      render: function (i) {
        var c = cats[i];
        var hidden = F.lib.isHidden(type, c.id);
        var locked = F.lib.lockState(type, c.id);
        var renamed = S.p.cats[type].names[c.id];
        return h('div', { 'class': 'catman-row' + (hidden ? ' off' : '') }, [
          h('span', { 'class': 'catman-pos' }, String(i + 1)),
          h('span', { 'class': 'catman-name' }, [renamed || c.name, renamed ? h('span', { 'class': 'catman-orig' }, '(' + c.name + ')') : null]),
          h('span', { 'class': 'catman-count' }, String(counts[c.id] || 0)),
          mode === 'lock'
            ? h('span', { 'class': 'catman-state' + (locked ? ' on' : '') }, [U.icon('lock'), locked ? t('locked') : t('unlocked')])
            : h('span', { 'class': 'catman-state' + (hidden ? '' : ' on') }, [U.icon(hidden ? 'eyeOff' : 'check'), hidden ? t('hidden') : t('visible')])
        ]);
      },
      onSelect: function (i) {
        var c = cats[i];
        if (mode === 'lock') F.lib.setLocked(type, c.id, !F.lib.lockState(type, c.id));
        else F.lib.toggleHidden(type, c.id);
        F.lib._counts = {};
        grid.update(i);
        F.app.emit('library');
      }
    });

    function move(dir) {
      var i = grid.index, j = i + dir;
      if (j < 0 || j >= cats.length) return;
      var tmp = cats[i]; cats[i] = cats[j]; cats[j] = tmp;
      F.lib.setCatOrder(type, cats.map(function (c) { return c.id; }));
      grid.index = j;
      grid.refresh();
      grid.focus();
      F.app.emit('library');
    }

    load();
    grid.count = cats.length;

    return {
      el: el,
      focusDefault: function () { if (grid.count) grid.focus(); },
      onKey: function (k) {
        if (mode === 'lock') return false;
        var c = cats[grid.index];
        if (k === 'GREEN') { move(-1); return true; }
        if (k === 'YELLOW') { move(1); return true; }
        if (k === 'BLUE' && c) {
          F.ui.prompt({ title: t('rename'), sub: c.name, value: S.p.cats[type].names[c.id] || c.name }).then(function (n) {
            if (n === null) return;
            n = n.trim();
            F.lib.renameCat(type, c.id, n && n !== c.name ? n : '');
            grid.update(grid.index);
            F.app.emit('library');
          });
          return true;
        }
        if (k === 'RED') {
          F.ui.confirm({ title: t('resetAll'), text: t('resetCatsText'), ok: t('reset'), danger: true, focusCancel: true }).then(function (ok) {
            if (!ok) return;
            var locked = S.p.cats[type].locked;
            F.lib.resetCats(type);
            S.p.cats[type].locked = locked;
            S.saveP();
            load(); grid.count = cats.length; grid.index = 0; grid.refresh(); grid.focus();
            F.app.emit('library');
          });
          return true;
        }
        return false;
      },
      destroy: function () { grid.destroy(); }
    };
  };
})();
