/* Flimmer – Einstellungen (alle Optionen mit ◀ ▶ änderbar) */
(function () {
  'use strict';
  var U = F.util, h = U.h, S = F.store, C = F.vc, t = function (k, v) { return F.t(k, v); };

  F.views.settings = function (params) {
    var el = h('div', { 'class': 'settings' });
    el.appendChild(C.header(t('settings')));
    var body = h('div', { 'class': 'set-body' });
    var menu = h('div', { 'class': 'set-menu', data: { group: 'set-menu' } });
    var panel = h('div', { 'class': 'set-panel' });
    body.appendChild(menu); body.appendChild(panel);
    el.appendChild(body);
    el.appendChild(F.ui.hints([['lr', t('change')], ['ok', t('select')], ['back', t('back')]]));

    function opts(list) { return list.map(function (x) { return { value: x[0], label: x[1] }; }); }
    function choice(key, list, o) { o = o || {}; return { kind: 'choice', key: key, list: list, label: t('set_' + key), desc: o.desc || F.t('setd_' + key, null, ''), after: o.after }; }
    function toggle(key, o) { o = o || {}; return { kind: 'toggle', key: key, label: t('set_' + key), desc: o.desc || F.t('setd_' + key, null, ''), after: o.after }; }
    function action(label, fn, o) { o = o || {}; return { kind: 'action', label: label, desc: o.desc || '', fn: fn, value: o.value, danger: o.danger }; }
    function info(label, value) { return { kind: 'info', label: label, value: value }; }

    var reEpg = function () { F.epg.reset(); };
    var look = function () { F.app.applySettings(); F.app.emit('settings'); };

    function sections() {
      var acc = F.lib.account || {};
      var prof = S.profile() || {};
      var accents = Object.keys(F.app.ACCENTS).map(function (k) { return { value: k, label: t('accent_' + k), color: F.app.ACCENTS[k] }; });
      return [
        { id: 'look', icon: 'settings', title: t('sec_look'), rows: [
          choice('theme', opts([['dark', t('theme_dark')], ['midnight', t('theme_midnight')], ['oled', t('theme_oled')], ['light', t('theme_light')]]), { after: look }),
          choice('accent', accents, { after: look }),
          choice('fontSize', opts([['s', 'S'], ['m', 'M'], ['l', 'L'], ['xl', 'XL']]), { after: look }),
          choice('uiScale', opts([[85, '85 %'], [90, '90 %'], [100, '100 %'], [110, '110 %'], [120, '120 %']]), { after: look }),
          toggle('animations', { after: look })
        ] },
        { id: 'live', icon: 'live', title: t('sec_live'), rows: [
          choice('liveLayout', opts([['list', t('layout_list')], ['compact', t('layout_compact')], ['grid', t('layout_grid')]])),
          toggle('showLogos'), toggle('showNumbers'), toggle('preview'), toggle('previewAuto'),
          choice('epgOffset', opts([-12, -6, -3, -2, -1, 0, 1, 2, 3, 6, 12].map(function (n) { return [n, (n > 0 ? '+' : '') + n + ' h']; })), { after: reEpg }),
          choice('epgSource', opts([['auto', t('epg_auto')], ['xmltv', t('epg_xmltv')]]), { after: reEpg }),
          choice('liveFormat', opts([['m3u8', 'HLS (.m3u8)'], ['ts', 'MPEG-TS (.ts)']])),
          action(t('reloadEpg'), function () { F.epg.reset(); if (F.epg.mode === 'xmltv') F.epg.loadXml(true); F.ui.toast(t('epgReloading')); }),
          action(t('manageCatsLive'), function () { F.app.go('categories', { type: 'live' }); })
        ] },
        { id: 'vod', icon: 'movie', title: t('sec_vod'), rows: [
          choice('tileSize', opts([['s', t('size_s')], ['m', t('size_m')], ['l', t('size_l')]])),
          choice('sort', opts(['default', 'new', 'az', 'za', 'rating', 'year'].map(function (s) { return [s, t('sort_' + s)]; }))),
          toggle('autoNext'),
          choice('nextCountdown', opts([[5, '5 s'], [10, '10 s'], [15, '15 s'], [20, '20 s'], [30, '30 s']])),
          action(t('manageCatsVod'), function () { F.app.go('categories', { type: 'vod' }); }),
          action(t('manageCatsSeries'), function () { F.app.go('categories', { type: 'series' }); })
        ] },
        { id: 'player', icon: 'play', title: t('sec_player'), rows: [
          choice('engine', opts([['auto', t('engine_auto')], ['native', t('engine_native')], ['mpegts', 'mpegts.js']])),
          choice('buffer', opts([['small', t('buffer_small')], ['normal', t('buffer_normal')], ['large', t('buffer_large')]])),
          choice('aspect', opts(['auto', '16:9', '4:3', 'zoom', 'fill'].map(function (a) { return [a, t('ar_' + a.replace(':', ''))]; })), { after: function () { F.player.setAspect(S.settings.aspect); } }),
          choice('seekStep', opts([[10, '10 s'], [15, '15 s'], [30, '30 s'], [60, '60 s']])),
          choice('osdTime', opts([[3, '3 s'], [5, '5 s'], [8, '8 s'], [12, '12 s']]))
        ] },
        { id: 'general', icon: 'list', title: t('sec_general'), rows: [
          choice('lang', opts([['de', 'Deutsch'], ['en', 'English']]), { after: function () { look(); rebuild(); } }),
          choice('clock', opts([['24h', '24 h (20:15)'], ['12h', '12 h (8:15 PM)']])),
          choice('start', opts([['home', t('start_home')], ['live', t('start_live')], ['last', t('start_last')]])),
          choice('refresh', opts([['start', t('refresh_start')], ['6h', t('refresh_6h')], ['12h', t('refresh_12h')], ['24h', t('refresh_24h')], ['manual', t('refresh_manual')]])),
          action(t('refreshNow'), function () { F.lib.refresh(false); }, { value: F.lib.loadedAt ? t('lastUpdate', { d: U.fmtDate(F.lib.loadedAt) + ' ' + U.fmtTime(F.lib.loadedAt) }) : '' }),
          action(t('clearCache'), function () {
            F.db.clear().then(function () { F.ui.toast(t('cacheCleared')); });
          }, { desc: t('clearCacheDesc') })
        ] },
        { id: 'security', icon: 'lock', title: t('sec_security'), rows: [
          action(t('appPin'), appPin, { value: S.settings.appPin ? t('on') : t('off'), desc: t('appPinDesc') }),
          action(t('parentalPin'), parentalPin, { value: S.settings.parentalPin ? t('on') : t('off'), desc: t('parentalPinDesc') }),
          toggle('autoLockAdult'),
          action(t('lockedCatsLive'), function () { needParental(function () { F.app.go('categories', { type: 'live', mode: 'lock' }); }); }),
          action(t('lockedCatsVod'), function () { needParental(function () { F.app.go('categories', { type: 'vod', mode: 'lock' }); }); }),
          action(t('lockedCatsSeries'), function () { needParental(function () { F.app.go('categories', { type: 'series', mode: 'lock' }); }); })
        ] },
        { id: 'account', icon: 'user', title: t('sec_account'), rows: [
          info(t('profile'), prof.name + '  (' + ({ xtream: 'Xtream Codes', m3u: 'M3U', demo: 'Demo' }[prof.type] || '') + ')'),
          acc.m3u || acc.demo ? null : info(t('status'), t('status_' + (acc.status || 'active'))),
          acc.exp ? info(t('expires'), U.fmtDate(acc.exp, true)) : null,
          acc.maxCons ? info(t('maxConnections'), (acc.activeCons || 0) + ' / ' + acc.maxCons) : null,
          acc.trial ? info(t('trial'), t('yes')) : null,
          info(t('server'), prof.type === 'xtream' ? prof.server : prof.type === 'm3u' ? shortUrl(prof.url) : 'Demo'),
          info(t('content'), F.lib.data ? t('contentCounts', { a: F.lib.data.live.items.length, b: F.lib.data.vod.items.length, c: F.lib.data.series.items.length }) : '–'),
          action(t('switchProfile'), function () { F.player.stop(); F.app.reset('login'); }),
          prof.type !== 'demo' ? action(t('editProfile'), function () { F.app.go('profileEdit', { profile: prof }); }) : null,
          action(t('logoutWipe'), function () {
            F.ui.confirm({ title: t('logoutWipe'), text: t('logoutWipeText'), ok: t('deleteAll'), danger: true, focusCancel: true }).then(function (ok) {
              if (!ok) return;
              F.player.stop();
              S.wipe().then(function () { F.app.applySettings(); F.app.reset('login'); F.ui.toast(t('wiped')); });
            });
          }, { danger: true })
        ].filter(Boolean) },
        { id: 'backup', icon: 'archive', title: t('sec_backup'), rows: [
          action(t('exportSettings'), function () { doExport(false); }, { desc: t('exportDesc') }),
          action(t('exportWithCreds'), function () {
            F.ui.confirm({ title: t('exportWithCreds'), text: t('exportCredsWarn'), ok: t('export') }).then(function (ok) { if (ok) doExport(true); });
          }),
          action(t('importSettings'), doImport, { desc: t('importDesc') })
        ] },
        { id: 'about', icon: 'play', title: t('sec_about'), rows: [
          info('Flimmer', t('version') + ' 1.1.0'),
          info(t('aboutPlayer'), t('aboutPlayerText')),
          info(t('aboutPrivacy'), t('aboutPrivacyText')),
          info(t('keys'), t('keysText')),
          info(t('libraries'), 'mpegts.js (Apache-2.0), pako (MIT)')
        ] }
      ];
    }

    function shortUrl(u) { u = String(u || ''); return u.length > 60 ? u.slice(0, 57) + '…' : u; }

    function needParental(fn) {
      if (!S.settings.parentalPin) { F.ui.toast(t('setParentalFirst')); return; }
      F.ui.pin({ title: t('parentalPin'), check: function (v) { return v === S.settings.parentalPin; } }).then(function (v) { if (v) fn(); });
    }

    function pinFlow(key, title) {
      var cur = S.settings[key];
      var verify = cur ? F.ui.pin({ title: title, sub: t('pinCurrent'), check: function (v) { return v === cur; } }) : Promise.resolve('ok');
      return verify.then(function (ok) {
        if (!ok) return;
        if (!cur) return F.ui.newPin(title).then(function (p) { if (p) { S.set(key, p); F.ui.toast(t('pinSet')); render(); } });
        return F.ui.select({ title: title, options: [{ label: t('pinChange'), value: 'change' }, { label: t('pinRemove'), value: 'remove' }] }).then(function (v) {
          if (v === 'change') return F.ui.newPin(title).then(function (p) { if (p) { S.set(key, p); F.ui.toast(t('pinSet')); render(); } });
          if (v === 'remove') { S.set(key, ''); F.ui.toast(t('pinRemoved')); render(); }
        });
      });
    }
    function appPin() { pinFlow('appPin', t('appPin')); }
    function parentalPin() { pinFlow('parentalPin', t('parentalPin')).then(function () { F.lib.unlocked = {}; F.app.emit('library'); }); }

    function doExport(withCreds) {
      var code = S.exportCode(withCreds);
      var box = h('div', { 'class': 'export-box' }, [
        h('p', { 'class': 'modal-text' }, t('exportText')),
        h('textarea', { 'class': 'input textarea export-code', readonly: true }, code)
      ]);
      var buttons = [{ label: t('download'), value: 'dl', primary: true }];
      F.ui.info({ title: t('exportSettings'), el: box, buttons: buttons }).then(function (v) {
        if (v !== 'dl') return;
        try {
          var a = document.createElement('a');
          a.href = URL.createObjectURL(new Blob([code], { type: 'text/plain' }));
          a.download = 'flimmer-backup.txt';
          document.body.appendChild(a); a.click(); document.body.removeChild(a);
        } catch (e) { F.ui.toast(t('downloadFail'), 'error'); }
      });
    }
    function doImport() {
      F.ui.prompt({ title: t('importSettings'), sub: t('importDesc'), multiline: true, placeholder: t('pasteCode') }).then(function (code) {
        if (!code) return;
        try {
          S.importCode(code);
          F.app.applySettings();
          F.ui.toast(t('imported'));
          rebuild();
        } catch (e) { F.ui.toast(t('importFail'), 'error'); }
      });
    }

    var secs = [], cur = params.section || 'look';

    function valueLabel(r) {
      var v = S.settings[r.key];
      var o = null;
      r.list.forEach(function (x) { if (String(x.value) === String(v)) o = x; });
      return o ? o.label : String(v);
    }

    function setChoice(r, v) {
      var num = typeof S.DEFAULTS[r.key] === 'number';
      S.set(r.key, num ? Number(v) : v);
      if (r.after) r.after();
      F.app.emit('settings');
    }

    function cycle(r, dir) {
      var v = S.settings[r.key], i = 0;
      r.list.forEach(function (x, j) { if (String(x.value) === String(v)) i = j; });
      var n = i + dir;
      if (n < 0 || n >= r.list.length) return false;
      setChoice(r, r.list[n].value);
      return true;
    }

    function rowEl(r) {
      var val;
      if (r.kind === 'choice') {
        val = h('span', { 'class': 'set-choice' }, [h('i', { 'class': 'arr' }, '‹'), h('span', { 'class': 'set-val' }, [
          r.key === 'accent' ? h('span', { 'class': 'swatch', style: 'background:' + F.app.ACCENTS[S.settings.accent] }) : null, valueLabel(r)
        ]), h('i', { 'class': 'arr' }, '›')]);
      } else if (r.kind === 'toggle') {
        val = h('span', { 'class': 'switch' + (S.settings[r.key] ? ' on' : '') }, h('span', { 'class': 'knob' }));
      } else if (r.kind === 'action') {
        val = h('span', { 'class': 'set-action' }, [r.value ? h('span', { 'class': 'set-val' }, r.value) : null, h('i', { 'class': 'arr' }, '›')]);
      } else {
        val = h('span', { 'class': 'set-info' }, r.value || '');
      }
      var cls = 'set-row' + (r.kind === 'info' ? ' info' : '') + (r.danger ? ' danger' : '');
      var attrs = {
        onclick: function () {
          if (r.kind === 'choice') {
            F.ui.select({ title: r.label, options: r.list, current: S.settings[r.key] }).then(function (v) { if (v !== undefined) { setChoice(r, v); redraw(r); } });
          } else if (r.kind === 'toggle') { S.set(r.key, !S.settings[r.key]); if (r.after) r.after(); F.app.emit('settings'); redraw(r); }
          else if (r.kind === 'action') r.fn();
        }
      };
      var e = r.kind === 'info' ? h('div', { 'class': cls + ' focusable', tabindex: '-1' }) : U.btn(cls, attrs);
      e.appendChild(h('div', { 'class': 'set-text' }, [h('div', { 'class': 'set-label' }, r.label), r.desc ? h('div', { 'class': 'set-desc' }, r.desc) : null]));
      e.appendChild(val);
      e._row = r;
      return e;
    }

    function redraw(r) {
      var old = null;
      U.$$('.set-row', panel).forEach(function (x) { if (x._row === r) old = x; });
      if (!old) return;
      var n = rowEl(r);
      var hadFocus = old === document.activeElement;
      panel.querySelector('.set-rows').replaceChild(n, old);
      if (hadFocus) F.nav.focus(n, { noScroll: true });
    }

    function render() {
      var keepFocusRow = panel.contains(document.activeElement) && document.activeElement._row ? document.activeElement._row.label : null;
      secs = sections();
      var s = null;
      secs.forEach(function (x) { if (x.id === cur) s = x; });
      if (!s) s = secs[0];
      U.empty(panel);
      panel.appendChild(h('div', { 'class': 'panel-title' }, s.title));
      var rows = h('div', { 'class': 'set-rows' });
      s.rows.forEach(function (r) { rows.appendChild(rowEl(r)); });
      panel.appendChild(rows);
      if (keepFocusRow) U.$$('.set-row', rows).forEach(function (x) { if (x._row.label === keepFocusRow) F.nav.focus(x, { noScroll: true }); });
    }

    function renderMenu() {
      U.empty(menu);
      secs = sections();
      secs.forEach(function (s) {
        var b = U.btn('set-menu-item' + (s.id === cur ? ' on' : ''), { onclick: function () { var f = panel.querySelector('.set-row:not(.info)') || panel.querySelector('.set-row'); if (f) F.nav.focus(f); } }, [U.icon(s.icon), s.title]);
        b._sec = s.id;
        b.addEventListener('focus', function () {
          if (cur === s.id) return;
          cur = s.id;
          U.$$('.set-menu-item', menu).forEach(function (x) { x.classList.toggle('on', x._sec === cur); });
          render();
        });
        menu.appendChild(b);
      });
    }

    function rebuild() {
      var f = document.activeElement && document.activeElement._sec;
      renderMenu(); render();
      if (f) U.$$('.set-menu-item', menu).forEach(function (x) { if (x._sec === f) F.nav.focus(x); });
    }

    renderMenu(); render();

    return {
      el: el,
      focusDefault: function () { F.nav.focus(menu.querySelector('.on')); },
      onShow: function (first) { if (!first) render(); },
      onKey: function (k) {
        var a = document.activeElement;
        if (a && a._row && a._row.kind === 'choice' && (k === 'LEFT' || k === 'RIGHT')) {
          if (cycle(a._row, k === 'LEFT' ? -1 : 1)) { redraw(a._row); return true; }
          if (k === 'RIGHT') return true;
          F.nav.focus(menu.querySelector('.on'));
          return true;
        }
        if (a && a._row && a._row.kind === 'toggle' && (k === 'RIGHT')) { a.click(); return true; }
        if (a && panel.contains(a) && k === 'LEFT') { F.nav.focus(menu.querySelector('.on')); return true; }
        if (a && menu.contains(a) && k === 'RIGHT') { var f = panel.querySelector('.set-row'); if (f) F.nav.focus(f); return true; }
        return false;
      },
      onBack: function () {
        var a = document.activeElement;
        if (a && panel.contains(a)) { F.nav.focus(menu.querySelector('.on')); return true; }
        return false;
      },
      onEvent: function (e) { if (e === 'account' || e === 'library') render(); }
    };
  };
})();
