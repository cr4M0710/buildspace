/* Flimmer – globale Suche über Live-TV, Filme und Serien */
(function () {
  'use strict';
  var U = F.util, h = U.h, S = F.store, C = F.vc, t = function (k, v) { return F.t(k, v); };
  var ICON = { live: 'live', vod: 'movie', series: 'series' };

  F.views.search = function (params) {
    var st = { type: params.type || 'all', q: '', results: [] };
    var el = h('div', { 'class': 'search' });
    el.appendChild(C.header(t('search')));
    var input = h('input', { 'class': 'focusable input search-input', tabindex: '-1', type: 'text', placeholder: t('searchPh'), spellcheck: 'false', autocomplete: 'off' });
    var tabs = h('div', { 'class': 'segmented search-tabs', data: { group: 'stabs' } });
    var recent = h('div', { 'class': 'search-recent', data: { group: 'srecent' } });
    var info = h('div', { 'class': 'search-info' });
    var listEl = h('div', { 'class': 'search-list' });
    el.appendChild(h('div', { 'class': 'search-top' }, [h('div', { 'class': 'search-box' }, [U.icon('search', 'search-ico'), input]), tabs]));
    el.appendChild(recent);
    el.appendChild(info);
    el.appendChild(listEl);
    el.appendChild(F.ui.hints([['ok', t('open')], ['red', t('favorite')], ['back', t('back')]]));

    function renderTabs() {
      U.empty(tabs);
      [['all', t('all')], ['live', t('liveTv')], ['vod', t('movies')], ['series', t('series')]].forEach(function (x) {
        tabs.appendChild(U.btn('seg' + (st.type === x[0] ? ' on' : ''), { onclick: function () { st.type = x[0]; renderTabs(); run(); F.nav.focus(tabs.querySelector('.on')); } }, x[1]));
      });
    }

    function renderRecent() {
      U.empty(recent);
      if (st.q || !S.p.searches.length) { recent.classList.add('hidden'); return; }
      recent.classList.remove('hidden');
      recent.appendChild(h('span', { 'class': 'search-recent-label' }, t('recentSearches')));
      S.p.searches.slice(0, 8).forEach(function (q) {
        recent.appendChild(U.btn('chip', { onclick: function () { input.value = q; st.q = q; run(); } }, q));
      });
    }

    var grid = new F.VGrid({
      container: listEl, rowRem: 5.6, count: 0, margin: 2,
      render: function (i) {
        var r = st.results[i], it = r.item;
        var img = r.type === 'live' ? U.img(F.lib.logo(it), U.logoSvg(it.name), 'sr-logo') : U.img(F.lib.poster(it), U.posterSvg(it.name, it.year), 'sr-poster');
        var sub = F.lib.catName(r.type, it.cat);
        if (r.type === 'live') { var nn = F.epg.nowNext(F.epg.peek(it)); if (nn.cur) sub += '  ·  ' + nn.cur.title; }
        else if (it.year) sub += '  ·  ' + it.year;
        return h('div', { 'class': 'sr-row' }, [
          U.icon(ICON[r.type], 'sr-type'), img,
          h('div', { 'class': 'sr-text' }, [h('div', { 'class': 'sr-name' }, it.name), h('div', { 'class': 'sr-sub' }, sub)]),
          S.isFav(r.type, it.id) ? U.icon('starFill', 'sr-fav') : null
        ]);
      },
      onSelect: function (i) { open(st.results[i]); }
    });

    function open(r) {
      if (!r) return;
      remember();
      if (r.type === 'live') {
        var lives = st.results.filter(function (x) { return x.type === 'live'; }).map(function (x) { return x.item; });
        C.playChannel(r.item, lives);
      } else F.app.go('details', { type: r.type, item: r.item });
    }

    function remember() {
      var q = st.q.trim();
      if (q.length < 2) return;
      S.p.searches = [q].concat(S.p.searches.filter(function (x) { return x.toLowerCase() !== q.toLowerCase(); })).slice(0, 12);
      S.saveP();
    }

    function run() {
      st.results = st.q.trim().length ? F.lib.search(st.q, st.type, 300) : [];
      grid.count = st.results.length;
      grid.index = 0;
      listEl.scrollTop = 0;
      grid.refresh();
      info.textContent = st.q.trim() ? (st.results.length ? t('nResults', { n: st.results.length }) : t('noResults', { q: st.q })) : t('searchHint');
      renderRecent();
    }

    var deb = U.debounce(function () { st.q = input.value; run(); }, 300);
    input.addEventListener('input', deb);
    input._onEnter = function () { deb.cancel(); st.q = input.value; run(); remember(); if (grid.count) grid.focus(); };

    renderTabs();
    run();

    return {
      el: el,
      focusDefault: function () { F.nav.focus(input); },
      onKey: function (k) {
        var a = document.activeElement;
        if (k === 'RED' && a && listEl.contains(a)) {
          var r = st.results[grid.index];
          if (r) { var on = S.toggleFav(r.type, r.item.id); F.ui.toast(t(on ? 'favAdded' : 'favRemoved')); grid.update(grid.index); }
          return true;
        }
        return false;
      },
      destroy: function () { grid.destroy(); }
    };
  };
})();
