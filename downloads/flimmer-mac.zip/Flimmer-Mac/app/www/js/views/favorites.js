/* Flimmer – Favoriten (Sender, Filme, Serien) */
(function () {
  'use strict';
  var U = F.util, h = U.h, S = F.store, C = F.vc, t = function (k, v) { return F.t(k, v); };

  F.views.favorites = function () {
    var st = { type: 'live', items: [] };
    var el = h('div', { 'class': 'favorites' });
    el.appendChild(C.header(t('favorites')));
    var tabs = h('div', { 'class': 'segmented fav-tabs', data: { group: 'ftabs' } });
    var gridEl = h('div', { 'class': 'fav-grid' });
    var emptyEl = h('div', { 'class': 'fav-empty hidden' });
    el.appendChild(tabs);
    el.appendChild(gridEl);
    el.appendChild(emptyEl);
    el.appendChild(F.ui.hints([['ok', t('open')], ['red', t('removeFav')]]));

    var grid = new F.VGrid({
      container: gridEl, cols: 6, rowRem: 20, count: 0, margin: 0,
      render: function (i) {
        var it = st.items[i];
        if (st.type === 'live') {
          var nn = F.epg.nowNext(F.epg.peek(it));
          if (!F.epg.peek(it)) F.epg.get(it);
          return h('div', { 'class': 'fav-ch' }, [
            h('div', { 'class': 'fav-ch-logo' }, U.img(F.lib.logo(it), U.logoSvg(it.name))),
            h('div', { 'class': 'fav-ch-name' }, (S.settings.showNumbers ? it.num + '  ' : '') + it.name),
            h('div', { 'class': 'fav-ch-now' }, nn.cur ? nn.cur.title : '')
          ]);
        }
        return C.posterCard(st.type, it);
      },
      onSelect: function (i) {
        var it = st.items[i];
        if (st.type === 'live') C.playChannel(it, st.items);
        else F.app.go('details', { type: st.type, item: it });
      },
      onEdge: function (dir) { if (dir === 'UP') { F.nav.focus(tabs.querySelector('.on')); return true; } return false; }
    });

    function size() {
      var w = gridEl.clientWidth || 1700;
      if (st.type === 'live') { grid.cols = 5; grid.rowRem = 12; }
      else { grid.cols = C.posterCols(); grid.rowRem = (w / grid.cols * 1.5) / U.rem() + 5.2; }
    }

    function load(keepIndex) {
      st.items = F.lib.items(st.type, '__fav');
      var i = grid.index;
      grid.count = st.items.length;
      grid.index = keepIndex ? Math.min(i, Math.max(0, grid.count - 1)) : 0;
      if (!keepIndex) gridEl.scrollTop = 0;
      size();
      grid.refresh();
      emptyEl.classList.toggle('hidden', !!st.items.length);
      if (!st.items.length) U.empty(emptyEl).appendChild(C.empty(t('noFavorites'), st.type === 'live' ? t('noFavoritesHint') : t('noFavoritesHintVod'), 'star'));
    }

    function renderTabs() {
      U.empty(tabs);
      [['live', t('channels')], ['vod', t('movies')], ['series', t('series')]].forEach(function (x) {
        var n = S.p.fav[x[0]].length;
        tabs.appendChild(U.btn('seg' + (st.type === x[0] ? ' on' : ''), {
          onclick: function () { st.type = x[0]; renderTabs(); load(false); F.nav.focus(tabs.querySelector('.on')); }
        }, x[1] + (n ? '  ' + n : '')));
      });
    }

    renderTabs();
    load(false);

    return {
      el: el,
      focusDefault: function () { F.nav.focus(tabs.querySelector('.on')); },
      onShow: function () { renderTabs(); load(true); },
      onKey: function (k) {
        var a = document.activeElement;
        if (k === 'DOWN' && a && tabs.contains(a) && grid.count) { grid.focus(); return true; }
        if (k === 'RED' && a && gridEl.contains(a)) {
          var it = st.items[grid.index];
          if (!it) return true;
          S.toggleFav(st.type, it.id);
          F.ui.toast(t('favRemoved'));
          renderTabs(); load(true);
          if (grid.count) grid.focus(); else F.nav.focus(tabs.querySelector('.on'));
          return true;
        }
        return false;
      },
      onEvent: function (e) { if (e === 'resize' || e === 'progress') load(true); },
      destroy: function () { grid.destroy(); }
    };
  };
})();
