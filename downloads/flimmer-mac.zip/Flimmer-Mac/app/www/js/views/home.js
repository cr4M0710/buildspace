/* Flimmer – Startseite */
(function () {
  'use strict';
  var U = F.util, h = U.h, S = F.store, C = F.vc, t = function (k, v) { return F.t(k, v); };

  F.views.home = function () {
    var el = h('div', { 'class': 'home' });
    var prof = S.profile() || {};
    var acct = h('div', { 'class': 'home-account' });
    el.appendChild(C.header(null, h('div', { 'class': 'header-profile' }, [U.icon('user'), prof.name || ''])));
    var scroll = h('div', { 'class': 'home-scroll' });
    el.appendChild(scroll);

    var tiles = h('div', { 'class': 'home-tiles', data: { group: 'tiles' } });
    scroll.appendChild(tiles);
    var rows = h('div', { 'class': 'home-rows' });
    scroll.appendChild(rows);
    el.appendChild(acct);

    function count(type) { return F.lib.data ? F.lib.data[type].items.length : 0; }

    function bigTile(cls, icon, label, sub, action) {
      return U.btn('home-tile big ' + cls, { onclick: action }, [
        h('div', { 'class': 'home-tile-glow' }),
        U.icon(icon, 'home-tile-ico'),
        h('div', { 'class': 'home-tile-label' }, label),
        h('div', { 'class': 'home-tile-sub' }, sub)
      ]);
    }
    function smallTile(icon, label, action) {
      return U.btn('home-tile small', { onclick: action }, [U.icon(icon, 'home-tile-ico'), h('div', { 'class': 'home-tile-label' }, label)]);
    }

    function renderTiles() {
      U.empty(tiles);
      tiles.appendChild(bigTile('t-live default-focus', 'live', t('liveTv'), t('nChannels', { n: count('live') }), function () { F.app.go('live'); }));
      tiles.appendChild(bigTile('t-movie', 'movie', t('movies'), t('nTitles', { n: count('vod') }), function () { F.app.go('library', { type: 'vod' }); }));
      tiles.appendChild(bigTile('t-series', 'series', t('series'), t('nSeries', { n: count('series') }), function () { F.app.go('library', { type: 'series' }); }));
      var col = h('div', { 'class': 'home-tiles-small' }, [
        smallTile('guide', t('tvGuide'), function () { F.app.go('guide'); }),
        smallTile('star', t('favorites'), function () { F.app.go('favorites'); }),
        smallTile('search', t('search'), function () { F.app.go('search'); }),
        smallTile('settings', t('settings'), function () { F.app.go('settings'); })
      ]);
      tiles.appendChild(col);
    }

    function hrow(title, items) {
      if (!items.length) return null;
      var inner = h('div', { 'class': 'hrow-inner' }, items);
      return h('div', { 'class': 'hrow-wrap' }, [h('div', { 'class': 'row-title' }, title), h('div', { 'class': 'hrow', data: { group: 'row-' + U.hash(title) } }, inner)]);
    }

    function continueCards() {
      return S.continueList().map(function (pr) {
        var m = pr.meta || {};
        var poster = m.poster || U.posterSvg(m.title || '', '');
        var card = U.btn('cont-card', { onclick: function () { resume(pr); } }, [
          h('div', { 'class': 'cont-img' }, [
            U.img(poster, U.posterSvg(m.title || '', '')),
            h('div', { 'class': 'cont-progress' }, h('div', { style: 'width:' + Math.round(pr.pos / (pr.dur || 1) * 100) + '%' }))
          ]),
          h('div', { 'class': 'cont-title' }, m.title || ''),
          h('div', { 'class': 'cont-sub' }, (m.sub ? m.sub + ' · ' : '') + t('minLeft', { n: Math.max(1, Math.round((pr.dur - pr.pos) / 60)) }))
        ]);
        card._progress = pr;
        return card;
      });
    }

    function resume(pr) {
      var m = pr.meta || {};
      if (m.type === 'vod') {
        var it = F.lib.get('vod', m.id);
        if (!it) { F.ui.toast(t('notAvailable'), 'error'); return; }
        F.lib.unlock('vod', it.cat).then(function (ok) {
          if (!ok) return;
          F.lib.provider.vodInfo(it).catch(function () { return {}; }).then(function (info) { F.player.playVod(it, info, pr.pos); });
        });
      } else if (m.type === 'episode') {
        var s = F.lib.get('series', m.seriesId);
        if (!s) { F.ui.toast(t('notAvailable'), 'error'); return; }
        F.lib.unlock('series', s.cat).then(function (ok) {
          if (!ok) return;
          var ld = F.ui.loader(t('loading'));
          U.always(F.lib.provider.seriesInfo(s), ld.close).then(function (info) {
            var all = [];
            info.seasons.forEach(function (se) { all = all.concat(se.episodes); });
            var idx = -1;
            all.forEach(function (e, i) { if (e.id === m.epId) idx = i; });
            if (idx < 0) { F.ui.toast(t('notAvailable'), 'error'); return; }
            F.player.playEpisode(Object.assign({}, s, { poster: info.info.poster || s.poster }), all, idx, pr.pos);
          }, function () { F.ui.toast(t('loadFailed'), 'error'); });
        });
      }
    }

    function channelCards(ids, kind) {
      var list = ids.map(function (id) { return F.lib.get('live', id); }).filter(function (it) { return it && !F.lib.isLocked('live', it.cat); }).slice(0, 20);
      return list.map(function (it) {
        var nn = F.epg.nowNext(F.epg.peek(it));
        if (!F.epg.peek(it)) F.epg.get(it);
        var c = U.btn('chan-card', { onclick: function () { C.playChannel(it, list); } }, [
          h('div', { 'class': 'chan-card-logo' }, U.img(F.lib.logo(it), U.logoSvg(it.name))),
          h('div', { 'class': 'chan-card-name' }, it.name),
          h('div', { 'class': 'chan-card-now' }, nn.cur ? nn.cur.title : '')
        ]);
        c._channel = it; c._kind = kind;
        return c;
      });
    }

    function renderRows() {
      U.empty(rows);
      [hrow(t('continueWatching'), continueCards()),
        hrow(t('recentChannels'), channelCards(S.p.recentLive, 'recent')),
        hrow(t('favoriteChannels'), channelCards(S.p.fav.live, 'fav'))
      ].forEach(function (r) { if (r) rows.appendChild(r); });
      if (!rows.children.length) rows.appendChild(h('div', { 'class': 'home-tip' }, t('homeTip')));
    }

    function renderAccount() {
      var a = F.lib.account;
      U.empty(acct);
      if (!a) return;
      var parts = [];
      if (a.demo) parts.push(t('demoMode'));
      else if (a.m3u) parts.push(t('m3uPlaylist'));
      else {
        parts.push(t('status_' + (a.status || 'active')));
        if (a.exp) parts.push(t('validUntil', { d: U.fmtDate(a.exp, true) }));
        else parts.push(t('unlimited'));
        if (a.maxCons) parts.push(t('connections', { a: a.activeCons || 0, b: a.maxCons }));
      }
      acct.appendChild(h('span', { 'class': 'acct-dot ' + (a.status === 'active' || a.m3u || a.demo ? 'ok' : 'bad') }));
      acct.appendChild(h('span', {}, parts.join('  ·  ')));
      acct.appendChild(F.ui.hints([['red', t('removeFromList')], ['blue', t('search')]]));
    }

    renderTiles(); renderRows(); renderAccount();
    var unlisten = F.epg.listen(U.debounce(function () { if (!el.classList.contains('hidden')) { var a = document.activeElement; if (!rows.contains(a)) renderRows(); } }, 800));

    return {
      el: el,
      focusDefault: function () { F.nav.focus(tiles.querySelector('.default-focus')); },
      onShow: function (first) {
        if (!first) {
          var a = document.activeElement;
          renderTiles(); renderRows();
          if (!document.body.contains(a)) F.nav.focus(tiles.querySelector('.default-focus'));
        }
      },
      onEvent: function (e) {
        if (e === 'account') renderAccount();
        if (e === 'library' || e === 'progress') { renderTiles(); renderRows(); }
      },
      onKey: function (k) {
        var a = document.activeElement;
        if (k === 'BLUE') { F.app.go('search'); return true; }
        if (k === 'RED' && a) {
          if (a._progress) { delete S.p.progress[a._progress.key]; S.saveP(); renderRows(); F.nav.focus(tiles.querySelector('.default-focus')); return true; }
          if (a._channel) {
            var rid = String(a._channel.id);
            if (a._kind === 'fav') S.toggleFav('live', rid);
            else S.p.recentLive = S.p.recentLive.filter(function (x) { return x !== rid; });
            S.saveP(); renderRows(); F.nav.focus(tiles.querySelector('.default-focus'));
            return true;
          }
        }
        return false;
      },
      onBack: function () { F.app.askExit(); return true; },
      destroy: function () { unlisten(); }
    };
  };
})();
