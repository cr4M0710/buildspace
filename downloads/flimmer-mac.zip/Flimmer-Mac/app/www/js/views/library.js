/* Flimmer – Filme & Serien: Kategorien + Poster-Raster */
(function () {
  'use strict';
  var U = F.util, h = U.h, S = F.store, C = F.vc, t = function (k, v) { return F.t(k, v); };
  var SORTS = ['default', 'new', 'az', 'za', 'rating', 'year'];

  F.views.library = function (params) {
    var type = params.type || 'vod';
    var el = h('div', { 'class': 'library' });
    var sortLbl = h('span', { 'class': 'header-sort' });
    el.appendChild(C.header(type === 'vod' ? t('movies') : t('series'), sortLbl));
    var body = h('div', { 'class': 'lib-body' });
    el.appendChild(body);
    var st = { catId: params.catId || '__all', items: [] };

    var cats = C.catPanel({
      type: type, active: st.catId,
      onFocusCat: U.debounce(function (c) { if (c && !c.locked && c.id !== st.catId) load(c.id); }, 350),
      onPick: function (c) {
        F.lib.unlock(type, c.id).then(function (ok) { if (!ok) return; if (c.locked) cats.reload(); load(c.id); if (grid.count) grid.focus(); });
      },
      onEdge: function (dir) { if (dir === 'RIGHT' && grid.count) { grid.focus(); return true; } return false; }
    });
    body.appendChild(cats.el);

    var right = h('div', { 'class': 'lib-right' });
    var title = h('div', { 'class': 'panel-title' });
    var gridEl = h('div', { 'class': 'poster-grid' });
    var emptyEl = h('div', { 'class': 'lib-empty hidden' });
    right.appendChild(title); right.appendChild(gridEl); right.appendChild(emptyEl);
    body.appendChild(right);
    el.appendChild(F.ui.hints([['ok', t('details')], ['red', t('favorite')], ['green', t('sort')], ['yellow', t('manageCats')], ['blue', t('search')]]));

    var grid = new F.VGrid({
      container: gridEl, cols: C.posterCols(), rowRem: 20, count: 0, margin: 0,
      render: function (i) { return C.posterCard(type, st.items[i]); },
      onSelect: function (i) { open(st.items[i]); },
      onEdge: function (dir) { if (dir === 'LEFT') { cats.grid.focus(); return true; } return false; }
    });

    function sizeGrid() {
      grid.cols = C.posterCols();
      var colW = (gridEl.clientWidth || 1200) / grid.cols;
      grid.rowRem = (colW * 1.5) / U.rem() + 5.2;
    }

    function load(id) {
      st.catId = id;
      cats.setActive(id);
      st.items = F.lib.items(type, id, S.settings.sort);
      var name = '';
      cats.cats.forEach(function (c) { if (c.id === id) name = c.name; });
      title.textContent = name + '  ·  ' + st.items.length;
      sortLbl.textContent = t('sortBy') + ': ' + t('sort_' + S.settings.sort);
      grid.count = st.items.length;
      grid.index = 0;
      gridEl.scrollTop = 0;
      sizeGrid();
      grid.refresh();
      emptyEl.classList.toggle('hidden', !!st.items.length);
      if (!st.items.length) U.empty(emptyEl).appendChild(C.empty(id === '__fav' ? t('noFavorites') : t('nothingHere'), id === '__fav' ? t('noFavoritesHintVod') : '', 'star'));
    }

    function open(it) {
      if (!it) return;
      F.lib.unlock(type, it.cat).then(function (ok) { if (ok) F.app.go('details', { type: type, item: it }); });
    }

    load(st.catId);

    return {
      el: el,
      focusDefault: function () { if (grid.count) grid.focus(); else cats.grid.focus(); },
      onKey: function (k) {
        var a = document.activeElement;
        if (k === 'RED' && a && gridEl.contains(a)) {
          var it = st.items[grid.index];
          if (!it) return true;
          var on = S.toggleFav(type, it.id);
          F.ui.toast(t(on ? 'favAdded' : 'favRemoved'));
          if (st.catId === '__fav') { var i = grid.index; load('__fav'); grid.index = Math.min(i, grid.count - 1); grid.refresh(); if (grid.count) grid.focus(); else cats.grid.focus(); }
          else grid.update(grid.index);
          return true;
        }
        if (k === 'GREEN') {
          F.ui.select({ title: t('sortBy'), options: SORTS.map(function (s) { return { label: t('sort_' + s), value: s }; }), current: S.settings.sort }).then(function (v) {
            if (!v) return;
            S.set('sort', v);
            var inGrid = gridEl.contains(document.activeElement);
            load(st.catId);
            if (inGrid && grid.count) grid.focus();
          });
          return true;
        }
        if (k === 'YELLOW') { F.app.go('categories', { type: type }); return true; }
        if (k === 'BLUE') { F.app.go('search', { type: type }); return true; }
        return false;
      },
      onShow: function (first) {
        if (first) { sizeGrid(); grid.refresh(); return; }
        cats.reload();
        var i = grid.index;
        st.items = F.lib.items(type, st.catId, S.settings.sort);
        grid.count = st.items.length;
        grid.index = Math.min(i, Math.max(0, grid.count - 1));
        sizeGrid();
        grid.refresh();
      },
      onEvent: function (e) {
        if (e === 'library') { cats.reload(); load(st.catId); }
        if (e === 'resize') { cats.grid.refresh(); sizeGrid(); grid.refresh(); }
        if (e === 'progress') grid.refresh();
      },
      destroy: function () { grid.destroy(); cats.grid.destroy(); }
    };
  };
})();
