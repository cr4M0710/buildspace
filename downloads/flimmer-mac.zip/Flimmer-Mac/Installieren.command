#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  Flimmer – Installation für macOS (Apple-Chip, M1 bis M5)
#  Doppelklick genügt. Ein erneuter Doppelklick aktualisiert die App.
# ─────────────────────────────────────────────────────────────
cd "$(dirname "$0")" || exit 1
SRC="$(pwd)"
APP_NAME="Flimmer"
BUNDLE_ID="de.buildspaceos.flimmer"
VERSION="1.1.0"
ELECTRON="38.2.2"
ELECTRON_SHA="323d805132db09f92b9766ff5f6845ce106c22a543b0f7a4a663d5270a76db22"
ELECTRON_URL="https://github.com/electron/electron/releases/download/v$ELECTRON/electron-v$ELECTRON-darwin-arm64.zip"
CACHE="$HOME/Library/Caches/Flimmer"
LOGDIR="$HOME/Library/Logs/Flimmer"; mkdir -p "$LOGDIR" "$CACHE" 2>/dev/null
LOG="$LOGDIR/installation.txt"

say()  { printf "\n\033[1m%s\033[0m\n" "$1"; }
ok()   { printf "  \033[32m✓\033[0m %s\n" "$1"; }
fail() {
  printf "\n  \033[31m✗ %s\033[0m\n" "$1"
  osascript -e "display alert \"Flimmer konnte nicht installiert werden\" message \"$1\" as critical" >/dev/null 2>&1
  echo; read -r -p "Enter zum Schließen …" _; exit 1
}

clear
printf "\033[1;33m  Flimmer %s\033[0m\n  IPTV-Player für Xtream Codes und M3U\n" "$VERSION"
echo "=== Installation $(date) ===" > "$LOG"

[ -f "$SRC/app/main.js" ] || fail "Der Ordner „app“ fehlt. Bitte das ZIP vollständig entpacken."
[ "$(uname -m)" = "arm64" ] || fail "Diese Version ist für Macs mit Apple-Chip (M1 bis M5). Dein Mac hat einen Intel-Prozessor."

# ── 1. Laufzeit laden ────────────────────────────────────────
say "1/4  Laufzeit laden (einmalig ca. 110 MB)"
ZIP="$CACHE/electron-v$ELECTRON-darwin-arm64.zip"
sum_ok() { [ -f "$ZIP" ] && [ "$(shasum -a 256 "$ZIP" | cut -d' ' -f1)" = "$ELECTRON_SHA" ]; }
if sum_ok; then
  ok "bereits vorhanden"
else
  rm -f "$ZIP"
  curl -fL --progress-bar --retry 3 -o "$ZIP" "$ELECTRON_URL" 2>&1 || fail "Download fehlgeschlagen. Besteht eine Internetverbindung?"
  sum_ok || { rm -f "$ZIP"; fail "Die geladene Datei ist beschädigt. Bitte erneut versuchen."; }
  ok "geladen und geprüft"
fi

# ── 2. App zusammensetzen ────────────────────────────────────
say "2/4  App zusammensetzen"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
ditto -x -k "$ZIP" "$TMP" >>"$LOG" 2>&1 || fail "Entpacken fehlgeschlagen."
BUILD="$TMP/$APP_NAME.app"
mv "$TMP/Electron.app" "$BUILD" || fail "Entpacken unvollständig."
RES="$BUILD/Contents/Resources"
rm -f "$RES/default_app.asar"
ditto "$SRC/app" "$RES/app" || fail "Programmdateien konnten nicht kopiert werden."
cp "$SRC/Flimmer.icns" "$RES/electron.icns"
PL="$BUILD/Contents/Info.plist"
/usr/libexec/PlistBuddy -c "Set :CFBundleName $APP_NAME" "$PL"
/usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName $APP_NAME" "$PL"
/usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier $BUNDLE_ID" "$PL"
/usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString $VERSION" "$PL"
/usr/libexec/PlistBuddy -c "Set :CFBundleVersion $VERSION" "$PL"
/usr/libexec/PlistBuddy -c "Delete :NSMicrophoneUsageDescription" "$PL" >/dev/null 2>&1
/usr/libexec/PlistBuddy -c "Delete :NSCameraUsageDescription" "$PL" >/dev/null 2>&1
/usr/libexec/PlistBuddy -c "Add :NSLocalNetworkUsageDescription string 'Flimmer verbindet sich mit dem Server deines IPTV-Anbieters.'" "$PL" >/dev/null 2>&1
xattr -cr "$BUILD" 2>/dev/null
codesign --force --deep --sign - "$BUILD" >>"$LOG" 2>&1 || fail "Die App ließ sich nicht signieren (siehe ~/Library/Logs/Flimmer)."
ok "App fertig"

# ── 3. In „Programme“ legen ──────────────────────────────────
say "3/4  In „Programme“ legen"
DEST="/Applications"
[ -w "$DEST" ] || { DEST="$HOME/Applications"; mkdir -p "$DEST"; }
APP="$DEST/$APP_NAME.app"
osascript -e "tell application \"$APP_NAME\" to quit" >/dev/null 2>&1; sleep 1
rm -rf "$APP"
ditto "$BUILD" "$APP" || fail "Kopieren nach $DEST fehlgeschlagen."
xattr -cr "$APP" 2>/dev/null
touch "$APP"
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$APP" >/dev/null 2>&1
ok "$APP"

# ── 4. Starten ───────────────────────────────────────────────
say "4/4  Flimmer starten"
open "$APP" && ok "Flimmer läuft – viel Spaß!"
printf "\n  Tipp: Flimmer im Dock behalten (Rechtsklick aufs Symbol › Optionen › Im Dock behalten).\n"
printf "  Dieses Fenster kannst du schließen.\n\n"
