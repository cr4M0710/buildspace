# Startdatei von Heft2PDF.
# Bindet die installierten Bausteine ein, leitet Ausgaben ins Protokoll und
# startet die Oberfläche. Läuft innerhalb des App-Prozesses „Heft2PDF“,
# damit macOS die Freigaben dieser App zuordnet (nicht „Python“).
import datetime
import os
import site
import subprocess
import sys
import traceback

HOME = os.environ.get("HEFT2PDF_HOME") or os.path.expanduser(
    "~/Library/Application Support/Heft2PDF")
VER = f"python{sys.version_info.major}.{sys.version_info.minor}"
site.addsitedir(os.path.join(HOME, "venv", "lib", VER, "site-packages"))
sys.path.insert(0, os.path.join(HOME, "app"))

try:
    log = open(os.path.join(HOME, "protokoll.txt"), "a", buffering=1, encoding="utf-8")
    sys.stdout = sys.stderr = log
except OSError:
    pass

print(f"\n--- Start {datetime.datetime.now():%Y-%m-%d %H:%M:%S} · "
      f"{sys.executable} · Python {sys.version.split()[0]}")

try:
    import heft2pdf_app
    heft2pdf_app.main()
except Exception:  # noqa: BLE001
    traceback.print_exc()
    subprocess.run(["/usr/bin/osascript", "-e",
                    'display alert "Heft2PDF konnte nicht starten" message '
                    '"Details stehen in ~/Library/Application Support/Heft2PDF/protokoll.txt"'])
finally:
    try:
        sys.stdout.flush()
    except Exception:  # noqa: BLE001
        pass
    os._exit(0)
