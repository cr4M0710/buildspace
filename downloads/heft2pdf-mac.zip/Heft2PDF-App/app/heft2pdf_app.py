#!/usr/bin/env python3
"""
Heft2PDF – Mac-App, die ein digitales Heft automatisch durchblättert,
jede Seite in voller Retina-Auflösung aufnimmt und als PDF speichert.

Aufbau
  • Oberfläche: ui/index.html (läuft in einem nativen Fenster über pywebview)
  • Aufnahme:   macOS-eigenes `screencapture`
  • Blättern:   Tastendruck oder Mausklick über Quartz-Events
  • PDF:        eigener Schreiber, der die JPEG-Seiten direkt einbettet
                (kein Neukomprimieren, kaum Arbeitsspeicher)
  • Texterkennung: Apple Vision (läuft auf dem Mac, ohne Internet); der
                erkannte Text liegt unsichtbar über jeder Seite, dadurch ist
                die PDF durchsuchbar und Text lässt sich markieren/kopieren
"""
import concurrent.futures
import base64
import ctypes
import datetime
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

from PIL import Image, ImageChops

APP_NAME = "Heft2PDF"
VERSION = "2.3"
APP_DIR = Path(__file__).resolve().parent
UI_FILE = APP_DIR / "ui" / "index.html"
ICON_FILE = APP_DIR / "ui" / "icon.png"
SUPPORT_DIR = Path.home() / "Library" / "Application Support" / APP_NAME
SETTINGS_FILE = SUPPORT_DIR / "settings.json"
DEFAULT_OUT = Path.home() / "Documents" / APP_NAME
TMP_DIR = Path(tempfile.gettempdir()) / "heft2pdf"

SCREENCAPTURE = "/usr/sbin/screencapture"
KEYCODES = {"right": 124, "left": 123, "down": 125, "pagedown": 121, "space": 49}

# Dateigröße / Qualität der Seiten
QUALITY = {
    "best":     {"jpeg": 92, "subsampling": 0, "max_h": None},
    "balanced": {"jpeg": 85, "subsampling": 2, "max_h": None},
    "small":    {"jpeg": 75, "subsampling": 2, "max_h": 1800},
}


# ═════════════════════════════════════════════════════════════ Bildvergleich
def changed_pixels(a, b, width=1000, threshold=40):
    """Anzahl deutlich veränderter Pixel zwischen zwei Bildern (verkleinert, grau)."""
    if a.size != b.size:
        return 10**9
    h = max(1, round(width * a.height / a.width))
    sa = a.convert("L").resize((width, h))
    sb = b.convert("L").resize((width, h))
    diff = ImageChops.difference(sa, sb).point(lambda p: 255 if p > threshold else 0)
    return diff.histogram()[255]


def same(a, b, tolerance=2):
    return changed_pixels(a, b) <= tolerance


def data_url(img, width=320, quality=78):
    im = img.copy()
    if im.width > width:
        im = im.resize((width, max(1, round(width * im.height / im.width))), Image.LANCZOS)
    buf = io.BytesIO()
    im.convert("RGB").save(buf, "JPEG", quality=quality)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()


# ═════════════════════════════════════════════════════════════ PDF-Schreiber
def _pdf_text(s):
    return "<FEFF" + s.encode("utf-16-be").hex().upper() + ">"


def text_layer(words, page_w, page_h):
    """Unsichtbarer Text (Darstellungsmodus 3) passend über den erkannten Wörtern.

    words: Liste von (text, x, y, w, h) – Anteile 0..1, Ursprung unten links
    (so liefert Apple Vision die Rahmen, und so rechnet auch PDF).
    Courier hat feste Zeichenbreiten (600/1000 em); mit der horizontalen
    Skalierung (Tz) passt jedes Wort genau in seinen Rahmen. Die Schrift ist
    unsichtbar, daher spielt ihr Aussehen keine Rolle.
    """
    out = ["BT 3 Tr"]
    for text, x, y, w, h in words:
        text = text.strip()
        if not text or w <= 0 or h <= 0:
            continue
        size = max(1.0, h * page_h)
        width = w * page_w
        natural = 0.6 * size * len(text)
        scale = min(1000.0, max(5.0, 100.0 * width / natural))
        data = (text + " ").encode("cp1252", errors="replace").hex().upper()
        out.append(f"/F1 {size:.2f} Tf {scale:.1f} Tz 1 0 0 1 {x * page_w:.2f} "
                   f"{y * page_h + 0.22 * size:.2f} Tm <{data}> Tj")
    out.append("ET")
    return "\n".join(out) if len(out) > 2 else ""


def write_pdf(jpeg_paths, out_path, page_w, page_h, title="", texts=None):
    """Schreibt eine PDF, in der jede JPEG-Datei unverändert eine Seite füllt.

    texts (optional): je Seite die erkannten Wörter für die Textebene.
    """
    offsets = {}
    n = len(jpeg_paths)
    font_num = 3 + 3 * n
    info_num = font_num + 1
    texts = texts or [None] * n
    with open(out_path, "wb") as f:
        def obj(num, body, stream=None):
            offsets[num] = f.tell()
            f.write(f"{num} 0 obj\n".encode())
            f.write(body.encode() if isinstance(body, str) else body)
            if stream is not None:
                f.write(b"\nstream\n")
                f.write(stream)
                f.write(b"\nendstream")
            f.write(b"\nendobj\n")

        f.write(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        obj(1, "<< /Type /Catalog /Pages 2 0 R >>")
        kids = []
        for i, path in enumerate(jpeg_paths):
            page, image, content = 3 + 3 * i, 4 + 3 * i, 5 + 3 * i
            with Image.open(path) as im:
                w, h = im.size
                cs = "/DeviceGray" if im.mode == "L" else "/DeviceRGB"
            data = Path(path).read_bytes()
            obj(image, f"<< /Type /XObject /Subtype /Image /Width {w} /Height {h} "
                       f"/ColorSpace {cs} /BitsPerComponent 8 /Filter /DCTDecode "
                       f"/Length {len(data)} >>", data)
            draw = f"q {page_w:.2f} 0 0 {page_h:.2f} 0 0 cm /Im0 Do Q"
            layer = text_layer(texts[i], page_w, page_h) if texts[i] else ""
            if layer:
                draw += "\n" + layer
            draw = draw.encode("latin-1")
            obj(content, f"<< /Length {len(draw)} >>", draw)
            obj(page, f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {page_w:.2f} {page_h:.2f}] "
                      f"/Resources << /XObject << /Im0 {image} 0 R >> /Font << /F1 {font_num} 0 R >> >> "
                      f"/Contents {content} 0 R >>")
            kids.append(f"{page} 0 R")
        obj(2, f"<< /Type /Pages /Kids [{' '.join(kids)}] /Count {n} >>")
        obj(font_num, "<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>")
        obj(info_num, f"<< /Title {_pdf_text(title)} /Producer {_pdf_text(APP_NAME + ' ' + VERSION)} >>")

        xref = f.tell()
        size = info_num + 1
        f.write(f"xref\n0 {size}\n0000000000 65535 f \n".encode())
        for num in range(1, size):
            f.write(f"{offsets[num]:010d} 00000 n \n".encode())
        f.write(f"trailer\n<< /Size {size} /Root 1 0 R /Info {info_num} 0 R >>\n"
                f"startxref\n{xref}\n%%EOF\n".encode())
    return out_path


# ═════════════════════════════════════════════════════════════ Texterkennung
class TextRecognizer:
    """Texterkennung mit Apple Vision (macOS 11+), Deutsch und Englisch."""

    def __init__(self):
        self.error = ""
        try:
            import Vision  # noqa: F401  (pyobjc-framework-Vision)
            import objc  # noqa: F401
            from Foundation import NSURL  # noqa: F401
            self.available = True
        except Exception as exc:  # noqa: BLE001
            self.available = False
            self.error = str(exc)

    def __call__(self, path):
        import objc
        import Vision
        from Foundation import NSURL

        with objc.autorelease_pool():
            url = NSURL.fileURLWithPath_(str(path))
            handler = Vision.VNImageRequestHandler.alloc().initWithURL_options_(url, None)
            req = Vision.VNRecognizeTextRequest.alloc().init()
            req.setRecognitionLevel_(Vision.VNRequestTextRecognitionLevelAccurate)
            req.setUsesLanguageCorrection_(True)
            try:
                req.setRecognitionLanguages_(["de-DE", "en-US"])
            except Exception:  # noqa: BLE001
                pass
            ok = handler.performRequests_error_([req], None)
            if isinstance(ok, tuple):
                ok = ok[0]
            if not ok:
                return []
            words = []
            for obs in req.results() or []:
                cands = obs.topCandidates_(1)
                if not cands:
                    continue
                cand = cands[0]
                line = str(cand.string())
                found = []
                for m in re.finditer(r"\S+", line):
                    try:
                        res = cand.boundingBoxForRange_error_((m.start(), m.end() - m.start()), None)
                        box = res[0] if isinstance(res, tuple) else res
                        if box is None:
                            continue
                        b = box.boundingBox()
                        found.append((m.group(), b.origin.x, b.origin.y, b.size.width, b.size.height))
                    except Exception:  # noqa: BLE001
                        found = []
                        break
                if not found:   # Ersatz: ganze Zeile in ihrem Rahmen
                    b = obs.boundingBox()
                    found = [(line, b.origin.x, b.origin.y, b.size.width, b.size.height)]
                words.extend(found)
            return words


# ═════════════════════════════════════════════════════════════ Aufnahme-Ablauf
class StopRequested(Exception):
    pass


class CaptureJob:
    """Blättert durch, nimmt jede Seite auf und baut am Ende die PDF.

    Alle Mac-spezifischen Dinge (Aufnahme, Blättern, Stopp-Prüfung) werden als
    Funktionen übergeben – so lässt sich der Ablauf auch ohne Mac testen.
    """

    def __init__(self, grab, turn, stop_check, report, *, delay, max_pages,
                 out_dir, name, keep_images, quality, page_size, ocr=None):
        self.grab, self.turn, self.stop_check, self.report = grab, turn, stop_check, report
        self.delay = delay
        self.max_pages = max_pages
        self.out_dir = Path(out_dir)
        self.name = name
        self.keep_images = keep_images
        self.quality = QUALITY.get(quality, QUALITY["balanced"])
        self.page_w, self.page_h = page_size
        self.pages = []
        self.thumb = None
        self.ocr = ocr
        self.ocr_jobs = []
        self.pool = concurrent.futures.ThreadPoolExecutor(max_workers=1) if ocr else None

    # -- Hilfen
    def check(self):
        if self.stop_check():
            raise StopRequested()

    def sleep(self, seconds):
        end = time.time() + seconds
        while time.time() < end:
            self.check()
            time.sleep(min(0.1, max(0, end - time.time())))

    def wait_stable(self, img, max_wait=6.0, interval=0.4):
        deadline = time.time() + max_wait
        while time.time() < deadline:
            self.sleep(interval)
            nxt = self.grab()
            if same(img, nxt):
                return nxt
            img = nxt
        return img

    def next_page(self, prev):
        for _ in range(2):                         # zweiter Versuch bei langsamem Laden
            self.check()
            self.turn()
            self.sleep(self.delay)
            deadline = time.time() + max(3.0, self.delay * 3)
            candidate = self.grab()
            while same(candidate, prev) and time.time() < deadline:
                self.sleep(0.3)
                candidate = self.grab()
            if not same(candidate, prev):
                return self.wait_stable(candidate)
        return None

    def save_page(self, img, number, folder):
        q = self.quality
        if q["max_h"] and img.height > q["max_h"]:
            w = round(img.width * q["max_h"] / img.height)
            img = img.resize((w, q["max_h"]), Image.LANCZOS)
        path = folder / f"Seite_{number:03d}.jpg"
        img.convert("RGB").save(path, "JPEG", quality=q["jpeg"],
                                subsampling=q["subsampling"], optimize=True)
        return path

    # -- Hauptablauf
    def run(self):
        self.out_dir.mkdir(parents=True, exist_ok=True)
        pdf_path = unique_path(self.out_dir / f"{self.name}.pdf")
        pages_dir = (unique_path(self.out_dir / f"{self.name} – Seiten") if self.keep_images
                     else Path(tempfile.mkdtemp(prefix="heft2pdf_", dir=ensure_tmp())))
        pages_dir.mkdir(parents=True, exist_ok=True)
        reason = "end"
        try:
            self.report("status", {"text": "Erste Seite wird aufgenommen …"})
            img = self.wait_stable(self.grab())
            number = 1
            while True:
                self.pages.append(self.save_page(img, number, pages_dir))
                if self.pool:   # Texterkennung läuft nebenher, während umgeblättert wird
                    self.ocr_jobs.append(self.pool.submit(self.ocr, self.pages[-1]))
                if number == 1:
                    self.thumb = data_url(img, 360)
                self.report("page", {"page": number, "thumb": data_url(img, 300)})
                if self.max_pages and number >= self.max_pages:
                    reason = "count"
                    break
                self.report("status", {"text": "Blättere um …"})
                nxt = self.next_page(img)
                if nxt is None:
                    reason = "end"
                    break
                img, number = nxt, number + 1
        except StopRequested:
            reason = "stopped"

        if not self.pages:
            shutil.rmtree(pages_dir, ignore_errors=True)
            return {"ok": False, "reason": reason, "pages": 0}

        texts, ocr_ok = None, False
        if self.pool:
            texts = []
            total = len(self.ocr_jobs)
            for i, job in enumerate(self.ocr_jobs, 1):
                if not job.done():
                    self.report("status", {"text": f"Text wird erkannt: Seite {i} von {total} …"})
                try:
                    texts.append(job.result())
                except Exception as exc:  # noqa: BLE001
                    print(f"Texterkennung Seite {i}: {exc}")
                    texts.append(None)
            self.pool.shutdown(wait=False)
            ocr_ok = any(texts)

        self.report("status", {"text": f"PDF wird erstellt ({len(self.pages)} Seiten) …"})
        write_pdf(self.pages, pdf_path, self.page_w, self.page_h, title=self.name, texts=texts)
        if not self.keep_images:
            shutil.rmtree(pages_dir, ignore_errors=True)
        size = pdf_path.stat().st_size
        size_txt = (f"{size / 1_048_576:.1f} MB" if size >= 1_048_576
                    else f"{max(1, round(size / 1024))} KB").replace(".", ",")
        return {"ok": True, "reason": reason, "pages": len(self.pages),
                "pdf": str(pdf_path), "file": pdf_path.name,
                "folder": str(pages_dir) if self.keep_images else "",
                "size": size_txt, "thumb": self.thumb, "ocr": ocr_ok}


def unique_path(path):
    path = Path(path)
    if not path.exists():
        return path
    stem, suffix = path.stem, path.suffix
    i = 2
    while True:
        cand = path.with_name(f"{stem} ({i}){suffix}")
        if not cand.exists():
            return cand
        i += 1


def ensure_tmp():
    TMP_DIR.mkdir(parents=True, exist_ok=True)
    return TMP_DIR


def clean_tmp():
    """Reste abgebrochener Aufnahmen entfernen (nur eine App läuft gleichzeitig)."""
    try:
        for d in ensure_tmp().glob("heft2pdf_*"):
            shutil.rmtree(d, ignore_errors=True)
    except Exception:  # noqa: BLE001
        pass


def clean_name(name):
    name = re.sub(r'[\\/:*?"<>|]+', " ", name or "").strip().strip(".")
    return name or "Heft " + datetime.datetime.now().strftime("%Y-%m-%d %H.%M")


# ═════════════════════════════════════════════════════════════ macOS-Anbindung
class Mac:
    def __init__(self):
        import AppKit
        import Quartz
        from PyObjCTools import AppHelper
        self.AK, self.Q, self.AH = AppKit, Quartz, AppHelper
        self._cg = ctypes.cdll.LoadLibrary(
            "/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics")
        self._ax = ctypes.cdll.LoadLibrary(
            "/System/Library/Frameworks/ApplicationServices.framework/ApplicationServices")
        for lib, fn in ((self._cg, "CGPreflightScreenCaptureAccess"),
                        (self._cg, "CGRequestScreenCaptureAccess"),
                        (self._ax, "AXIsProcessTrusted")):
            try:
                getattr(lib, fn).restype = ctypes.c_bool
            except AttributeError:
                pass

    # -- Hauptthread (AppKit verlangt das für Fenster/App-Aktionen)
    def on_main(self, fn, timeout=5):
        done, box = threading.Event(), {}

        def work():
            try:
                box["v"] = fn()
            except Exception as exc:  # noqa: BLE001
                box["e"] = exc
            finally:
                done.set()

        self.AH.callAfter(work)
        done.wait(timeout)
        return box.get("v")

    def app(self):
        return self.AK.NSApplication.sharedApplication()

    def set_dock_icon(self, path):
        def f():
            img = self.AK.NSImage.alloc().initWithContentsOfFile_(str(path))
            if img:
                self.app().setApplicationIconImage_(img)
        self.on_main(f)

    def bundle_path(self):
        try:
            path = str(self.AK.NSBundle.mainBundle().bundlePath())
            return path if path.endswith(".app") else None
        except Exception:  # noqa: BLE001
            return None

    def on_cmd_q(self, callback):
        """⌘Q selbst abfangen. pywebview beendet sonst mit NSApp.stop, das erst
        beim nächsten Ereignis greift – die App hing dann unsichtbar weiter."""
        AK = self.AK
        mask = getattr(AK, "NSEventMaskKeyDown", 1 << 10)
        cmd = getattr(AK, "NSEventModifierFlagCommand", 1 << 20)

        def handler(event):
            try:
                if (event.modifierFlags() & cmd) and str(event.charactersIgnoringModifiers()).lower() == "q":
                    threading.Thread(target=callback, daemon=True).start()
                    return None
            except Exception:  # noqa: BLE001
                pass
            return event

        self._key_handler = handler   # Referenz halten, sonst räumt Python den Block weg
        self._key_monitor = self.on_main(
            lambda: AK.NSEvent.addLocalMonitorForEventsMatchingMask_handler_(mask, handler))

    # -- Rechte
    def has_screen_permission(self):
        try:
            return bool(self._cg.CGPreflightScreenCaptureAccess())
        except AttributeError:
            return True

    def request_screen_permission(self):
        try:
            self._cg.CGRequestScreenCaptureAccess()
        except AttributeError:
            pass

    def screen_test(self):
        """Winziges Test-Bildschirmfoto über `screencapture`. Das ist ein eigener
        Prozess und fragt macOS jedes Mal neu – er sieht eine frisch erteilte
        Freigabe also sofort, während diese App sie erst nach einem Neustart kennt."""
        path = ensure_tmp() / "test.png"
        try:
            path.unlink(missing_ok=True)
            r = subprocess.run([SCREENCAPTURE, "-x", "-R0,0,8,8", str(path)],
                               capture_output=True, timeout=10)
            return r.returncode == 0 and path.exists() and path.stat().st_size > 0
        except Exception:  # noqa: BLE001
            return False
        finally:
            path.unlink(missing_ok=True)

    def has_accessibility(self):
        try:
            return bool(self._ax.AXIsProcessTrusted())
        except AttributeError:
            return True

    # -- Bildschirm
    def screen_points(self):
        b = self.Q.CGDisplayBounds(self.Q.CGMainDisplayID())
        return float(b.size.width), float(b.size.height)

    def capture(self, path, region=None):
        cmd = [SCREENCAPTURE, "-x", "-t", "png"]
        if region:
            cmd += ["-R", "{x},{y},{w},{h}".format(**{k: round(v) for k, v in region.items()})]
        else:
            cmd += ["-m"]
        path = Path(path)
        path.unlink(missing_ok=True)
        r = subprocess.run(cmd + [str(path)], capture_output=True, timeout=30)
        if r.returncode != 0 or not path.exists():
            raise RuntimeError("Das Bildschirmfoto hat nicht geklappt. Fehlt die Freigabe "
                               "„Bildschirmaufnahme“?")
        with Image.open(path) as im:
            return im.convert("RGB")

    # -- Eingaben
    def press(self, key):
        code = KEYCODES[key]
        for down in (True, False):
            ev = self.Q.CGEventCreateKeyboardEvent(None, code, down)
            self.Q.CGEventPost(self.Q.kCGHIDEventTap, ev)
            time.sleep(0.04)

    def click(self, x, y):
        Q = self.Q
        for etype in (Q.kCGEventMouseMoved, Q.kCGEventLeftMouseDown, Q.kCGEventLeftMouseUp):
            ev = Q.CGEventCreateMouseEvent(None, etype, (x, y), Q.kCGMouseButtonLeft)
            Q.CGEventPost(Q.kCGHIDEventTap, ev)
            time.sleep(0.05)

    def mouse(self):
        loc = self.Q.CGEventGetLocation(self.Q.CGEventCreate(None))
        return loc.x, loc.y

    # -- Apps
    def hide_self(self):
        self.on_main(lambda: self.app().hide_(None))

    def show_self(self):
        def f():
            self.app().unhide_(None)
            self.app().activateIgnoringOtherApps_(True)
        self.on_main(f)

    def frontmost_other_app(self):
        def f():
            a = self.AK.NSWorkspace.sharedWorkspace().frontmostApplication()
            if a is None or a.processIdentifier() == os.getpid():
                return None
            return a
        return self.on_main(f)

    def activate(self, running_app):
        if running_app is None:
            return
        opt = getattr(self.AK, "NSApplicationActivateIgnoringOtherApps", 1 << 1)
        self.on_main(lambda: running_app.activateWithOptions_(opt))

    @staticmethod
    def sound(name="Glass"):
        path = f"/System/Library/Sounds/{name}.aiff"
        if os.path.exists(path):
            subprocess.Popen(["/usr/bin/afplay", path])

    @staticmethod
    def notify(text):
        script = f'display notification "{text}" with title "{APP_NAME}"'
        subprocess.Popen(["/usr/bin/osascript", "-e", script],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    @staticmethod
    def open(path, reveal=False):
        subprocess.Popen(["/usr/bin/open"] + (["-R"] if reveal else []) + [str(path)])


# ═════════════════════════════════════════════════════════════ Einstellungen
def load_settings():
    try:
        return json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def save_settings(data):
    try:
        SUPPORT_DIR.mkdir(parents=True, exist_ok=True)
        SETTINGS_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass


# ═════════════════════════════════════════════════════════════ Schnittstelle zur Oberfläche
MAIN_SIZE = (1140, 780)
MINI_SIZE = (340, 268)


class Api:
    """Alle Methoden ohne Unterstrich sind aus der Oberfläche aufrufbar."""

    def __init__(self, mac):
        self._mac = mac
        self._window = None
        self._target = None
        self._screen = None       # {"pt_w", "pt_h", "px_w", "px_h"}
        self._stop = False
        self._running = False
        self._idle = threading.Event()
        self._idle.set()
        self._quitting = False
        self._last = None
        self._ocr = TextRecognizer()
        self._asked = False
        self._test_usable = None    # klappt der Test ohne Freigabe schon? Dann taugt er nicht

    # -- Start & Rechte
    def init(self):
        s = load_settings()
        s.setdefault("folder", str(DEFAULT_OUT))
        s.setdefault("ocr", True)
        return {"settings": s, "permissions": self.permissions(), "version": VERSION,
                "ocr": self._ocr.available}

    def permissions(self):
        screen = self._mac.has_screen_permission()
        pending = False
        if not screen and self._asked and self._test_usable:
            pending = self._mac.screen_test()
        return {"screen": screen, "access": self._mac.has_accessibility(),
                "screen_pending": pending, "asked": self._asked}

    def open_permission(self, kind):
        if not self._asked:
            self._asked = True
            # Auf älteren macOS-Versionen liefert screencapture auch ohne Freigabe
            # ein Bild (nur Schreibtischhintergrund) – dann verlassen wir uns nicht darauf.
            if not self._mac.has_screen_permission():
                self._test_usable = not self._mac.screen_test()
        if kind == "screen":
            self._mac.request_screen_permission()
            pane = "Privacy_ScreenCapture"
        else:
            pane = "Privacy_Accessibility"
        subprocess.Popen(["/usr/bin/open",
                          f"x-apple.systempreferences:com.apple.preference.security?{pane}"])
        return True

    def restart(self):
        threading.Thread(target=self._quit, kwargs={"restart": True}, daemon=True).start()
        return True

    # -- Beenden (rotes X, ⌘Q, Menü „Beenden“, Dock „Beenden“, Neustart)
    def _on_closing(self):
        """Läuft auf dem Hauptthread, wenn das Fenster schließen oder die App enden
        soll. Wir brechen das Schließen ab und beenden die App selbst sauber."""
        if not self._quitting:
            threading.Thread(target=self._quit, daemon=True).start()
        return False

    def _quit(self, restart=False):
        if self._quitting:
            return
        self._quitting = True
        if self._running:   # laufende Aufnahme: erst die PDF fertig speichern
            self._stop = True
            self._js("status", {"text": "Wird beendet – PDF wird noch gespeichert …"})
            self._idle.wait(600)
        if restart:
            bundle = os.environ.get("HEFT2PDF_BUNDLE") or self._mac.bundle_path()
            if bundle:
                # Neu öffnen, sobald dieser Prozess wirklich beendet ist
                script = (f"while kill -0 {os.getpid()} 2>/dev/null; do sleep 0.2; done; "
                          f'sleep 0.4; /usr/bin/open "{bundle}"')
                subprocess.Popen(["/bin/sh", "-c", script], start_new_session=True,
                                 stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
        print(f"Beendet{' (Neustart)' if restart else ''}")
        try:
            sys.stdout.flush()
        except Exception:  # noqa: BLE001
            pass
        os._exit(0)

    # -- Bildschirm erfassen
    def capture_screen(self):
        try:
            self._mac.hide_self()
            time.sleep(0.9)
            self._target = self._mac.frontmost_other_app()
            img = self._mac.capture(ensure_tmp() / "screen.png")
            pt_w, pt_h = self._mac.screen_points()
            self._screen = {"pt_w": pt_w, "pt_h": pt_h, "px_w": img.width, "px_h": img.height}
            app_name = str(self._target.localizedName()) if self._target else ""
            return {"ok": True, "preview": data_url(img, 1800, 82), **self._screen,
                    "app": app_name}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": str(exc)}
        finally:
            self._mac.show_self()

    def choose_folder(self, current):
        import webview
        res = self._window.create_file_dialog(webview.FileDialog.FOLDER, directory=current or "")
        return res[0] if res else None

    # -- Aufnahme
    def start(self, opts):
        if self._running or not self._screen:
            return False
        if self._quitting:
            return False
        self._stop = False
        self._running = True
        self._idle.clear()
        save_settings({k: opts[k] for k in ("region", "turn", "delay", "folder", "keep_images",
                                            "quality", "ocr") if k in opts})
        threading.Thread(target=self._run, args=(opts,), daemon=True).start()
        return True

    def stop(self):
        self._stop = True
        return True

    def open_pdf(self):
        if self._last:
            self._mac.open(self._last["pdf"])

    def reveal_pdf(self):
        if self._last:
            self._mac.open(self._last["pdf"], reveal=True)

    # -- intern
    def _js(self, fn, data=None):
        try:
            self._window.evaluate_js(f"window.ui && ui.{fn}({json.dumps(data)})")
        except Exception:  # noqa: BLE001
            pass

    def _region_points(self, frac):
        sw, sh = self._screen["pt_w"], self._screen["pt_h"]
        return {"x": frac["x"] * sw, "y": frac["y"] * sh,
                "w": max(20, frac["w"] * sw), "h": max(20, frac["h"] * sh)}

    def _mini_position(self, r):
        """Ecke des Bildschirms, die am weitesten von der Heftseite entfernt ist."""
        sw, sh = self._screen["pt_w"], self._screen["pt_h"]
        mw, mh = MINI_SIZE
        corners = [(16, 40), (sw - mw - 16, 40), (16, sh - mh - 16), (sw - mw - 16, sh - mh - 16)]
        cx, cy = r["x"] + r["w"] / 2, r["y"] + r["h"] / 2

        def overlaps(px, py):
            return not (px + mw < r["x"] or px > r["x"] + r["w"] or
                        py + mh < r["y"] or py > r["y"] + r["h"])

        free = [c for c in corners if not overlaps(*c)]
        if not free:
            return None
        return max(free, key=lambda c: (c[0] + mw / 2 - cx) ** 2 + (c[1] + mh / 2 - cy) ** 2)

    def _in_corner(self):
        x, y = self._mac.mouse()
        sw, sh = self._screen["pt_w"], self._screen["pt_h"]
        return (x <= 3 or x >= sw - 4) and (y <= 3 or y >= sh - 4)

    def _run(self, opts):
        w = self._window
        region = self._region_points(opts["region"])
        turn = opts["turn"]
        hidden = False
        try:
            self._js("mode", "mini")
            pos = self._mini_position(region)
            w.resize(*MINI_SIZE)
            if pos:
                w.move(int(pos[0]), int(pos[1]))
                w.on_top = True
            else:   # Heft füllt den Bildschirm: Fenster während der Aufnahme ausblenden
                hidden = True
                w.hide()
                self._mac.notify("Aufnahme läuft – Stopp: Maus in eine Bildschirmecke schieben.")
            self._mac.activate(self._target)

            for n in (3, 2, 1):
                self._js("countdown", {"n": n, "app": opts.get("app", "")})
                for _ in range(10):
                    if self._stop:
                        raise StopRequested()
                    time.sleep(0.1)

            shot = ensure_tmp() / "page.png"

            def grab():
                return self._mac.capture(shot, region)

            if turn["mode"] == "click":
                cx = turn["x"] * self._screen["pt_w"]
                cy = turn["y"] * self._screen["pt_h"]

                def do_turn():
                    self._mac.click(cx, cy)
            else:
                def do_turn():
                    self._mac.press(turn["key"])

            job = CaptureJob(
                grab, do_turn, lambda: self._stop or self._in_corner(),
                lambda ev, data: self._js(ev, data),
                delay=float(opts.get("delay", 1.5)),
                max_pages=int(opts.get("pages") or 0),
                out_dir=opts.get("folder") or DEFAULT_OUT,
                name=clean_name(opts.get("name")),
                keep_images=bool(opts.get("keep_images")),
                quality=opts.get("quality", "balanced"),
                page_size=(region["w"], region["h"]),
                ocr=self._ocr if (opts.get("ocr") and self._ocr.available) else None)
            result = job.run()
            self._last = result if result.get("ok") else None
        except StopRequested:
            result = {"ok": False, "reason": "stopped", "pages": 0}
        except Exception as exc:  # noqa: BLE001
            result = {"ok": False, "reason": "error", "error": str(exc), "pages": 0}
        finally:
            self._running = False

        if self._quitting:      # App wird gerade beendet: nur noch Bescheid geben
            self._idle.set()
            return

        # Hauptfenster zurückholen
        try:
            if hidden:
                w.show()
            w.on_top = False
            w.resize(*MAIN_SIZE)
            sw, sh = self._screen["pt_w"], self._screen["pt_h"]
            w.move(int((sw - MAIN_SIZE[0]) / 2), int(max(40, (sh - MAIN_SIZE[1]) / 2)))
        except Exception:  # noqa: BLE001
            pass
        self._mac.show_self()
        self._js("mode", "main")
        self._js("done", result)
        if result.get("ok"):
            self._mac.sound("Glass")
            self._mac.notify(f"Fertig: {result['pages']} Seiten gespeichert.")
        else:
            self._mac.sound("Basso" if result.get("reason") == "error" else "Pop")
        self._idle.set()


# ═════════════════════════════════════════════════════════════ Start
def main():
    import webview

    mac = Mac()
    api = Api(mac)
    window = webview.create_window(
        APP_NAME, url=str(UI_FILE), js_api=api,
        width=MAIN_SIZE[0], height=MAIN_SIZE[1], min_size=(300, 240),
        background_color="#FBFCFE", text_select=False)
    api._window = window
    window.events.closing += api._on_closing
    clean_tmp()

    def on_ready():
        mac.set_dock_icon(ICON_FILE)
        mac.on_cmd_q(api._quit)

    webview.start(on_ready)
    os._exit(0)     # falls die Ereignisschleife doch einmal endet


if __name__ == "__main__":
    main()
