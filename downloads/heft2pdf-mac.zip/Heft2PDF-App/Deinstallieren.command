#!/bin/bash
# Entfernt Heft2PDF wieder. Deine gespeicherten PDFs bleiben erhalten.
APP_NAME="Heft2PDF"
SUPPORT="$HOME/Library/Application Support/$APP_NAME"

clear
printf "\033[1mHeft2PDF entfernen\033[0m\n\n"
echo "Gelöscht werden die App und ihre Programmdateien."
echo "Deine PDFs unter Dokumente/Heft2PDF bleiben erhalten."
echo
read -r -p "Wirklich entfernen? (j/n) " a
case "$a" in j|J|ja|Ja) ;; *) echo "Abgebrochen."; exit 0;; esac

osascript -e "quit app \"$APP_NAME\"" >/dev/null 2>&1
sleep 1
pkill -x "$APP_NAME" 2>/dev/null
pkill -f "Application Support/$APP_NAME/app/" 2>/dev/null
rm -rf "/Applications/$APP_NAME.app" "$HOME/Applications/$APP_NAME.app" "$SUPPORT"
tccutil reset ScreenCapture de.buildspaceos.heft2pdf >/dev/null 2>&1
tccutil reset Accessibility de.buildspaceos.heft2pdf >/dev/null 2>&1
printf "\n\033[32m✓\033[0m Heft2PDF wurde entfernt.\n\n"
read -r -p "Enter zum Schließen …" _
