# Heft2PDF 2.1 für den Mac

Blättert ein digitales Heft automatisch durch, fotografiert jede Seite in voller
Retina-Auflösung und speichert alles als eine PDF.

## Installieren (einmalig)
1. ZIP entpacken.
2. Doppelklick auf **Installieren.command**.
   Warnt macOS („nicht verifizierter Entwickler“): Systemeinstellungen →
   Datenschutz & Sicherheit → ganz unten **„Dennoch öffnen“**, dann erneut doppelklicken.
3. Nach ein bis zwei Minuten liegt **Heft2PDF** im Ordner *Programme*
   und startet von selbst. Am besten ins Dock ziehen.

Python 3 muss vorhanden sein. Fehlt es, bietet der Installer die Installation an.

## Erster Start: zwei Freigaben
Die App zeigt oben rechts, welche Freigabe noch fehlt, und öffnet per Klick
die richtige Stelle in den Systemeinstellungen:
- **Bildschirmaufnahme**, damit die Seiten fotografiert werden können
- **Bedienungshilfen**, damit umgeblättert werden kann

Danach in der App auf **„App neu starten“** klicken.
Taucht Heft2PDF in der Liste nicht auf: mit „+“ aus *Programme* hinzufügen.

## So geht's
1. Heft öffnen, auf die erste Seite gehen, so groß wie möglich zoomen.
2. **Bildschirm aufnehmen**: Heft2PDF tritt kurz zur Seite und fotografiert den Bildschirm.
3. Im Foto einen **Rahmen um die Heftseite** ziehen.
   Die Anzeige sagt dir, ob das Ergebnis scharf wird.
4. Umblätter-Art wählen (Pfeiltaste, Bild ↓, Leertaste oder Klick auf „Weiter“).
5. **PDF erstellen**: Ein kleines Fenster zeigt den Fortschritt. Maus und Tastatur
   währenddessen nicht benutzen.

**Stoppen:** Knopf „Stopp“ oder Maus in eine Bildschirmecke schieben.
Bereits erfasste Seiten werden trotzdem zur PDF.

PDFs landen unter *Dokumente/Heft2PDF* (änderbar).

## Aktualisieren und entfernen
- Neue Version: einfach **Installieren.command** erneut öffnen.
- Entfernen: **Deinstallieren.command**. Deine PDFs bleiben erhalten.

## Wenn etwas hakt
Ein Protokoll liegt unter
`~/Library/Application Support/Heft2PDF/protokoll.txt`.

Bitte nur für Inhalte nutzen, die du speichern darfst (eigene Hefte, passende Lizenz).
