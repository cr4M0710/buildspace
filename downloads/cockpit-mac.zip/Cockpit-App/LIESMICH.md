# Cockpit 2.8 für den Mac

Deine Startzentrale für den Schulalltag: IServ, WebUntis, iDoceo, Edumaps, Jamf,
Apple School Manager, Mail, Kalender, Erinnerungen und WhatsApp mit einem Klick.
Text geht direkt an Claude, ChatGPT, DeepL Write oder WhatsApp. Dazu Kalender,
Projekte & To-dos, Lesezeichen, Whiteboard und PDFs zum Beschriften.

Die ausführliche Anleitung (PDF) gibt es auf buildspaceos.de unter Programme › Cockpit.

## Installieren (einmalig)
1. ZIP entpacken.
2. Doppelklick auf **Installieren.command**.
   Warnt macOS („nicht verifizierter Entwickler“): Systemeinstellungen →
   Datenschutz & Sicherheit → ganz unten **„Dennoch öffnen“**, dann erneut doppelklicken.
3. Nach ein bis zwei Minuten liegt **Cockpit** im Ordner *Programme*
   und startet von selbst. Am besten ins Dock ziehen.

Python 3 muss vorhanden sein. Fehlt es, bietet der Installer die Installation an.
Von älteren Versionen einfach drüber installieren – deine Daten bleiben.

## Erster Start
- **Name und Hintergrund** eintippen bzw. wählen.
- **Termine:** Reiter **Kalender** › Quellen › **„Verbinden“** und erlauben.
- **Adressen:** Kacheln mit orangem Punkt (IServ, Jamf) anklicken und die Adresse eurer Schule eintragen.
- **Erinnerungen:** Beim ersten Mal fragt macOS, ob Cockpit „Erinnerungen“ steuern darf. **OK**.

## Die Bereiche (Seitenreiter links)
- **Start:** Apps, KI-Schnellzeile, Heute, Projekte, buildspace-Aufrufe, Notizen, Gespeichert, Timer, Countdown.
  **Anpassen** oben rechts (oder lange drücken): Widgets und einzelne Apps frei verschieben und an der Ecke
  in der Größe ändern – wie Widgets auf iPhone und iPad. ✕ nimmt sie weg, „Hinzufügen“ holt sie zurück.
  Schnellstart und Kurzwahltasten 1–6 lassen sich unter Einstellungen › Widgets abschalten.
- **WhatsApp:** deine Chats direkt im Cockpit. Beim ersten Mal den QR-Code mit dem Handy scannen
  (WhatsApp › Einstellungen › Verknüpfte Geräte). Ein Widget zeigt ungelesene Chats.
  Neue Nachrichten kommen als Mitteilung von „Cockpit“ – beim ersten Start „Erlauben“ wählen.
- **Kalender:** Woche, Tagesplan, eigene Termine, Kalender-Abos (WebUntis, IServ).
- **Erinnerungen (Widget):** deine Listen abhaken und neue anlegen – beim ersten Mal „Erinnerungen verbinden“ und erlauben.
- **Wetter (Widget):** Ort oben im Widget wählen; „App“ öffnet die Wetter-App.
- **Projekte:** In Planung · In Bearbeitung · Fertig – Karten ziehen oder mit ‹ › verschieben.
- **Gespeichert:** Lesezeichen mit Kategorien und Favoriten.
- **Whiteboard:** Stift, Marker, Radierer, Text; mehrere Tafeln; Vollbild für den Beamer.
- **Dateien:** PDFs und Bilder beschriften, „Als PDF sichern“ legt sie in *Downloads*.
- **Suche (⌘K):** findet alles, auch die Tools auf buildspace.
- **Synchronisieren:** Einstellungen › Synchronisieren › „Mit Google anmelden“ – dasselbe Cockpit
  auf Mac, iPad und im Browser, inklusive PDFs und Bildern.
  Die Mac-App legt dabei auch deine Termine (Mac-Kalender und Abos) ins Konto – so siehst du sie auf iPad und iPhone.
- **Glocke:** was heute und morgen ansteht; macOS meldet sich 15 Minuten vor Terminen.

## Wenn etwas hakt
Einstellungen › **Diagnose** zeigt, ob alles verbunden ist, und hat Test-Knöpfe.
Protokoll: `~/Library/Logs/Cockpit/protokoll.txt`.
Deine Daten: `…/Cockpit/state.json` (mit Sicherungskopie `state.backup.json`), Dateien im Ordner `…/Cockpit/dateien`.

## Aktualisieren und entfernen
- Neue Version: **Installieren.command** erneut öffnen. Deine Daten bleiben.
- Entfernen: **Deinstallieren.command**.
