# Cockpit 1.1 für den Mac

Deine Startzentrale für den Schulalltag. IServ, WebUntis, Edumaps, Jamf und
Apple School Manager öffnest du mit einem Klick. Kalender, Erinnerungen, Mail
und iDoceo auch. Text schickst du direkt an Claude, ChatGPT oder DeepL Write.
Dazu siehst du deine heutigen Termine und hast Notizen griffbereit.

## Installieren (einmalig)
1. ZIP entpacken.
2. Doppelklick auf **Installieren.command**.
   Warnt macOS („nicht verifizierter Entwickler“): Systemeinstellungen →
   Datenschutz & Sicherheit → ganz unten **„Dennoch öffnen“**, dann erneut doppelklicken.
3. Nach ein bis zwei Minuten liegt **Cockpit** im Ordner *Programme*
   und startet von selbst. Am besten ins Dock ziehen.

Python 3 muss vorhanden sein. Fehlt es, bietet der Installer die Installation an.

## Erster Start
- **Termine:** Rechts auf **„Kalender verbinden“** klicken und erlauben.
  Cockpit liest nur die Termine von heute und ändert nichts.
- **Erinnerungen:** Beim ersten Mal fragt macOS, ob Cockpit „Erinnerungen“
  steuern darf. Mit **OK** bestätigen.
- **Adressen:** Kacheln mit orangem Punkt (IServ, Jamf) anklicken und die
  Adresse eurer Schule eintragen.

## So geht's
- **Kachel anklicken** öffnet Webseite oder App. Tasten **1–6** starten den Schnellstart.
- **⌘K** oder **/** öffnet die Suche. Eine getippte Frage geht auf Wunsch direkt an Claude oder ChatGPT.
- **KI-Schnellzeile:** Text eingeben, optional eine Vorlage wählen, dann
  Claude, ChatGPT, DeepL Write, Erinnerung oder Notiz. **⌘↩** schickt an Claude.
- **Anpassen:** Kacheln bearbeiten, verschieben, hinzufügen.
  Typ **„Mac-App“** öffnet jedes Programm aus *Programme*.
- **Übertragen** (Zahnrad): Einstellungen per Code aufs iPad holen.
  Dort läuft Cockpit unter **buildspaceos.de/cockpit**.

## Persönlich anpassen (Zahnrad)
- **Persönlich:** dein Name für die Begrüßung, Name der App und das App-Symbol
  (buildspace, selbst gestaltet mit Farbe und Symbol oder Buchstaben, oder ein eigenes Bild).
  Das Symbol erscheint im Dock, solange Cockpit läuft.
- **Aussehen:** Hintergrund (sechs Vorlagen oder ein eigenes Bild), Glas-Unschärfe,
  Glas-Deckkraft, Abdunkeln und Akzentfarbe.
- **Widgets:** Uhr, KI-Schnellzeile, Schnellstart, App-Bereiche, Heute, Notizen,
  Timer, Countdown und Tipps einzeln ein- und ausblenden.
- Beim ersten Start fragt Cockpit nach deinem Namen und einem Hintergrund.

## Aktualisieren und entfernen
- Neue Version: einfach **Installieren.command** erneut öffnen. Deine Einstellungen bleiben.
- Entfernen: **Deinstallieren.command**.

## Wenn etwas hakt
Ein Protokoll liegt unter
`~/Library/Application Support/Cockpit/protokoll.txt`,
deine Einstellungen unter `…/Cockpit/state.json`.
