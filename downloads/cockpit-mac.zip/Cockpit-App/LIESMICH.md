# Cockpit 2.0 für den Mac

Deine Startzentrale für den Schulalltag: IServ, WebUntis, iDoceo, Edumaps, Jamf,
Apple School Manager, Mail, Kalender, Erinnerungen und WhatsApp mit einem Klick.
Text geht direkt an Claude, ChatGPT, DeepL Write oder WhatsApp. Dazu Kalender,
Projekte & To-dos, Lesezeichen, Whiteboard und PDFs zum Beschriften.

Die ausführliche Anleitung (PDF) gibt es auf buildspaceos.de unter Programme › Cockpit.

## Installieren (einmalig)
1. ZIP entpacken.
2. Doppelklick auf **Installieren.command**.
   Warnt macOS („nicht verifizierter Entwickler“): Systemeinstellungen →
   Datenschutz & Sicherheit → ganz unten **„Dennoch öffnen“**, dann erneut doppelklicken.
3. Nach ein bis zwei Minuten liegt **Cockpit** im Ordner *Programme*
   und startet von selbst. Am besten ins Dock ziehen.

Python 3 muss vorhanden sein. Fehlt es, bietet der Installer die Installation an.
Von Version 1.x einfach drüber installieren – deine Daten bleiben.

## Erster Start
- **Name und Hintergrund** eintippen bzw. wählen.
- **Termine:** Reiter **Kalender** › Quellen › **„Verbinden“** und erlauben.
- **Adressen:** Kacheln mit orangem Punkt (IServ, Jamf) anklicken und die Adresse eurer Schule eintragen.
- **Erinnerungen:** Beim ersten Mal fragt macOS, ob Cockpit „Erinnerungen“ steuern darf. **OK**.

## Die Bereiche (Seitenreiter links)
- **Start:** Apps, KI-Schnellzeile, Heute, Projekte, buildspace-Aufrufe, Notizen, Gespeichert, Timer, Countdown.
- **Kalender:** Woche, Tagesplan, eigene Termine, Kalender-Abos (WebUntis, IServ).
- **Projekte:** In Planung · In Bearbeitung · Fertig – Karten ziehen oder mit ‹ › verschieben.
- **Gespeichert:** Lesezeichen mit Kategorien und Favoriten.
- **Whiteboard:** Stift, Marker, Radierer, Text; mehrere Tafeln; Vollbild für den Beamer.
- **Dateien:** PDFs und Bilder beschriften, „Als PDF sichern“ legt sie in *Downloads*.
- **Suche (⌘K):** findet alles, auch die Tools auf buildspace.
- **Glocke:** was heute und morgen ansteht; macOS meldet sich 15 Minuten vor Terminen.

## Wenn etwas hakt
Einstellungen › **Diagnose** zeigt, ob alles verbunden ist, und hat Test-Knöpfe.
Protokoll: `~/Library/Application Support/Cockpit/protokoll.txt`.
Deine Daten: `…/Cockpit/state.json` (mit Sicherungskopie `state.backup.json`), Dateien im Ordner `…/Cockpit/dateien`.

## Aktualisieren und entfernen
- Neue Version: **Installieren.command** erneut öffnen. Deine Daten bleiben.
- Entfernen: **Deinstallieren.command**.
