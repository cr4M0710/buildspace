#!/bin/bash
# Entfernt Cockpit wieder samt Einstellungen und Notizen.
APP_NAME="Cockpit"
SUPPORT="$HOME/Library/Application Support/$APP_NAME"

clear
printf "\033[1mCockpit entfernen\033[0m\n\n"
echo "Gelöscht werden die App, ihre Programmdateien,"
echo "deine Cockpit-Einstellungen und Notizen auf diesem Mac."
echo "Kalender, Erinnerungen und Mails bleiben unberührt."
echo
read -r -p "Wirklich entfernen? (j/n) " a
case "$a" in j|J|ja|Ja) ;; *) echo "Abgebrochen."; exit 0;; esac

osascript -e "quit app \"$APP_NAME\"" >/dev/null 2>&1
sleep 1
pkill -x "$APP_NAME" 2>/dev/null
pkill -f "Application Support/$APP_NAME/app/" 2>/dev/null
rm -rf "/Applications/$APP_NAME.app" "$HOME/Applications/$APP_NAME.app" "$SUPPORT"
tccutil reset Calendar de.buildspaceos.cockpit >/dev/null 2>&1
tccutil reset AppleEvents de.buildspaceos.cockpit >/dev/null 2>&1
printf "\n\033[32m✓\033[0m Cockpit wurde entfernt.\n\n"
read -r -p "Enter zum Schließen …" _
