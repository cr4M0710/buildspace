#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  Cockpit – Installation für macOS
#  Doppelklick genügt. Ein erneuter Doppelklick aktualisiert die App.
# ─────────────────────────────────────────────────────────────
cd "$(dirname "$0")" || exit 1
SRC="$(pwd)/app"
APP_NAME="Cockpit"
BUNDLE_ID="de.buildspaceos.cockpit"
VERSION="2.9"
SUPPORT="$HOME/Library/Application Support/$APP_NAME"
LOGDIR="$HOME/Library/Logs/Cockpit"; mkdir -p "$LOGDIR" 2>/dev/null
LOG="$LOGDIR/installation.txt"

say()  { printf "\n\033[1m%s\033[0m\n" "$1"; }
ok()   { printf "  \033[32m✓\033[0m %s\n" "$1"; }
note() { printf "  \033[33m•\033[0m %s\n" "$1"; }
fail() {
  printf "\n  \033[31m✗ %s\033[0m\n" "$1"
  osascript -e "display alert \"Cockpit konnte nicht installiert werden\" message \"$1\" as critical" >/dev/null 2>&1
  echo; read -r -p "Enter zum Schließen …" _; exit 1
}

clear
printf "\033[1;34m  Cockpit %s\033[0m\n  Deine Startzentrale für Schule, Apps und KI\n" "$VERSION"

[ -f "$SRC/cockpit_app.py" ] || fail "Der Ordner „app“ fehlt. Bitte das ZIP vollständig entpacken."
mkdir -p "$SUPPORT" || fail "Ordner „$SUPPORT“ lässt sich nicht anlegen."
echo "=== Installation $(date) ===" > "$LOG"

# ── 1. Python suchen ─────────────────────────────────────────
say "1/4  Python suchen"
PY=""
for c in /Library/Frameworks/Python.framework/Versions/Current/bin/python3 \
         /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3; do
  if [ -x "$c" ] && "$c" -c 'import sys, venv; assert sys.version_info >= (3, 9)' >/dev/null 2>&1; then
    PY="$c"; break
  fi
done
if [ -z "$PY" ]; then
  osascript -e 'display alert "Python fehlt" message "Cockpit braucht Python 3. Falls gleich ein Fenster „Befehlszeilenentwicklerwerkzeuge installieren“ erscheint, klicke auf „Installieren“. Sonst öffnet sich python.org – dort den macOS-Installer laden. Danach dieses Installationsprogramm erneut starten."' >/dev/null 2>&1
  /usr/bin/xcode-select --install >/dev/null 2>&1 || open "https://www.python.org/downloads/macos/"
  fail "Python 3 ist noch nicht installiert (siehe Hinweisfenster)."
fi
ok "$("$PY" --version) gefunden"

# ── 2. Programmdateien kopieren ──────────────────────────────
say "2/4  Programmdateien kopieren"
rm -rf "$SUPPORT/app"
cp -R "$SRC" "$SUPPORT/app" || fail "Kopieren fehlgeschlagen."
ok "nach ~/Library/Application Support/$APP_NAME"

# ── 3. Bausteine installieren ────────────────────────────────
say "3/4  Bausteine installieren (beim ersten Mal ca. 1–2 Minuten)"
VENV="$SUPPORT/venv"
# Umgebung kaputt (z. B. Python entfernt)? Dann neu anlegen.
if [ -e "$VENV" ] && ! "$VENV/bin/python" -c 'import sys' >/dev/null 2>&1; then rm -rf "$VENV"; fi
if [ ! -x "$VENV/bin/python" ]; then
  "$PY" -m venv "$VENV" >>"$LOG" 2>&1 || fail "Die Python-Umgebung ließ sich nicht anlegen."
fi
"$VENV/bin/python" -m pip install -q --disable-pip-version-check --upgrade pip >>"$LOG" 2>&1
"$VENV/bin/python" -m pip install -q --disable-pip-version-check --upgrade pywebview pyobjc-framework-EventKit pyobjc-framework-UserNotifications certifi >>"$LOG" 2>&1 \
  || fail "Bausteine konnten nicht geladen werden. Besteht eine Internetverbindung?"
"$VENV/bin/python" -c 'import webview, AppKit' >>"$LOG" 2>&1 \
  || fail "Bausteine sind unvollständig. Bitte Installation erneut starten."
ok "pywebview bereit"
if "$VENV/bin/python" -c 'import EventKit; EventKit.EKEventStore' >>"$LOG" 2>&1; then
  ok "Kalender-Baustein bereit"
else
  note "Kalender-Baustein fehlt – Cockpit funktioniert trotzdem, nur ohne Terminanzeige."
fi

# ── 4. App bauen ─────────────────────────────────────────────
say "4/4  App anlegen"
DEST="/Applications"
[ -w "$DEST" ] || { DEST="$HOME/Applications"; mkdir -p "$DEST"; }
APP="$DEST/$APP_NAME.app"
EXE="$APP/Contents/MacOS/$APP_NAME"

# Alte Version merken (für die Freigaben) und beenden
OLD_HASH=""; OLD_SCRIPT=0
if [ -f "$EXE" ]; then
  OLD_HASH="$(codesign -dvvv "$APP" 2>&1 | awk -F= '/^CDHash=/{print $2; exit}')"
  [ "$(head -c 2 "$EXE")" = "#!" ] && OLD_SCRIPT=1
fi
for old in "/Applications/$APP_NAME.app" "$HOME/Applications/$APP_NAME.app"; do
  [ -d "$old" ] && [ -f "$old/Contents/MacOS/$APP_NAME" ] && [ "$(head -c 2 "$old/Contents/MacOS/$APP_NAME")" = "#!" ] && OLD_SCRIPT=1
done
# Laufende oder hängengebliebene Cockpit-Prozesse beenden
osascript -e "quit app \"$APP_NAME\"" >/dev/null 2>&1; sleep 1
stop_old() {
  pkill -"$1" -x "$APP_NAME" 2>/dev/null
  pkill -"$1" -f "Application Support/$APP_NAME/app/launch.py" 2>/dev/null
  pkill -"$1" -f "Application Support/$APP_NAME/app/cockpit_app.py" 2>/dev/null
}
if pgrep -x "$APP_NAME" >/dev/null 2>&1 || pgrep -f "Application Support/$APP_NAME/app/" >/dev/null 2>&1; then
  stop_old TERM; sleep 1; stop_old KILL
  note "Eine hängengebliebene Cockpit-Sitzung wurde beendet."
fi

make_bundle() {
  rm -rf "$APP"
  mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
  cp "$SRC/Cockpit.icns" "$APP/Contents/Resources/$APP_NAME.icns"
  cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>$APP_NAME</string>
  <key>CFBundleDisplayName</key><string>$APP_NAME</string>
  <key>CFBundleIdentifier</key><string>$BUNDLE_ID</string>
  <key>CFBundleExecutable</key><string>$APP_NAME</string>
  <key>CFBundleIconFile</key><string>$APP_NAME</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>$VERSION</string>
  <key>CFBundleVersion</key><string>$VERSION</string>
  <key>CFBundleDevelopmentRegion</key><string>de</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>LSApplicationCategoryType</key><string>public.app-category.productivity</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSCalendarsUsageDescription</key><string>Cockpit zeigt deine heutigen Termine an.</string>
  <key>NSCalendarsFullAccessUsageDescription</key><string>Cockpit zeigt deine heutigen Termine an. Es ändert nichts in deinem Kalender.</string>
  <key>CFBundleURLTypes</key>
  <array><dict>
    <key>CFBundleURLName</key><string>Cockpit</string>
    <key>CFBundleURLSchemes</key><array><string>cockpit</string></array>
  </dict></array>
  <key>NSRemindersUsageDescription</key><string>Cockpit zeigt deine Erinnerungen an, hakt sie auf deinen Wunsch ab und legt neue an.</string>
  <key>NSRemindersFullAccessUsageDescription</key><string>Cockpit zeigt deine Erinnerungen an, hakt sie auf deinen Wunsch ab und legt neue an.</string>
  <key>NSAppleEventsUsageDescription</key><string>Cockpit legt auf deinen Wunsch Erinnerungen in der App „Erinnerungen“ an.</string>
  <key>LSEnvironment</key>
  <dict>
    <key>COCKPIT_HOME</key><string>$SUPPORT</string>
    <key>COCKPIT_RUN</key><string>1</string>
    <key>PYTHONPATH</key><string>$SUPPORT/app</string>
    <key>PYTHONNOUSERSITE</key><string>1</string>
    <key>PYTHONDONTWRITEBYTECODE</key><string>1</string>
  </dict>
</dict>
</plist>
PLIST
}

sign_bundle() { xattr -cr "$APP" 2>/dev/null; codesign --force -s - -i "$BUNDLE_ID" "$APP" >>"$LOG" 2>&1; }

TESTCODE='import os,site,sys; site.addsitedir(os.path.join(os.environ["COCKPIT_HOME"],"venv","lib","python%d.%d"%sys.version_info[:2],"site-packages")); import webview, AppKit; print("startklar")'
test_bundle() {
  codesign -dv "$APP" 2>&1 | grep -q "Identifier=$BUNDLE_ID" || return 1
  COCKPIT_HOME="$SUPPORT" PYTHONPATH="$SUPPORT/app" PYTHONNOUSERSITE=1 \
    "$EXE" -c "$TESTCODE" 2>>"$LOG" | grep -q startklar
}

# Wo liegt das eigentliche Python?
REAL_PY="$("$VENV/bin/python" -c 'import os,sys
c=os.path.join(sys.base_prefix,"Resources","Python.app","Contents","MacOS","Python")
print(c if os.path.isfile(c) else os.path.realpath(getattr(sys,"_base_executable",sys.executable)))')"
LIBPY="$("$VENV/bin/python" -c 'import os,sys,sysconfig
fw=sysconfig.get_config_var("PYTHONFRAMEWORK")
print(os.path.join(sys.base_prefix,fw) if fw else os.path.join(sysconfig.get_config_var("LIBDIR") or "",sysconfig.get_config_var("LDLIBRARY") or ""))')"
echo "Python: $REAL_PY / Bibliothek: $LIBPY" >>"$LOG"

MODE=""
# Weg A: Python-Programmdatei als App-Programm (App hat eigene Identität).
# Nur wenn sie ihre Bibliothek nicht relativ zum eigenen Ort sucht – sonst stürzt die Kopie
# sofort ab und macOS zeigt „Cockpit kann nicht geöffnet werden“ (dann gleich Weg B).
if LC_ALL=C grep -aqE '@(executable|loader)_path/' "$REAL_PY" 2>/dev/null; then
  echo "Weg A übersprungen: $REAL_PY lädt Python relativ zum eigenen Ort" >>"$LOG"
else
  make_bundle
  if cp "$REAL_PY" "$EXE" 2>>"$LOG" && chmod +x "$EXE" && sign_bundle && test_bundle; then
    MODE="eigen"
  fi
fi
# Weg B: kleinen Starter übersetzen, der Python in den App-Prozess lädt
if [ -z "$MODE" ] && xcode-select -p >/dev/null 2>&1 && [ -f "$LIBPY" ]; then
  make_bundle
  TMPD="$(mktemp -d)"
  printf '#define LIBPYTHON "%s"\n#define LAUNCH_SCRIPT "%s"\n' "$LIBPY" "$SUPPORT/app/launch.py" > "$TMPD/stub_config.h"
  if xcrun clang -O2 -I"$TMPD" "$SUPPORT/app/stub.c" -o "$EXE" >>"$LOG" 2>&1 && sign_bundle && test_bundle; then
    MODE="starter"
  fi
  rm -rf "$TMPD"
fi
# Weg C (Notlösung): Skript-Starter – Freigaben dann für „Python“
if [ -z "$MODE" ]; then
  make_bundle
  cat > "$EXE" <<'LAUNCH'
#!/bin/bash
SUPPORT="$HOME/Library/Application Support/Cockpit"
exec "$SUPPORT/venv/bin/python" "$SUPPORT/app/launch.py"
LAUNCH
  chmod +x "$EXE"
  sign_bundle
  MODE="skript"
fi
echo "Modus: $MODE" >>"$LOG"

/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$APP" >/dev/null 2>&1
touch "$APP"
ok "$APP"

# Freigaben aufräumen, wenn sich die App-Identität geändert hat
NEW_HASH="$(codesign -dvvv "$APP" 2>&1 | awk -F= '/^CDHash=/{print $2; exit}')"
if [ "$OLD_SCRIPT" = 1 ] || { [ -n "$OLD_HASH" ] && [ "$OLD_HASH" != "$NEW_HASH" ]; }; then
  tccutil reset Calendar "$BUNDLE_ID" >/dev/null 2>&1
  tccutil reset AppleEvents "$BUNDLE_ID" >/dev/null 2>&1
  note "Alte Freigaben wurden zurückgesetzt – die App fragt gleich neu."
fi

printf "\n\033[1;32m  Fertig!\033[0m Cockpit liegt jetzt in „%s“.\n" "$(basename "$DEST")"
echo
echo "  Tipp: Zieh Cockpit ins Dock. Beim ersten Start kannst du den"
echo "  Kalender verbinden, damit deine heutigen Termine erscheinen."
open "$APP"
echo; read -r -p "Enter zum Schließen …" _
