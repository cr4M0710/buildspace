#!/usr/bin/env python3
"""
Cockpit – Mac-App von buildspace.

Startzentrale für den Schulalltag: Webseiten (IServ, WebUntis, Edumaps …)
und Mac-Apps (Kalender, Mail, iDoceo …) mit einem Klick öffnen, Text an
Claude, ChatGPT oder DeepL Write schicken, Erinnerungen anlegen und die
heutigen Termine sehen.

Aufbau
  • Oberfläche: ui/index.html – dieselbe Datei wie die Web-App unter
                buildspaceos.de/cockpit, läuft hier in einem nativen Fenster
                (pywebview) und nutzt die Funktionen der Klasse Api
  • Apps/Links: macOS-eigenes `open`
  • Termine:    EventKit (nur lesen, nur heute)
  • Erinnerung: AppleScript an die App „Erinnerungen“
  • Speicher:   ~/Library/Application Support/Cockpit/state.json
"""
import base64
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

APP_NAME = "Cockpit"
VERSION = "2.1"
APP_DIR = Path(__file__).resolve().parent
UI_FILE = APP_DIR / "ui" / "index.html"
ICON_FILE = APP_DIR / "ui" / "icon.png"
SUPPORT_DIR = Path.home() / "Library" / "Application Support" / APP_NAME
STATE_FILE = SUPPORT_DIR / "state.json"
BACKUP_FILE = SUPPORT_DIR / "state.backup.json"
WEB_DATA = SUPPORT_DIR / "webdaten"
CUSTOM_ICON = SUPPORT_DIR / "symbol.png"
OPEN = "/usr/bin/open"
OSASCRIPT = "/usr/bin/osascript"
FILES_DIR = SUPPORT_DIR / "dateien"
APP_FOLDERS = ["/Applications", "/System/Applications", "/System/Applications/Utilities",
               str(Path.home() / "Applications"), "/Applications/Utilities"]
ALLOWED_SCHEMES = ("http://", "https://", "shortcuts://", "mailto:")
PRIVACY = {
    "calendar": "x-apple.systempreferences:com.apple.preference.security?Privacy_Calendars",
    "automation": "x-apple.systempreferences:com.apple.preference.security?Privacy_Automation",
}


# ═════════════════════════════════════════════════════════════ macOS-Helfer
class Mac:
    def __init__(self):
        import AppKit
        from PyObjCTools import AppHelper
        self.AK, self.AH = AppKit, AppHelper

    def on_main(self, fn, timeout=5):
        """AppKit verlangt Fenster-/App-Aktionen auf dem Hauptthread."""
        done, box = threading.Event(), {}

        def work():
            try:
                box["v"] = fn()
            except Exception as exc:  # noqa: BLE001
                box["e"] = exc
            finally:
                done.set()

        self.AH.callAfter(work)
        done.wait(timeout)
        return box.get("v")

    def app(self):
        return self.AK.NSApplication.sharedApplication()

    def set_dock_icon(self, path):
        def f():
            img = self.AK.NSImage.alloc().initWithContentsOfFile_(str(path))
            if img:
                self.app().setApplicationIconImage_(img)
        self.on_main(f)

    def on_cmd_q(self, callback):
        """⌘Q selbst abfangen – pywebview beendet sonst erst beim nächsten Ereignis."""
        AK = self.AK
        mask = getattr(AK, "NSEventMaskKeyDown", 1 << 10)
        cmd = getattr(AK, "NSEventModifierFlagCommand", 1 << 20)

        def handler(event):
            try:
                if (event.modifierFlags() & cmd) and str(event.charactersIgnoringModifiers()).lower() == "q":
                    threading.Thread(target=callback, daemon=True).start()
                    return None
            except Exception:  # noqa: BLE001
                pass
            return event

        self._key_handler = handler   # Referenz halten
        self._key_monitor = self.on_main(
            lambda: AK.NSEvent.addLocalMonitorForEventsMatchingMask_handler_(mask, handler))


# ═════════════════════════════════════════════════════════════ Kalender
class Calendar:
    """Liest die heutigen Termine über EventKit. Fragt nur nach Erlaubnis,
    wenn du in der App auf „Kalender verbinden“ klickst."""

    def __init__(self):
        self._store = None
        self._lock = threading.Lock()

    def _ek(self):
        import EventKit  # noqa: WPS433
        return EventKit

    def store(self):
        with self._lock:
            if self._store is None:
                self._store = self._ek().EKEventStore.alloc().init()
            return self._store

    def state(self):
        EK = self._ek()
        status = int(EK.EKEventStore.authorizationStatusForEntityType_(EK.EKEntityTypeEvent))
        # 0 = noch nicht gefragt, 1 = eingeschränkt, 2 = abgelehnt,
        # 3 = voller Zugriff (früher „authorized“), 4 = nur schreiben
        if status == 0:
            return "ask"
        if status == 3:
            return "ok"
        return "denied"

    def request(self):
        done, box = threading.Event(), {"ok": False}

        def handler(granted, error):
            box["ok"] = bool(granted)
            done.set()

        store = self.store()
        try:
            if hasattr(store, "requestFullAccessToEventsWithCompletion_"):   # macOS 14+
                store.requestFullAccessToEventsWithCompletion_(handler)
            else:
                store.requestAccessToEntityType_completion_(self._ek().EKEntityTypeEvent, handler)
        except Exception as exc:  # noqa: BLE001
            print("Kalender-Anfrage fehlgeschlagen:", exc)
            return False
        done.wait(120)
        with self._lock:
            self._store = None   # nach der Freigabe frisch verbinden
        return box["ok"]

    def today(self):
        return self.day(None)

    def day(self, day_iso):
        """Termine eines Tages (JJJJ-MM-TT, None = heute)."""
        import AppKit
        import Foundation
        store = self.store()
        cal = Foundation.NSCalendar.currentCalendar()
        ref = Foundation.NSDate.date()
        if day_iso:
            import datetime
            d = datetime.datetime.strptime(str(day_iso)[:10], "%Y-%m-%d").replace(hour=12)
            ref = Foundation.NSDate.dateWithTimeIntervalSince1970_(d.timestamp())
        start = cal.startOfDayForDate_(ref)
        end = start.dateByAddingTimeInterval_(24 * 3600)
        pred = store.predicateForEventsWithStartDate_endDate_calendars_(start, end, None)
        events = store.eventsMatchingPredicate_(pred) or []
        out = []
        for e in events:
            color = "#4F7BFF"
            try:
                c = e.calendar().color().colorUsingColorSpace_(AppKit.NSColorSpace.sRGBColorSpace())
                color = "#%02X%02X%02X" % (round(c.redComponent() * 255), round(c.greenComponent() * 255),
                                           round(c.blueComponent() * 255))
            except Exception:  # noqa: BLE001
                pass
            out.append({
                "title": str(e.title() or "Ohne Titel"),
                "start": float(e.startDate().timeIntervalSince1970()),
                "end": float(e.endDate().timeIntervalSince1970()),
                "allDay": bool(e.isAllDay()),
                "location": str(e.location() or ""),
                "calendar": str(e.calendar().title() or "") if e.calendar() else "",
                "color": color,
            })
        out.sort(key=lambda x: (not x["allDay"], x["start"]))
        return out


# ═════════════════════════════════════════════════════════════ Schnittstelle zur Oberfläche
class Api:
    """Alle Methoden sind aus der Oberfläche als window.pywebview.api.<name>() erreichbar."""

    def __init__(self, mac):
        self._mac = mac
        self._window = None
        self._quitting = False
        self._cal = Calendar()
        self._state_lock = threading.Lock()
        self._saved = threading.Event()

    # -- Speicher
    def load_state(self):
        """Liest die gespeicherten Einstellungen. Ist state.json beschädigt oder fehlt,
        wird die Sicherungskopie vom letzten erfolgreichen Speichern genommen."""
        for f in (STATE_FILE, BACKUP_FILE):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    if f is BACKUP_FILE:
                        print("state.json fehlte oder war beschädigt – Sicherungskopie geladen")
                    return data
            except FileNotFoundError:
                continue
            except Exception as exc:  # noqa: BLE001
                print(f"{f.name} unlesbar:", exc)
        return {}

    def save_state(self, state):
        with self._state_lock:
            try:
                SUPPORT_DIR.mkdir(parents=True, exist_ok=True)
                if not isinstance(state, dict):
                    return False
                text = json.dumps(state, ensure_ascii=False)
                tmp = STATE_FILE.with_suffix(".tmp")
                with open(tmp, "w", encoding="utf-8") as fh:
                    fh.write(text)
                    fh.flush()
                    os.fsync(fh.fileno())
                if STATE_FILE.exists():
                    os.replace(STATE_FILE, BACKUP_FILE)   # letzte gute Fassung aufheben
                os.replace(tmp, STATE_FILE)
                self._saved.set()
                return True
            except Exception as exc:  # noqa: BLE001
                print("Speichern fehlgeschlagen:", exc)
                return False

    # -- Öffnen
    def open_url(self, url):
        url = str(url or "").strip()
        if not url.lower().startswith(ALLOWED_SCHEMES):
            return {"ok": False, "error": "Diese Adresse kann Cockpit nicht öffnen."}
        r = subprocess.run([OPEN, url], capture_output=True, text=True)
        if r.returncode != 0:
            if url.startswith("shortcuts://"):
                return {"ok": False, "error": "Der Kurzbefehl wurde nicht gefunden."}
            return {"ok": False, "error": "Die Adresse ließ sich nicht öffnen."}
        return {"ok": True}

    def open_app(self, spec):
        spec = spec or {}
        bundle, name = str(spec.get("bundle") or ""), str(spec.get("name") or "").strip()
        if bundle and subprocess.run([OPEN, "-b", bundle], capture_output=True).returncode == 0:
            return {"ok": True}
        if name and subprocess.run([OPEN, "-a", name], capture_output=True).returncode == 0:
            return {"ok": True}
        return {"ok": False, "error": f"„{name or bundle}“ ist auf diesem Mac nicht installiert."}

    def list_apps(self):
        names = set()
        for folder in APP_FOLDERS:
            try:
                for entry in os.scandir(folder):
                    if entry.name.endswith(".app"):
                        names.add(entry.name[:-4])
            except OSError:
                pass
        return sorted(names, key=str.casefold)

    def copy(self, text):
        try:
            subprocess.run(["/usr/bin/pbcopy"], input=str(text or ""), text=True, check=True,
                           env={**os.environ, "LANG": "de_DE.UTF-8"})
            return True
        except Exception:  # noqa: BLE001
            return False

    # -- Erinnerungen
    def add_reminder(self, text):
        text = str(text or "").strip()
        if not text:
            return {"ok": False, "error": "Erst etwas eingeben."}
        script = ['on run argv',
                  'tell application id "com.apple.reminders" to make new reminder with properties {name:(item 1 of argv)}',
                  'end run']
        args = ["/usr/bin/osascript"]
        for line in script:
            args += ["-e", line]
        r = subprocess.run(args + ["--", text[:500]], capture_output=True, text=True, timeout=60)
        if r.returncode == 0:
            return {"ok": True}
        err = r.stderr or ""
        print("Erinnerung fehlgeschlagen:", err.strip())
        if "-1743" in err or "nicht erlaubt" in err or "not allowed" in err:
            subprocess.run([OPEN, PRIVACY["automation"]])
            return {"ok": False, "error": "Bitte erlaube Cockpit, „Erinnerungen“ zu steuern (Automation)."}
        return {"ok": False, "error": "Die Erinnerung konnte nicht angelegt werden."}

    # -- Kalender
    def today_events(self):
        try:
            state = self._cal.state()
            if state != "ok":
                return {"state": state}
            return {"state": "ok", "events": self._cal.today()}
        except ImportError:
            return {"state": "error", "error": "Der Kalender-Baustein fehlt. Bitte Installieren.command erneut ausführen."}
        except Exception as exc:  # noqa: BLE001
            print("Termine fehlgeschlagen:", exc)
            return {"state": "error", "error": "Termine konnten nicht geladen werden."}

    def events(self, day_iso):
        try:
            state = self._cal.state()
            if state != "ok":
                return {"state": state}
            return {"state": "ok", "events": self._cal.day(day_iso)}
        except ImportError:
            return {"state": "error", "error": "Der Kalender-Baustein fehlt. Bitte Installieren.command erneut ausführen."}
        except Exception as exc:  # noqa: BLE001
            print("Termine fehlgeschlagen:", exc)
            return {"state": "error", "error": "Termine konnten nicht geladen werden."}

    # -- Internet: Kalender-Abos (iCal), buildspace-Beiträge, Aufrufzahlen
    def fetch_text(self, url):
        import ssl
        import urllib.error
        import urllib.request
        url = str(url or "").strip()
        if url.lower().startswith("webcal://"):
            url = "https://" + url[9:]
        if not url.lower().startswith(("https://", "http://")):
            return {"ok": False, "error": "Nur http- und https-Adressen."}
        try:
            try:
                import certifi
                ctx = ssl.create_default_context(cafile=certifi.where())
            except ImportError:
                ctx = ssl.create_default_context()
            req = urllib.request.Request(url, headers={"User-Agent": "Cockpit/" + VERSION})
            try:
                res = urllib.request.urlopen(req, timeout=20, context=ctx)
            except urllib.error.HTTPError as err:   # Antwort trotzdem weitergeben (z. B. Fehlermeldung als JSON)
                res = err
            data = res.read(8 * 1024 * 1024 + 1)
            if len(data) > 8 * 1024 * 1024:
                return {"ok": False, "error": "Die Datei ist zu groß."}
            charset = res.headers.get_content_charset() or "utf-8"
            return {"ok": True, "status": getattr(res, "status", 200), "text": data.decode(charset, "replace")}
        except Exception as exc:  # noqa: BLE001
            print("Laden fehlgeschlagen:", url, exc)
            return {"ok": False, "error": "Die Adresse ist nicht erreichbar."}

    # -- Mitteilungen
    def notify(self, title, text=""):
        esc = lambda v: str(v or "").replace("\\", "\\\\").replace('"', '\\"')[:200]
        script = f'display notification "{esc(text)}" with title "{esc(title) or APP_NAME}"'
        try:
            subprocess.run([OSASCRIPT, "-e", script], timeout=10, capture_output=True)
            return True
        except Exception as exc:  # noqa: BLE001
            print("Mitteilung fehlgeschlagen:", exc)
            return False

    # -- Dateien (PDFs und Bilder zum Bearbeiten)
    def _file_path(self, fid):
        fid = "".join(ch for ch in str(fid) if ch.isalnum() or ch in "-_")[:64]
        if not fid:
            raise ValueError("ungültige Kennung")
        return FILES_DIR / fid

    def file_save(self, fid, name, data_url):
        try:
            head, _, b64 = str(data_url).partition(",")
            if not head.startswith("data:") or not b64:
                return {"ok": False, "error": "Ungültige Datei."}
            FILES_DIR.mkdir(parents=True, exist_ok=True)
            path = self._file_path(fid)
            path.write_bytes(base64.b64decode(b64))
            path.with_suffix(".meta").write_text(json.dumps({"name": str(name), "type": head[5:].split(";")[0]}), "utf-8")
            return {"ok": True}
        except Exception as exc:  # noqa: BLE001
            print("Datei speichern fehlgeschlagen:", exc)
            return {"ok": False, "error": "Die Datei konnte nicht gespeichert werden."}

    def file_load(self, fid):
        try:
            path = self._file_path(fid)
            meta = {}
            try:
                meta = json.loads(path.with_suffix(".meta").read_text("utf-8"))
            except Exception:  # noqa: BLE001
                pass
            mime = meta.get("type") or "application/octet-stream"
            return {"ok": True, "data": f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode()}
        except FileNotFoundError:
            return {"ok": False, "error": "Datei nicht gefunden."}
        except Exception as exc:  # noqa: BLE001
            print("Datei laden fehlgeschlagen:", exc)
            return {"ok": False, "error": "Die Datei konnte nicht geladen werden."}

    def file_list(self):
        try:
            return [p.name for p in FILES_DIR.iterdir() if p.suffix != ".meta"] if FILES_DIR.exists() else []
        except Exception:  # noqa: BLE001
            return []

    def file_delete(self, fid):
        try:
            path = self._file_path(fid)
            path.unlink(missing_ok=True)
            path.with_suffix(".meta").unlink(missing_ok=True)
            return True
        except Exception:  # noqa: BLE001
            return False

    def save_download(self, name, data_url):
        """Speichert eine Datei (z. B. bearbeitetes PDF, Whiteboard als Bild) in „Downloads“."""
        try:
            head, _, b64 = str(data_url).partition(",")
            if not head.startswith("data:") or not b64:
                return {"ok": False, "error": "Ungültige Datei."}
            clean = "".join(ch for ch in str(name) if ch not in '/\\:\0').strip() or "Cockpit-Datei"
            downloads = Path.home() / "Downloads"
            downloads.mkdir(exist_ok=True)
            stem, dot, ext = clean.rpartition(".")
            if not dot:
                stem, ext = clean, ""
            target, n = downloads / clean, 2
            while target.exists():
                target = downloads / (f"{stem} {n}.{ext}" if ext else f"{stem} {n}")
                n += 1
            target.write_bytes(base64.b64decode(b64))
            subprocess.run([OPEN, "-R", str(target)])
            return {"ok": True, "name": target.name}
        except Exception as exc:  # noqa: BLE001
            print("Download fehlgeschlagen:", exc)
            return {"ok": False, "error": "Speichern in „Downloads“ fehlgeschlagen."}

    def request_calendar(self):
        try:
            return self._cal.request()
        except Exception as exc:  # noqa: BLE001
            print("Kalender-Freigabe fehlgeschlagen:", exc)
            return False

    def open_privacy(self, kind):
        url = PRIVACY.get(str(kind))
        if url:
            subprocess.run([OPEN, url])
        return True

    def version(self):
        return VERSION

    # -- Persönlich: App-Symbol im Dock und Fenstertitel
    def set_icon(self, data_url):
        """data_url = Bild als data:-URL (eigenes oder gestaltetes Symbol) oder None für das Standard-Symbol."""
        try:
            if not data_url:
                CUSTOM_ICON.unlink(missing_ok=True)
                self._mac.set_dock_icon(ICON_FILE)
                return True
            head, _, b64 = str(data_url).partition(",")
            if not head.startswith("data:image/") or not b64:
                return False
            SUPPORT_DIR.mkdir(parents=True, exist_ok=True)
            raw = base64.b64decode(b64)
            if CUSTOM_ICON.exists() and CUSTOM_ICON.read_bytes() == raw:
                return True
            CUSTOM_ICON.write_bytes(raw)
            self._mac.set_dock_icon(CUSTOM_ICON)
            return True
        except Exception as exc:  # noqa: BLE001
            print("Symbol setzen fehlgeschlagen:", exc)
            return False

    def set_title(self, title):
        try:
            title = str(title or APP_NAME).strip()[:40] or APP_NAME
            if self._window:
                self._window.set_title(title)
            return True
        except Exception as exc:  # noqa: BLE001
            print("Titel setzen fehlgeschlagen:", exc)
            return False

    # -- Beenden
    def _on_closing(self):
        if not self._quitting:
            threading.Thread(target=self._quit, daemon=True).start()
        return False

    def _flush_ui(self):
        """Vor dem Beenden: noch nicht gespeicherte Änderungen aus dem Fenster holen."""
        try:
            if not self._window:
                return
            pending = self._window.evaluate_js("window.__cockpitPending ? window.__cockpitPending() : false")
            if pending:
                self._saved.clear()
                self._window.evaluate_js("window.__cockpitFlush && (window.__cockpitFlush(), true)")
                self._saved.wait(2)
        except Exception as exc:  # noqa: BLE001
            print("Speichern vor dem Beenden fehlgeschlagen:", exc)

    def _quit(self):
        if self._quitting:
            return
        self._quitting = True
        self._flush_ui()
        time.sleep(0.05)
        print("Beendet")
        try:
            sys.stdout.flush()
        except Exception:  # noqa: BLE001
            pass
        os._exit(0)


# ═════════════════════════════════════════════════════════════ Start
def main():
    import webview

    SUPPORT_DIR.mkdir(parents=True, exist_ok=True)
    try:   # Links mit target="_blank" im normalen Browser öffnen statt im App-Fenster
        webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True
    except Exception:  # noqa: BLE001
        pass
    mac = Mac()
    api = Api(mac)
    window = webview.create_window(
        APP_NAME, url=str(UI_FILE), js_api=api,
        width=1320, height=880, min_size=(760, 560),
        background_color="#06060D", text_select=True)
    api._window = window
    window.events.closing += api._on_closing

    def on_ready():
        mac.set_dock_icon(CUSTOM_ICON if CUSTOM_ICON.exists() else ICON_FILE)
        mac.on_cmd_q(api._quit)

    # Fensterspeicher dauerhaft machen (pywebview löscht ihn sonst bei jedem Beenden).
    # Die eigentlichen Daten liegen ohnehin in state.json – das hier ist das zweite Netz.
    try:
        WEB_DATA.mkdir(parents=True, exist_ok=True)
        webview.start(on_ready, private_mode=False, storage_path=str(WEB_DATA))
    except TypeError:   # sehr alte pywebview-Version ohne diese Optionen
        webview.start(on_ready)
    os._exit(0)


if __name__ == "__main__":
    main()
