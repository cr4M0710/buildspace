#!/usr/bin/env python3
"""
Cockpit – Mac-App von buildspace.

Startzentrale für den Schulalltag: Webseiten (IServ, WebUntis, Edumaps …)
und Mac-Apps (Kalender, Mail, iDoceo …) mit einem Klick öffnen, Text an
Claude, ChatGPT oder DeepL Write schicken, Erinnerungen anlegen und die
heutigen Termine sehen.

Aufbau
  • Oberfläche: ui/index.html – dieselbe Datei wie die Web-App unter
                buildspaceos.de/cockpit, läuft hier in einem nativen Fenster
                (pywebview) und nutzt die Funktionen der Klasse Api
  • Apps/Links: macOS-eigenes `open`
  • Termine:    EventKit (nur lesen, nur heute)
  • Erinnerung: AppleScript an die App „Erinnerungen“
  • Speicher:   ~/Library/Application Support/Cockpit/state.json
"""
import json
import os
import subprocess
import sys
import threading
from pathlib import Path

APP_NAME = "Cockpit"
VERSION = "1.0"
APP_DIR = Path(__file__).resolve().parent
UI_FILE = APP_DIR / "ui" / "index.html"
ICON_FILE = APP_DIR / "ui" / "icon.png"
SUPPORT_DIR = Path.home() / "Library" / "Application Support" / APP_NAME
STATE_FILE = SUPPORT_DIR / "state.json"
OPEN = "/usr/bin/open"
APP_FOLDERS = ["/Applications", "/System/Applications", "/System/Applications/Utilities",
               str(Path.home() / "Applications"), "/Applications/Utilities"]
ALLOWED_SCHEMES = ("http://", "https://", "shortcuts://", "mailto:")
PRIVACY = {
    "calendar": "x-apple.systempreferences:com.apple.preference.security?Privacy_Calendars",
    "automation": "x-apple.systempreferences:com.apple.preference.security?Privacy_Automation",
}


# ═════════════════════════════════════════════════════════════ macOS-Helfer
class Mac:
    def __init__(self):
        import AppKit
        from PyObjCTools import AppHelper
        self.AK, self.AH = AppKit, AppHelper

    def on_main(self, fn, timeout=5):
        """AppKit verlangt Fenster-/App-Aktionen auf dem Hauptthread."""
        done, box = threading.Event(), {}

        def work():
            try:
                box["v"] = fn()
            except Exception as exc:  # noqa: BLE001
                box["e"] = exc
            finally:
                done.set()

        self.AH.callAfter(work)
        done.wait(timeout)
        return box.get("v")

    def app(self):
        return self.AK.NSApplication.sharedApplication()

    def set_dock_icon(self, path):
        def f():
            img = self.AK.NSImage.alloc().initWithContentsOfFile_(str(path))
            if img:
                self.app().setApplicationIconImage_(img)
        self.on_main(f)

    def on_cmd_q(self, callback):
        """⌘Q selbst abfangen – pywebview beendet sonst erst beim nächsten Ereignis."""
        AK = self.AK
        mask = getattr(AK, "NSEventMaskKeyDown", 1 << 10)
        cmd = getattr(AK, "NSEventModifierFlagCommand", 1 << 20)

        def handler(event):
            try:
                if (event.modifierFlags() & cmd) and str(event.charactersIgnoringModifiers()).lower() == "q":
                    threading.Thread(target=callback, daemon=True).start()
                    return None
            except Exception:  # noqa: BLE001
                pass
            return event

        self._key_handler = handler   # Referenz halten
        self._key_monitor = self.on_main(
            lambda: AK.NSEvent.addLocalMonitorForEventsMatchingMask_handler_(mask, handler))


# ═════════════════════════════════════════════════════════════ Kalender
class Calendar:
    """Liest die heutigen Termine über EventKit. Fragt nur nach Erlaubnis,
    wenn du in der App auf „Kalender verbinden“ klickst."""

    def __init__(self):
        self._store = None
        self._lock = threading.Lock()

    def _ek(self):
        import EventKit  # noqa: WPS433
        return EventKit

    def store(self):
        with self._lock:
            if self._store is None:
                self._store = self._ek().EKEventStore.alloc().init()
            return self._store

    def state(self):
        EK = self._ek()
        status = int(EK.EKEventStore.authorizationStatusForEntityType_(EK.EKEntityTypeEvent))
        # 0 = noch nicht gefragt, 1 = eingeschränkt, 2 = abgelehnt,
        # 3 = voller Zugriff (früher „authorized“), 4 = nur schreiben
        if status == 0:
            return "ask"
        if status == 3:
            return "ok"
        return "denied"

    def request(self):
        done, box = threading.Event(), {"ok": False}

        def handler(granted, error):
            box["ok"] = bool(granted)
            done.set()

        store = self.store()
        try:
            if hasattr(store, "requestFullAccessToEventsWithCompletion_"):   # macOS 14+
                store.requestFullAccessToEventsWithCompletion_(handler)
            else:
                store.requestAccessToEntityType_completion_(self._ek().EKEntityTypeEvent, handler)
        except Exception as exc:  # noqa: BLE001
            print("Kalender-Anfrage fehlgeschlagen:", exc)
            return False
        done.wait(120)
        with self._lock:
            self._store = None   # nach der Freigabe frisch verbinden
        return box["ok"]

    def today(self):
        import AppKit
        import Foundation
        store = self.store()
        cal = Foundation.NSCalendar.currentCalendar()
        start = cal.startOfDayForDate_(Foundation.NSDate.date())
        end = start.dateByAddingTimeInterval_(24 * 3600)
        pred = store.predicateForEventsWithStartDate_endDate_calendars_(start, end, None)
        events = store.eventsMatchingPredicate_(pred) or []
        out = []
        for e in events:
            color = "#4F7BFF"
            try:
                c = e.calendar().color().colorUsingColorSpace_(AppKit.NSColorSpace.sRGBColorSpace())
                color = "#%02X%02X%02X" % (round(c.redComponent() * 255), round(c.greenComponent() * 255),
                                           round(c.blueComponent() * 255))
            except Exception:  # noqa: BLE001
                pass
            out.append({
                "title": str(e.title() or "Ohne Titel"),
                "start": float(e.startDate().timeIntervalSince1970()),
                "end": float(e.endDate().timeIntervalSince1970()),
                "allDay": bool(e.isAllDay()),
                "location": str(e.location() or ""),
                "calendar": str(e.calendar().title() or "") if e.calendar() else "",
                "color": color,
            })
        out.sort(key=lambda x: (not x["allDay"], x["start"]))
        return out


# ═════════════════════════════════════════════════════════════ Schnittstelle zur Oberfläche
class Api:
    """Alle Methoden sind aus der Oberfläche als window.pywebview.api.<name>() erreichbar."""

    def __init__(self, mac):
        self._mac = mac
        self._window = None
        self._quitting = False
        self._cal = Calendar()
        self._state_lock = threading.Lock()

    # -- Speicher
    def load_state(self):
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return {}
        except Exception as exc:  # noqa: BLE001
            print("state.json unlesbar:", exc)
            return {}

    def save_state(self, state):
        with self._state_lock:
            try:
                SUPPORT_DIR.mkdir(parents=True, exist_ok=True)
                tmp = STATE_FILE.with_suffix(".tmp")
                tmp.write_text(json.dumps(state, ensure_ascii=False, indent=1), encoding="utf-8")
                os.replace(tmp, STATE_FILE)
                return True
            except Exception as exc:  # noqa: BLE001
                print("Speichern fehlgeschlagen:", exc)
                return False

    # -- Öffnen
    def open_url(self, url):
        url = str(url or "").strip()
        if not url.lower().startswith(ALLOWED_SCHEMES):
            return {"ok": False, "error": "Diese Adresse kann Cockpit nicht öffnen."}
        r = subprocess.run([OPEN, url], capture_output=True, text=True)
        if r.returncode != 0:
            if url.startswith("shortcuts://"):
                return {"ok": False, "error": "Der Kurzbefehl wurde nicht gefunden."}
            return {"ok": False, "error": "Die Adresse ließ sich nicht öffnen."}
        return {"ok": True}

    def open_app(self, spec):
        spec = spec or {}
        bundle, name = str(spec.get("bundle") or ""), str(spec.get("name") or "").strip()
        if bundle and subprocess.run([OPEN, "-b", bundle], capture_output=True).returncode == 0:
            return {"ok": True}
        if name and subprocess.run([OPEN, "-a", name], capture_output=True).returncode == 0:
            return {"ok": True}
        return {"ok": False, "error": f"„{name or bundle}“ ist auf diesem Mac nicht installiert."}

    def list_apps(self):
        names = set()
        for folder in APP_FOLDERS:
            try:
                for entry in os.scandir(folder):
                    if entry.name.endswith(".app"):
                        names.add(entry.name[:-4])
            except OSError:
                pass
        return sorted(names, key=str.casefold)

    def copy(self, text):
        try:
            subprocess.run(["/usr/bin/pbcopy"], input=str(text or ""), text=True, check=True,
                           env={**os.environ, "LANG": "de_DE.UTF-8"})
            return True
        except Exception:  # noqa: BLE001
            return False

    # -- Erinnerungen
    def add_reminder(self, text):
        text = str(text or "").strip()
        if not text:
            return {"ok": False, "error": "Erst etwas eingeben."}
        script = ['on run argv',
                  'tell application id "com.apple.reminders" to make new reminder with properties {name:(item 1 of argv)}',
                  'end run']
        args = ["/usr/bin/osascript"]
        for line in script:
            args += ["-e", line]
        r = subprocess.run(args + ["--", text[:500]], capture_output=True, text=True, timeout=60)
        if r.returncode == 0:
            return {"ok": True}
        err = r.stderr or ""
        print("Erinnerung fehlgeschlagen:", err.strip())
        if "-1743" in err or "nicht erlaubt" in err or "not allowed" in err:
            subprocess.run([OPEN, PRIVACY["automation"]])
            return {"ok": False, "error": "Bitte erlaube Cockpit, „Erinnerungen“ zu steuern (Automation)."}
        return {"ok": False, "error": "Die Erinnerung konnte nicht angelegt werden."}

    # -- Kalender
    def today_events(self):
        try:
            state = self._cal.state()
            if state != "ok":
                return {"state": state}
            return {"state": "ok", "events": self._cal.today()}
        except ImportError:
            return {"state": "error", "error": "Der Kalender-Baustein fehlt. Bitte Installieren.command erneut ausführen."}
        except Exception as exc:  # noqa: BLE001
            print("Termine fehlgeschlagen:", exc)
            return {"state": "error", "error": "Termine konnten nicht geladen werden."}

    def request_calendar(self):
        try:
            return self._cal.request()
        except Exception as exc:  # noqa: BLE001
            print("Kalender-Freigabe fehlgeschlagen:", exc)
            return False

    def open_privacy(self, kind):
        url = PRIVACY.get(str(kind))
        if url:
            subprocess.run([OPEN, url])
        return True

    def version(self):
        return VERSION

    # -- Beenden
    def _on_closing(self):
        if not self._quitting:
            threading.Thread(target=self._quit, daemon=True).start()
        return False

    def _quit(self):
        if self._quitting:
            return
        self._quitting = True
        print("Beendet")
        try:
            sys.stdout.flush()
        except Exception:  # noqa: BLE001
            pass
        os._exit(0)


# ═════════════════════════════════════════════════════════════ Start
def main():
    import webview

    SUPPORT_DIR.mkdir(parents=True, exist_ok=True)
    mac = Mac()
    api = Api(mac)
    window = webview.create_window(
        APP_NAME, url=str(UI_FILE), js_api=api,
        width=1320, height=880, min_size=(760, 560),
        background_color="#06060D", text_select=True)
    api._window = window
    window.events.closing += api._on_closing

    def on_ready():
        mac.set_dock_icon(ICON_FILE)
        mac.on_cmd_q(api._quit)

    webview.start(on_ready)
    os._exit(0)


if __name__ == "__main__":
    main()
