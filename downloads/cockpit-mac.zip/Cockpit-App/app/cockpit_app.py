#!/usr/bin/env python3
"""
Cockpit – Mac-App von buildspace.

Startzentrale für den Schulalltag: Webseiten (IServ, WebUntis, Edumaps …)
und Mac-Apps (Kalender, Mail, iDoceo …) mit einem Klick öffnen, Text an
Claude, ChatGPT oder DeepL Write schicken, Erinnerungen anlegen und die
heutigen Termine sehen.

Aufbau
  • Oberfläche: ui/index.html – dieselbe Datei wie die Web-App unter
                buildspaceos.de/cockpit, läuft hier in einem nativen Fenster
                (pywebview) und nutzt die Funktionen der Klasse Api
  • Apps/Links: macOS-eigenes `open`
  • Termine:    EventKit (nur lesen, nur heute)
  • Erinnerung: AppleScript an die App „Erinnerungen“
  • Speicher:   ~/Library/Application Support/Cockpit/state.json
"""
import base64
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

APP_NAME = "Cockpit"
VERSION = "2.7"
APP_DIR = Path(__file__).resolve().parent
UI_FILE = APP_DIR / "ui" / "index.html"
ICON_FILE = APP_DIR / "ui" / "icon.png"
SUPPORT_DIR = Path.home() / "Library" / "Application Support" / APP_NAME
STATE_FILE = SUPPORT_DIR / "state.json"
BACKUP_FILE = SUPPORT_DIR / "state.backup.json"
WEB_DATA = SUPPORT_DIR / "webdaten"
CUSTOM_ICON = SUPPORT_DIR / "symbol.png"
OPEN = "/usr/bin/open"
OSASCRIPT = "/usr/bin/osascript"
FILES_DIR = SUPPORT_DIR / "dateien"
GUARD_DIR = SUPPORT_DIR / "schutz"     # Merker: welcher Baustein beim letzten Mal abgestürzt ist
APP_FOLDERS = ["/Applications", "/System/Applications", "/System/Applications/Utilities",
               str(Path.home() / "Applications"), "/Applications/Utilities"]
ALLOWED_SCHEMES = ("http://", "https://", "shortcuts://", "mailto:")
WA_URL = "https://web.whatsapp.com/"
# WhatsApp Web lässt nur bekannte Browser zu – die eingebettete Ansicht meldet sich wie Safari.
SAFARI_UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
             "(KHTML, like Gecko) Version/18.0 Safari/605.1.15")
WA_DESKTOP_IDS = ("net.whatsapp.WhatsApp", "desktop.WhatsApp", "WhatsApp")

# In die WhatsApp-Ansicht eingespielt: Web-Mitteilungen gelten als erlaubt und werden an Cockpit
# weitergereicht, das daraus echte macOS-Mitteilungen macht (mit Absender und Text).
WA_NOTIFY_SHIM = r"""
(function () {
  if (window.__cockpitNotify) return; window.__cockpitNotify = true;
  var post = function (m) { try { window.webkit.messageHandlers.cockpitNotify.postMessage(m); } catch (e) {} };
  var live = {};
  function CockpitNotification(title, opt) {
    opt = opt || {};
    var t = new EventTarget();
    var id = 'n' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    t.title = String(title || ''); t.body = String(opt.body || ''); t.tag = String(opt.tag || '');
    t.icon = opt.icon || ''; t.data = opt.data; t.silent = !!opt.silent;
    t.onclick = null; t.onclose = null; t.onshow = null; t.onerror = null;
    t.close = function () { post({ close: true, id: id, tag: t.tag }); };
    live[id] = t;
    var keys = Object.keys(live); if (keys.length > 60) delete live[keys[0]];
    post({ id: id, title: t.title, body: t.body, tag: t.tag, silent: t.silent });
    setTimeout(function () { if (t.onshow) t.onshow(new Event('show')); t.dispatchEvent(new Event('show')); }, 0);
    return t;
  }
  Object.defineProperty(CockpitNotification, 'permission', { get: function () { return 'granted'; } });
  CockpitNotification.requestPermission = function (cb) { if (cb) cb('granted'); return Promise.resolve('granted'); };
  CockpitNotification.maxActions = 0;
  window.__cockpitNotifyClick = function (id) {
    var t = live[id]; if (!t) return false;
    var ev = new Event('click'); if (t.onclick) t.onclick(ev); t.dispatchEvent(ev); return true;
  };
  try { Object.defineProperty(window, 'Notification', { value: CockpitNotification, writable: true, configurable: true }); }
  catch (e) { window.Notification = CockpitNotification; }
  if (navigator.permissions && navigator.permissions.query) {
    var q = navigator.permissions.query.bind(navigator.permissions);
    navigator.permissions.query = function (d) {
      if (d && d.name === 'notifications') return Promise.resolve({ name: 'notifications', state: 'granted', status: 'granted', onchange: null, addEventListener: function () {}, removeEventListener: function () {} });
      return q(d);
    };
  }
})();
"""
PRIVACY = {
    "calendar": "x-apple.systempreferences:com.apple.preference.security?Privacy_Calendars",
    "automation": "x-apple.systempreferences:com.apple.preference.security?Privacy_Automation",
    "notifications": "x-apple.systempreferences:com.apple.Notifications-Settings.extension",
}


# ═════════════════════════════════════════════════════════════ macOS-Helfer
class Mac:
    def __init__(self):
        import AppKit
        from PyObjCTools import AppHelper
        self.AK, self.AH = AppKit, AppHelper

    def on_main(self, fn, timeout=5):
        """AppKit verlangt Fenster-/App-Aktionen auf dem Hauptthread."""
        done, box = threading.Event(), {}

        def work():
            try:
                box["v"] = fn()
            except Exception as exc:  # noqa: BLE001
                box["e"] = exc
            finally:
                done.set()

        self.AH.callAfter(work)
        done.wait(timeout)
        return box.get("v")

    def app(self):
        return self.AK.NSApplication.sharedApplication()

    def set_dock_icon(self, path):
        def f():
            img = self.AK.NSImage.alloc().initWithContentsOfFile_(str(path))
            if img:
                self.app().setApplicationIconImage_(img)
        self.on_main(f)

    def on_cmd_q(self, callback):
        """⌘Q selbst abfangen – pywebview beendet sonst erst beim nächsten Ereignis."""
        AK = self.AK
        mask = getattr(AK, "NSEventMaskKeyDown", 1 << 10)
        cmd = getattr(AK, "NSEventModifierFlagCommand", 1 << 20)

        def handler(event):
            try:
                if (event.modifierFlags() & cmd) and str(event.charactersIgnoringModifiers()).lower() == "q":
                    threading.Thread(target=callback, daemon=True).start()
                    return None
            except Exception:  # noqa: BLE001
                pass
            return event

        self._key_handler = handler   # Referenz halten
        self._key_monitor = self.on_main(
            lambda: AK.NSEvent.addLocalMonitorForEventsMatchingMask_handler_(mask, handler))


# ═════════════════════════════════════════════════════════════ Selbstschutz
class Guard:
    """Vor einem heiklen Schritt wird ein Merker gesetzt und danach entfernt. Liegt er beim
    nächsten Start noch da, ist Cockpit genau dabei abgestürzt – dann bleibt der Baustein aus,
    damit sich die App wieder öffnen lässt."""
    def __init__(self, name):
        self.path = GUARD_DIR / (name + ".offen")
        self.crashed = self.path.exists()
        if self.crashed:
            print(f"Selbstschutz: „{name}“ ist beim letzten Start abgestürzt und bleibt aus.")

    def __enter__(self):
        try:
            GUARD_DIR.mkdir(parents=True, exist_ok=True)
            self.path.write_text(time.strftime("%Y-%m-%d %H:%M:%S"), "utf-8")
        except OSError:
            pass
        return self

    def __exit__(self, *exc):
        try:
            self.path.unlink(missing_ok=True)
        except OSError:
            pass
        return False

    def disarm_later(self, seconds):
        """Merker erst nach einer Weile entfernen – Abstürze beim Zeichnen/Laden kommen oft verzögert."""
        threading.Thread(target=lambda: (time.sleep(seconds), self.__exit__()), daemon=True).start()

    def reset(self):
        self.crashed = False
        try:
            self.path.unlink(missing_ok=True)
        except OSError:
            pass


# ═════════════════════════════════════════════════════════════ Mitteilungen (macOS)
_NOTIFY_DELEGATE = None


def _notify_delegate_class():
    global _NOTIFY_DELEGATE
    if _NOTIFY_DELEGATE is not None:
        return _NOTIFY_DELEGATE
    import AppKit

    class CockpitNotifyDelegate(AppKit.NSObject):
        # Auch zeigen, wenn Cockpit gerade vorne ist (Banner, Mitteilungszentrale, Ton)
        def userNotificationCenter_willPresentNotification_withCompletionHandler_(self, center, notification, handler):
            handler((1 << 4) | (1 << 3) | (1 << 1))

        # Klick auf eine Mitteilung: Cockpit nach vorne, passende Ansicht bzw. den Chat öffnen
        def userNotificationCenter_didReceiveNotificationResponse_withCompletionHandler_(self, center, response, handler):
            try:
                info = response.notification().request().content().userInfo() or {}
                args = (str(info.get("kind") or ""), str(info.get("ref") or ""), str(info.get("view") or ""))
                threading.Thread(target=self.notifier.clicked, args=args, daemon=True).start()
            except Exception as exc:  # noqa: BLE001
                print("Mitteilung angeklickt:", exc)
            handler()

    _NOTIFY_DELEGATE = CockpitNotifyDelegate
    return _NOTIFY_DELEGATE


class Notifier:
    """Echte macOS-Mitteilungen von „Cockpit“ (UserNotifications). Ohne App-Bundle oder ohne
    Erlaubnis geht es ersatzweise über AppleScript."""

    def __init__(self, mac):
        self.mac = mac
        self.api = None
        self.center = None
        self.UN = None
        self.granted = None      # None = noch unbekannt
        self._delegate = None
        self.guard = Guard("mitteilungen")

    def setup(self):
        if self.guard.crashed:
            return False

        def f():
            try:
                import Foundation
                import UserNotifications as UN
                bid = str(Foundation.NSBundle.mainBundle().bundleIdentifier() or "")
                if not bid or "python" in bid.lower():
                    raise RuntimeError("Cockpit läuft nicht als App-Paket")
                self.UN = UN
                self.center = UN.UNUserNotificationCenter.currentNotificationCenter()
                self._delegate = _notify_delegate_class().alloc().init()
                self._delegate.notifier = self
                self.center.setDelegate_(self._delegate)

                def done(granted, error):
                    self.granted = bool(granted)
                    if error is not None:
                        print("Mitteilungen:", error)

                opts = UN.UNAuthorizationOptionAlert | UN.UNAuthorizationOptionSound | UN.UNAuthorizationOptionBadge
                self.center.requestAuthorizationWithOptions_completionHandler_(opts, done)
                return True
            except Exception as exc:  # noqa: BLE001
                print("Mitteilungen über AppleScript (", exc, ")")
                self.center = None
                return False
        with self.guard:
            ok = self.mac.on_main(f, timeout=8)
            time.sleep(1.5)      # Absturz direkt nach der Anmeldung abwarten, bevor der Merker fällt
        return ok

    def status(self):
        if self.guard.crashed:
            return {"mode": "script", "granted": True, "safe": True}
        if self.center is None:
            return {"mode": "script", "granted": True}
        return {"mode": "system", "granted": self.granted}

    def deliver(self, title, body="", kind="cockpit", ref="", view="", sound=True):
        title, body = str(title or APP_NAME)[:180], str(body or "")[:600]
        if self.center is not None and self.granted is not False:
            def f():
                UN = self.UN
                content = UN.UNMutableNotificationContent.alloc().init()
                content.setTitle_(title)
                content.setBody_(body)
                content.setThreadIdentifier_(kind)
                content.setUserInfo_({"kind": kind, "ref": ref, "view": view})
                if sound:
                    content.setSound_(UN.UNNotificationSound.defaultSound())
                import uuid
                req = UN.UNNotificationRequest.requestWithIdentifier_content_trigger_(str(uuid.uuid4()), content, None)
                self.center.addNotificationRequest_withCompletionHandler_(req, lambda err: err and print("Mitteilung:", err))
                return True
            if self.mac.on_main(f):
                return True
        return self._script(title, body)

    @staticmethod
    def _script(title, body):
        esc = lambda v: str(v or "").replace("\\", "\\\\").replace('"', '\\"')[:200]
        script = f'display notification "{esc(body)}" with title "{esc(title) or APP_NAME}"'
        try:
            subprocess.run([OSASCRIPT, "-e", script], timeout=10, capture_output=True)
            return True
        except Exception as exc:  # noqa: BLE001
            print("Mitteilung fehlgeschlagen:", exc)
            return False

    def clicked(self, kind, ref, view):
        api = self.api
        if api is None:
            return

        def front():
            app = self.mac.app()
            app.activateIgnoringOtherApps_(True)
            win = getattr(api._window, "native", None)
            if win is not None:
                if win.isMiniaturized():
                    win.deminiaturize_(None)
                win.makeKeyAndOrderFront_(None)
        self.mac.on_main(front)
        target = "whatsapp" if kind == "whatsapp" else (view or "")
        if target:
            try:
                api._window.evaluate_js(f"window.__cockpitOpen && window.__cockpitOpen({json.dumps(target)})")
            except Exception as exc:  # noqa: BLE001
                print("Ansicht öffnen:", exc)
        if kind == "whatsapp" and ref:
            api._wa.click_notification(ref)


# ═════════════════════════════════════════════════════════════ WhatsApp im Cockpit
def unread_from_title(title):
    """„(3) WhatsApp“ → 3, „WhatsApp“ → 0, noch nicht geladen → None."""
    import re
    title = str(title or "").strip()
    if not title:
        return None
    m = re.match(r"^\((\d+)\)", title)
    if m:
        return int(m.group(1))
    return 0 if "whatsapp" in title.lower() else None


def badge_from_lsappinfo(text):
    """Zahl am Dock-Symbol aus `lsappinfo info -only StatusLabel …` lesen."""
    import re
    m = re.search(r'"label"\s*=\s*"([^"]*)"', str(text or ""))
    if not m:
        return 0
    digits = "".join(ch for ch in m.group(1) if ch.isdigit())
    return int(digits) if digits else (1 if m.group(1).strip() else 0)


_WA_DELEGATE = None


def _wa_delegate_class():
    """UI-Delegate der WhatsApp-Ansicht: Links im Browser öffnen, Dateien anhängen, Rückfragen."""
    global _WA_DELEGATE
    if _WA_DELEGATE is not None:
        return _WA_DELEGATE
    import AppKit
    from objc import nil

    class CockpitWhatsAppDelegate(AppKit.NSObject):
        # Links mit target="_blank" (z. B. geteilte Webseiten) im Standard-Browser öffnen
        def webView_createWebViewWithConfiguration_forNavigationAction_windowFeatures_(
                self, webview, config, action, features):
            try:
                url = action.request().URL()
                if url is not None:
                    AppKit.NSWorkspace.sharedWorkspace().openURL_(url)
            except Exception as exc:  # noqa: BLE001
                print("WhatsApp-Link:", exc)
            return nil

        # Dateien/Fotos anhängen
        def webView_runOpenPanelWithParameters_initiatedByFrame_completionHandler_(
                self, webview, param, frame, handler):
            panel = AppKit.NSOpenPanel.openPanel()
            panel.setCanChooseFiles_(True)
            panel.setCanChooseDirectories_(False)
            panel.setAllowsMultipleSelection_(bool(param.allowsMultipleSelection()))
            ok = getattr(AppKit, "NSModalResponseOK", 1)
            if panel.runModal() == ok:
                handler(panel.URLs())
            else:
                handler(nil)

        def webView_runJavaScriptAlertPanelWithMessage_initiatedByFrame_completionHandler_(
                self, webview, message, frame, handler):
            alert = AppKit.NSAlert.alloc().init()
            alert.setMessageText_(str(message))
            alert.runModal()
            handler()

        def webView_runJavaScriptConfirmPanelWithMessage_initiatedByFrame_completionHandler_(
                self, webview, message, frame, handler):
            alert = AppKit.NSAlert.alloc().init()
            alert.setMessageText_(str(message))
            alert.addButtonWithTitle_("OK")
            alert.addButtonWithTitle_("Abbrechen")
            first = getattr(AppKit, "NSAlertFirstButtonReturn", 1000)
            handler(alert.runModal() == first)

    _WA_DELEGATE = CockpitWhatsAppDelegate
    return _WA_DELEGATE


_WA_MSG = None


def _wa_message_class():
    """Nimmt Mitteilungen aus der WhatsApp-Ansicht entgegen."""
    global _WA_MSG
    if _WA_MSG is not None:
        return _WA_MSG
    import AppKit

    class CockpitWhatsAppMessages(AppKit.NSObject):
        def userContentController_didReceiveScriptMessage_(self, controller, message):
            try:
                body = message.body()
                data = {str(k): body[k] for k in body.keys()} if hasattr(body, "keys") else {}
                self.pane.on_message(data)
            except Exception as exc:  # noqa: BLE001
                print("WhatsApp-Mitteilung:", exc)

    _WA_MSG = CockpitWhatsAppMessages
    return _WA_MSG


_FLIPPED = None


def _flipped_view_class():
    """Halter mit Ursprung oben links – damit stimmen die Koordinaten der Oberfläche 1:1."""
    global _FLIPPED
    if _FLIPPED is not None:
        return _FLIPPED
    import AppKit

    class CockpitHostView(AppKit.NSView):
        def isFlipped(self):
            return True

    _FLIPPED = CockpitHostView
    return _FLIPPED


_WA_NAV = None


def _wa_nav_class():
    """Merkt sich Laden, Fehler und Adresse der WhatsApp-Ansicht (für die Diagnose)."""
    global _WA_NAV
    if _WA_NAV is not None:
        return _WA_NAV
    import AppKit

    class CockpitWhatsAppNav(AppKit.NSObject):
        def webView_didStartProvisionalNavigation_(self, webview, nav):
            self.pane.state["loading"] = True

        def webView_didFinishNavigation_(self, webview, nav):
            self.pane.state.update(loading=False, loaded=True, error="")

        def webView_didFailProvisionalNavigation_withError_(self, webview, nav, error):
            self.pane.state.update(loading=False, error=str(error.localizedDescription()))

        def webView_didFailNavigation_withError_(self, webview, nav, error):
            self.pane.state.update(loading=False, error=str(error.localizedDescription()))

        def webViewWebContentProcessDidTerminate_(self, webview):
            self.pane.state["error"] = "WhatsApp-Ansicht abgestürzt – wird neu geladen"
            webview.reload()

    _WA_NAV = CockpitWhatsAppNav
    return _WA_NAV


class WhatsAppPane:
    """WhatsApp Web als eigene, dauerhaft angemeldete Web-Ansicht direkt im Cockpit-Fenster.
    Die Oberfläche (JS) meldet, wo der Rahmen liegt; diese Ansicht wird genau dort eingesetzt.
    Ausweichweg: eigenes Fenster mit derselben Anmeldung."""

    def __init__(self, mac):
        self.mac = mac
        self.pyw = None          # pywebview-Fenster (sein .native ist das NSWindow)
        self.view = None         # eingebettete Ansicht
        self.host = None         # eigener Halter im Fenster (Oberfläche + WhatsApp)
        self.win2 = None         # eigenes WhatsApp-Fenster (Ausweichweg)
        self.view2 = None
        self._keep = []          # Delegates/Handler am Leben halten
        self.notifier = None     # wird in main() gesetzt
        self.notify_on = True    # Schalter „WhatsApp-Mitteilungen“ in Cockpit
        self._recent = {}
        self.state = {"loading": False, "loaded": False, "error": "", "step": ""}
        self.guard = Guard("whatsapp")

    @property
    def window(self):
        win = getattr(self.pyw, "native", None) if self.pyw is not None else None
        if win is None:
            raise RuntimeError("Cockpit-Fenster noch nicht bereit")
        return win

    # ---------- alles ab hier läuft auf dem Hauptthread ----------
    def _new_webview(self):
        import AppKit
        import Foundation
        import WebKit
        cfg = WebKit.WKWebViewConfiguration.alloc().init()
        cfg.setWebsiteDataStore_(WebKit.WKWebsiteDataStore.defaultDataStore())   # Anmeldung bleibt erhalten
        ucc = cfg.userContentController()
        ucc.addUserScript_(WebKit.WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly_(
            WA_NOTIFY_SHIM, WebKit.WKUserScriptInjectionTimeAtDocumentStart, False))
        msgs = _wa_message_class().alloc().init()
        msgs.pane = self
        ucc.addScriptMessageHandler_name_(msgs, "cockpitNotify")
        view = WebKit.WKWebView.alloc().initWithFrame_configuration_(AppKit.NSMakeRect(0, 0, 400, 400), cfg)
        view.setCustomUserAgent_(SAFARI_UA)
        ui = _wa_delegate_class().alloc().init()
        nav = _wa_nav_class().alloc().init()
        nav.pane = self
        view.setUIDelegate_(ui)
        view.setNavigationDelegate_(nav)
        self._keep += [msgs, ui, nav]
        view.loadRequest_(Foundation.NSURLRequest.requestWithURL_(Foundation.NSURL.URLWithString_(WA_URL)))
        return view

    def _ensure_host(self):
        """Eigenen Halter als Inhalt des Fensters einsetzen; die Cockpit-Oberfläche liegt darin
        (füllt alles), WhatsApp kommt obendrauf. So gibt es keine Koordinaten-Überraschungen."""
        import AppKit
        win = self.window
        if self.host is not None and win.contentView() is self.host:
            return self.host
        self.state["step"] = "Halter einsetzen"
        ui = win.contentView()
        host = _flipped_view_class().alloc().initWithFrame_(ui.frame())
        host.setAutoresizesSubviews_(True)
        win.setContentView_(host)
        ui.setFrame_(host.bounds())
        ui.setAutoresizingMask_(AppKit.NSViewWidthSizable | AppKit.NSViewHeightSizable)
        host.addSubview_(ui)
        win.makeFirstResponder_(ui)
        self.ui = ui
        self.host = host
        return host

    def _ensure(self):
        if self.view is not None:
            return self.view
        host = self._ensure_host()
        self.state["step"] = "WhatsApp laden"
        view = self._new_webview()
        view.setHidden_(True)
        try:
            view.setWantsLayer_(True)
            view.layer().setCornerRadius_(16.0)
            view.layer().setMasksToBounds_(True)
        except Exception:  # noqa: BLE001
            pass
        host.addSubview_(view)     # obendrauf
        self.view = view
        self.state["step"] = "eingebettet"
        return view

    @staticmethod
    def _rect(rect):
        import AppKit
        x, y = float(rect.get("x", 0)), float(rect.get("y", 0))
        w, h = max(10.0, float(rect.get("w", 10))), max(10.0, float(rect.get("h", 10)))
        return AppKit.NSMakeRect(x, y, w, h)    # Halter ist „flipped“: Ursprung oben links wie im Browser

    def _run(self, fn):
        """Auf dem Hauptthread ausführen und Fehler für die Diagnose festhalten."""
        def wrapped():
            try:
                return fn()
            except Exception as exc:  # noqa: BLE001
                self.state["error"] = f"{type(exc).__name__}: {exc}"
                print("WhatsApp:", self.state["error"])
                return False
        return self.mac.on_main(wrapped)

    def _blocked(self):
        if self.guard.crashed:
            self.state["error"] = ("Das Einbetten ist beim letzten Mal abgestürzt und wurde abgeschaltet. "
                                   "Nutze „Eigenes Fenster“ oder schalte es unter Einstellungen › Diagnose wieder ein.")
            return True
        return False

    def _guarded_ensure(self):
        if self.view is not None:
            return self.view
        self.guard.__enter__()
        view = self._ensure()
        self.guard.disarm_later(8)
        return view

    def show(self, rect):
        if self._blocked():
            return False

        def f():
            view = self._guarded_ensure()
            view.setFrame_(self._rect(rect))
            view.setHidden_(False)
            self.window.makeFirstResponder_(view)
            return True
        return self._run(f)

    def move(self, rect):
        return self._run(lambda: (self.view.setFrame_(self._rect(rect)) if self.view is not None else None) or True)

    def hide(self):
        def f():
            if self.view is not None:
                self.view.setHidden_(True)
                ui = getattr(self, "ui", None)
                if ui is not None:
                    self.window.makeFirstResponder_(ui)
            return True
        return self._run(f)

    def preload(self):
        if self._blocked():
            return False
        return self._run(lambda: bool(self._guarded_ensure()))

    def reload(self):
        def f():
            for v in (self.view, self.view2):
                if v is not None:
                    v.reload()
            return True
        return self._run(f)

    def open_window(self):
        """Ausweichweg: WhatsApp in einem eigenen Cockpit-Fenster (gleiche Anmeldung, gleiche Mitteilungen)."""
        def f():
            import AppKit
            if self.win2 is not None:
                self.win2.makeKeyAndOrderFront_(None)
                return True
            mask = (AppKit.NSWindowStyleMaskTitled | AppKit.NSWindowStyleMaskClosable
                    | AppKit.NSWindowStyleMaskResizable | AppKit.NSWindowStyleMaskMiniaturizable)
            win = AppKit.NSWindow.alloc().initWithContentRect_styleMask_backing_defer_(
                AppKit.NSMakeRect(0, 0, 1100, 760), mask, AppKit.NSBackingStoreBuffered, False)
            win.setTitle_("WhatsApp – Cockpit")
            win.setReleasedWhenClosed_(False)
            win.setMinSize_(AppKit.NSSize(640, 480))
            g = Guard("whatsapp-fenster").__enter__()
            view = self._new_webview()
            win.setContentView_(view)
            g.disarm_later(8)
            win.center()
            win.setFrameAutosaveName_("CockpitWhatsApp")
            win.makeKeyAndOrderFront_(None)
            self.win2, self.view2 = win, view
            return True
        return self._run(f)

    def debug(self):
        out = self._debug()
        key = json.dumps({k: out.get(k) for k in ("embedded", "error", "step", "url", "hidden", "frame", "host", "loaded")}, sort_keys=True)
        if key != getattr(self, "_last_debug", None):
            self._last_debug = key
            print("WhatsApp-Zustand:", key)
        return out

    def _debug(self):
        def f():
            out = dict(self.state)
            out["embedded"] = self.view is not None
            out["safe"] = bool(self.guard.crashed)
            out["window"] = self.win2 is not None and bool(self.win2.isVisible())
            v = self.view or self.view2
            if v is not None:
                fr = v.frame()
                out.update(url=str(v.URL().absoluteString()) if v.URL() else "", title=str(v.title() or ""),
                           hidden=bool(v.isHidden()), progress=round(float(v.estimatedProgress()), 2),
                           frame=[round(fr.origin.x), round(fr.origin.y), round(fr.size.width), round(fr.size.height)])
            if self.host is not None:
                out["host"] = [round(self.host.bounds().size.width), round(self.host.bounds().size.height)]
            return out
        return self._run(f) or dict(self.state)

    def title(self):
        def f():
            v = self.view or self.view2
            return str(v.title() or "") if v is not None else ""
        return self._run(f) or ""

    def on_message(self, data):
        """Eine Web-Mitteilung von WhatsApp: als macOS-Mitteilung zeigen."""
        if data.get("close") or not self.notify_on or self.notifier is None:
            return
        title, body = str(data.get("title") or "WhatsApp"), str(data.get("body") or "")
        # gleiche Nachricht nicht doppelt melden (eingebettet + eigenes Fenster, oder WhatsApp meldet zweimal)
        key, now = title + "|" + body, time.time()
        self._recent = {k: t for k, t in self._recent.items() if now - t < 10}
        if key in self._recent:
            return
        self._recent[key] = now
        # Läuft die WhatsApp-App, meldet sie sich selbst
        if whatsapp_desktop().get("running"):
            return
        threading.Thread(target=self.notifier.deliver, args=(title, body, "whatsapp", str(data.get("id") or ""), "whatsapp",
                                                             not data.get("silent")), daemon=True).start()

    def click_notification(self, ref):
        def f():
            js = f"window.__cockpitNotifyClick && window.__cockpitNotifyClick({json.dumps(ref)})"
            for v in (self.view, self.view2):
                if v is not None:
                    v.evaluateJavaScript_completionHandler_(js, None)
            return True
        self._run(f)


def whatsapp_desktop():
    """Läuft die WhatsApp-App? Dann die Zahl an ihrem Dock-Symbol."""
    try:
        import AppKit
        running = [a for a in AppKit.NSWorkspace.sharedWorkspace().runningApplications()
                   if str(a.bundleIdentifier() or "") in WA_DESKTOP_IDS or str(a.localizedName() or "") == "WhatsApp"]
    except Exception:  # noqa: BLE001
        running = []
    if not running:
        return {"running": False, "count": None}
    try:
        out = subprocess.run(["/usr/bin/lsappinfo", "info", "-only", "StatusLabel", "WhatsApp"],
                             capture_output=True, text=True, timeout=5).stdout
    except Exception:  # noqa: BLE001
        out = ""
    return {"running": True, "count": badge_from_lsappinfo(out)}


# ═════════════════════════════════════════════════════════════ Google-Konto & Synchronisieren
FB_API_KEY = "AIzaSyAt35KpU63iGk8UAX5X4T5Vj18zPf_JUus"     # öffentlicher Web-Schlüssel von buildspace (steht auch in protect.js)
FB_PROJECT = "kanban-board-281da"
FS_BASE = f"https://firestore.googleapis.com/v1/projects/{FB_PROJECT}/databases/(default)/documents"
LOGIN_PAGE = "https://buildspaceos.de/cockpit/anmelden.html"
ACCOUNT_FILE = SUPPORT_DIR / "konto.json"


def _https_context():
    import ssl
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        return ssl.create_default_context()


class Account:
    """Hält die Google-Anmeldung der Mac-App. Angemeldet wird im normalen Browser auf
    buildspaceos.de; die Seite gibt die Anmeldung an einen kurzlebigen Empfänger auf
    127.0.0.1 zurück (nur dieser Mac). Gespeichert wird nur der Erneuerungs-Schlüssel."""

    def __init__(self):
        self.data = {}
        self.id_token, self.expires = "", 0.0
        self._lock = threading.Lock()
        self._server = None
        self._nonce = ""
        try:
            self.data = json.loads(ACCOUNT_FILE.read_text("utf-8"))
        except Exception:  # noqa: BLE001
            self.data = {}

    def signed_in(self):
        return bool(self.data.get("rt") and self.data.get("uid"))

    def status(self):
        return {"signed_in": self.signed_in(), "uid": self.data.get("uid", ""), "email": self.data.get("email", ""),
                "name": self.data.get("name", "")}

    def _save(self):
        SUPPORT_DIR.mkdir(parents=True, exist_ok=True)
        tmp = ACCOUNT_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data), "utf-8")
        os.chmod(tmp, 0o600)
        os.replace(tmp, ACCOUNT_FILE)

    def logout(self):
        self.data, self.id_token, self.expires = {}, "", 0.0
        try:
            ACCOUNT_FILE.unlink(missing_ok=True)
        except OSError:
            pass
        return True

    def login(self):
        import http.server
        import secrets
        import socketserver
        import urllib.parse
        if self._server is not None:
            try:
                self._server.shutdown()
            except Exception:  # noqa: BLE001
                pass
        self._nonce = secrets.token_urlsafe(18)
        acc = self

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                self._answer({})

            def do_POST(self):
                n = min(int(self.headers.get("Content-Length") or 0), 20000)
                q = dict(urllib.parse.parse_qsl(self.rfile.read(n).decode("utf-8", "replace")))
                self._answer(q)

            def _answer(self, q):
                u = urllib.parse.urlparse(self.path)
                import hmac
                ok = (u.path == "/fertig" and bool(q.get("rt")) and bool(q.get("uid"))
                      and hmac.compare_digest(str(q.get("nonce", "")), acc._nonce))
                if ok:
                    acc.data = {"rt": q["rt"], "uid": q["uid"], "email": q.get("email", ""), "name": q.get("name", "")}
                    acc.id_token, acc.expires = "", 0.0
                    acc._save()
                body = ("<!doctype html><meta charset=utf-8><title>Cockpit</title><body style='font:16px -apple-system,sans-serif;"
                        "background:#0b0b14;color:#fff;display:grid;place-items:center;height:100vh;margin:0;text-align:center'>"
                        + ("<div><h2>Cockpit ist verbunden ✓</h2><p>Du kannst dieses Fenster schließen.</p></div>" if ok else
                           "<div><h2>Das hat nicht geklappt</h2><p>Bitte in Cockpit noch einmal auf „Mit Google anmelden“ tippen.</p></div>")
                        + "<script>setTimeout(function(){window.close()},2500)</script></body>")
                data = body.encode("utf-8")
                self.send_response(200 if ok else 400)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                if ok:
                    threading.Thread(target=self.server.shutdown, daemon=True).start()

        class Server(socketserver.TCPServer):
            allow_reuse_address = True

        srv = Server(("127.0.0.1", 0), Handler)
        self._server = srv
        port = srv.server_address[1]
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        t = threading.Timer(600, srv.shutdown)       # nach 10 Minuten aufräumen
        t.daemon = True
        t.start()
        url = f"{LOGIN_PAGE}?port={port}&nonce={urllib.parse.quote(self._nonce)}"
        subprocess.run([OPEN, url])
        return {"ok": True}

    def token(self):
        """Gültiges ID-Token holen (wird mit dem Erneuerungs-Schlüssel automatisch erneuert)."""
        import urllib.error
        import urllib.parse
        import urllib.request
        with self._lock:
            if not self.signed_in():
                return None
            if self.id_token and time.time() < self.expires - 120:
                return self.id_token
            body = urllib.parse.urlencode({"grant_type": "refresh_token", "refresh_token": self.data["rt"]}).encode()
            req = urllib.request.Request(f"https://securetoken.googleapis.com/v1/token?key={FB_API_KEY}", data=body,
                                         headers={"Content-Type": "application/x-www-form-urlencoded"})
            try:
                with urllib.request.urlopen(req, timeout=20, context=_https_context()) as r:
                    j = json.loads(r.read().decode())
            except urllib.error.HTTPError as err:
                if err.code in (400, 401, 403):     # Anmeldung zurückgezogen/abgelaufen
                    print("Anmeldung ungültig – bitte neu anmelden")
                    self.logout()
                return None
            except Exception as exc:  # noqa: BLE001   (offline o. Ä.)
                print("Token erneuern:", exc)
                return None
            self.id_token = j.get("id_token", "")
            self.expires = time.time() + int(j.get("expires_in", 3600))
            if j.get("refresh_token") and j["refresh_token"] != self.data.get("rt"):
                self.data["rt"] = j["refresh_token"]
                self._save()
            return self.id_token

    def request(self, method, path, body):
        import urllib.error
        import urllib.request
        method = str(method or "GET").upper()
        path = str(path or "")
        uid = self.data.get("uid", "")
        # nur die eigenen Cockpit-Daten (oder die Sammel-Endpunkte) – nichts anderes
        if not (path in (":commit", ":batchGet") or (uid and path.startswith(f"/cockpit/{uid}/") and ".." not in path)):
            return {"ok": False, "status": 400, "text": "unzulässiger Pfad"}
        if method not in ("GET", "POST", "PATCH", "DELETE"):
            return {"ok": False, "status": 400, "text": "unzulässige Methode"}
        tok = self.token()
        if not tok:
            return {"ok": False, "status": 401, "text": "nicht angemeldet"}
        data = body.encode("utf-8") if body else None
        req = urllib.request.Request(FS_BASE + path, data=data, method=method,
                                     headers={"Authorization": "Bearer " + tok, "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=60, context=_https_context()) as r:
                return {"ok": True, "status": r.status, "text": r.read().decode("utf-8")}
        except urllib.error.HTTPError as err:
            return {"ok": False, "status": err.code, "text": err.read().decode("utf-8", "replace")[:4000]}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "status": 0, "text": str(exc)}


# ═════════════════════════════════════════════════════════════ cockpit://-Links
_URL_HANDLER = None


def _url_handler_class():
    """Öffnet Cockpit über cockpit://<bereich> (z. B. aus der Browser-Version: cockpit://whatsapp)."""
    global _URL_HANDLER
    if _URL_HANDLER is not None:
        return _URL_HANDLER
    import AppKit

    class CockpitURLHandler(AppKit.NSObject):
        def handleGetURLEvent_withReplyEvent_(self, event, reply):
            try:
                url = str(event.paramDescriptorForKeyword_(0x2D2D2D2D).stringValue() or "")   # keyDirectObject '----'
                view = url.split("://", 1)[-1].strip("/").split("/")[0].split("?")[0] or "start"
                view = "".join(ch for ch in view if ch.isalnum())[:20] or "start"
                threading.Thread(target=self.api._open_view, args=(view,), daemon=True).start()
            except Exception as exc:  # noqa: BLE001
                print("cockpit://-Link:", exc)

    _URL_HANDLER = CockpitURLHandler
    return _URL_HANDLER


def register_url_handler(mac, api):
    def f():
        import AppKit
        h = _url_handler_class().alloc().init()
        h.api = api
        api._url_handler = h
        gurl = 0x4755524C   # 'GURL' (Event-Klasse und -ID)
        AppKit.NSAppleEventManager.sharedAppleEventManager().setEventHandler_andSelector_forEventClass_andEventID_(
            h, "handleGetURLEvent:withReplyEvent:", gurl, gurl)
        return True
    try:
        mac.on_main(f)
    except Exception as exc:  # noqa: BLE001
        print("cockpit://-Links nicht verfügbar:", exc)


# ═════════════════════════════════════════════════════════════ Kalender
class Calendar:
    """Liest die heutigen Termine über EventKit. Fragt nur nach Erlaubnis,
    wenn du in der App auf „Kalender verbinden“ klickst."""

    def __init__(self):
        self._store = None
        self._lock = threading.Lock()

    def _ek(self):
        import EventKit  # noqa: WPS433
        return EventKit

    def store(self):
        with self._lock:
            if self._store is None:
                self._store = self._ek().EKEventStore.alloc().init()
            return self._store

    def state(self):
        EK = self._ek()
        status = int(EK.EKEventStore.authorizationStatusForEntityType_(EK.EKEntityTypeEvent))
        # 0 = noch nicht gefragt, 1 = eingeschränkt, 2 = abgelehnt,
        # 3 = voller Zugriff (früher „authorized“), 4 = nur schreiben
        if status == 0:
            return "ask"
        if status == 3:
            return "ok"
        return "denied"

    def request(self):
        done, box = threading.Event(), {"ok": False}

        def handler(granted, error):
            box["ok"] = bool(granted)
            done.set()

        store = self.store()
        try:
            if hasattr(store, "requestFullAccessToEventsWithCompletion_"):   # macOS 14+
                store.requestFullAccessToEventsWithCompletion_(handler)
            else:
                store.requestAccessToEntityType_completion_(self._ek().EKEntityTypeEvent, handler)
        except Exception as exc:  # noqa: BLE001
            print("Kalender-Anfrage fehlgeschlagen:", exc)
            return False
        done.wait(120)
        with self._lock:
            self._store = None   # nach der Freigabe frisch verbinden
        return box["ok"]

    def today(self):
        return self.day(None)

    def day(self, day_iso):
        """Termine eines Tages (JJJJ-MM-TT, None = heute)."""
        import AppKit
        import Foundation
        store = self.store()
        cal = Foundation.NSCalendar.currentCalendar()
        ref = Foundation.NSDate.date()
        if day_iso:
            import datetime
            d = datetime.datetime.strptime(str(day_iso)[:10], "%Y-%m-%d").replace(hour=12)
            ref = Foundation.NSDate.dateWithTimeIntervalSince1970_(d.timestamp())
        start = cal.startOfDayForDate_(ref)
        end = start.dateByAddingTimeInterval_(24 * 3600)
        pred = store.predicateForEventsWithStartDate_endDate_calendars_(start, end, None)
        events = store.eventsMatchingPredicate_(pred) or []
        out = []
        for e in events:
            color = "#4F7BFF"
            try:
                c = e.calendar().color().colorUsingColorSpace_(AppKit.NSColorSpace.sRGBColorSpace())
                color = "#%02X%02X%02X" % (round(c.redComponent() * 255), round(c.greenComponent() * 255),
                                           round(c.blueComponent() * 255))
            except Exception:  # noqa: BLE001
                pass
            out.append({
                "title": str(e.title() or "Ohne Titel"),
                "start": float(e.startDate().timeIntervalSince1970()),
                "end": float(e.endDate().timeIntervalSince1970()),
                "allDay": bool(e.isAllDay()),
                "location": str(e.location() or ""),
                "calendar": str(e.calendar().title() or "") if e.calendar() else "",
                "color": color,
            })
        out.sort(key=lambda x: (not x["allDay"], x["start"]))
        return out


# ═════════════════════════════════════════════════════════════ Schnittstelle zur Oberfläche
class Api:
    """Alle Methoden sind aus der Oberfläche als window.pywebview.api.<name>() erreichbar."""

    def __init__(self, mac):
        self._mac = mac
        self._window = None
        self._quitting = False
        self._cal = Calendar()
        self._wa = WhatsAppPane(mac)
        self._account = Account()
        self._notifier = Notifier(mac)
        self._notifier.api = self
        self._wa.notifier = self._notifier
        self._state_lock = threading.Lock()
        self._saved = threading.Event()

    # -- Speicher
    def load_state(self):
        """Liest die gespeicherten Einstellungen. Ist state.json beschädigt oder fehlt,
        wird die Sicherungskopie vom letzten erfolgreichen Speichern genommen."""
        for f in (STATE_FILE, BACKUP_FILE):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    if f is BACKUP_FILE:
                        print("state.json fehlte oder war beschädigt – Sicherungskopie geladen")
                    return data
            except FileNotFoundError:
                continue
            except Exception as exc:  # noqa: BLE001
                print(f"{f.name} unlesbar:", exc)
        return {}

    def save_state(self, state):
        with self._state_lock:
            try:
                SUPPORT_DIR.mkdir(parents=True, exist_ok=True)
                if not isinstance(state, dict):
                    return False
                text = json.dumps(state, ensure_ascii=False)
                tmp = STATE_FILE.with_suffix(".tmp")
                with open(tmp, "w", encoding="utf-8") as fh:
                    fh.write(text)
                    fh.flush()
                    os.fsync(fh.fileno())
                if STATE_FILE.exists():
                    os.replace(STATE_FILE, BACKUP_FILE)   # letzte gute Fassung aufheben
                os.replace(tmp, STATE_FILE)
                self._saved.set()
                return True
            except Exception as exc:  # noqa: BLE001
                print("Speichern fehlgeschlagen:", exc)
                return False

    # -- Öffnen
    def open_url(self, url):
        url = str(url or "").strip()
        if not url.lower().startswith(ALLOWED_SCHEMES):
            return {"ok": False, "error": "Diese Adresse kann Cockpit nicht öffnen."}
        r = subprocess.run([OPEN, url], capture_output=True, text=True)
        if r.returncode != 0:
            if url.startswith("shortcuts://"):
                return {"ok": False, "error": "Der Kurzbefehl wurde nicht gefunden."}
            return {"ok": False, "error": "Die Adresse ließ sich nicht öffnen."}
        return {"ok": True}

    def open_app(self, spec):
        spec = spec or {}
        bundle, name = str(spec.get("bundle") or ""), str(spec.get("name") or "").strip()
        if bundle and subprocess.run([OPEN, "-b", bundle], capture_output=True).returncode == 0:
            return {"ok": True}
        if name and subprocess.run([OPEN, "-a", name], capture_output=True).returncode == 0:
            return {"ok": True}
        return {"ok": False, "error": f"„{name or bundle}“ ist auf diesem Mac nicht installiert."}

    def list_apps(self):
        names = set()
        for folder in APP_FOLDERS:
            try:
                for entry in os.scandir(folder):
                    if entry.name.endswith(".app"):
                        names.add(entry.name[:-4])
            except OSError:
                pass
        return sorted(names, key=str.casefold)

    def copy(self, text):
        try:
            subprocess.run(["/usr/bin/pbcopy"], input=str(text or ""), text=True, check=True,
                           env={**os.environ, "LANG": "de_DE.UTF-8"})
            return True
        except Exception:  # noqa: BLE001
            return False

    # -- Erinnerungen
    def add_reminder(self, text):
        text = str(text or "").strip()
        if not text:
            return {"ok": False, "error": "Erst etwas eingeben."}
        script = ['on run argv',
                  'tell application id "com.apple.reminders" to make new reminder with properties {name:(item 1 of argv)}',
                  'end run']
        args = ["/usr/bin/osascript"]
        for line in script:
            args += ["-e", line]
        r = subprocess.run(args + ["--", text[:500]], capture_output=True, text=True, timeout=60)
        if r.returncode == 0:
            return {"ok": True}
        err = r.stderr or ""
        print("Erinnerung fehlgeschlagen:", err.strip())
        if "-1743" in err or "nicht erlaubt" in err or "not allowed" in err:
            subprocess.run([OPEN, PRIVACY["automation"]])
            return {"ok": False, "error": "Bitte erlaube Cockpit, „Erinnerungen“ zu steuern (Automation)."}
        return {"ok": False, "error": "Die Erinnerung konnte nicht angelegt werden."}

    # -- Kalender
    def today_events(self):
        try:
            state = self._cal.state()
            if state != "ok":
                return {"state": state}
            return {"state": "ok", "events": self._cal.today()}
        except ImportError:
            return {"state": "error", "error": "Der Kalender-Baustein fehlt. Bitte Installieren.command erneut ausführen."}
        except Exception as exc:  # noqa: BLE001
            print("Termine fehlgeschlagen:", exc)
            return {"state": "error", "error": "Termine konnten nicht geladen werden."}

    def events(self, day_iso):
        try:
            state = self._cal.state()
            if state != "ok":
                return {"state": state}
            return {"state": "ok", "events": self._cal.day(day_iso)}
        except ImportError:
            return {"state": "error", "error": "Der Kalender-Baustein fehlt. Bitte Installieren.command erneut ausführen."}
        except Exception as exc:  # noqa: BLE001
            print("Termine fehlgeschlagen:", exc)
            return {"state": "error", "error": "Termine konnten nicht geladen werden."}

    # -- Internet: Kalender-Abos (iCal), buildspace-Beiträge, Aufrufzahlen
    def fetch_text(self, url):
        import ssl
        import urllib.error
        import urllib.request
        url = str(url or "").strip()
        if url.lower().startswith("webcal://"):
            url = "https://" + url[9:]
        if not url.lower().startswith(("https://", "http://")):
            return {"ok": False, "error": "Nur http- und https-Adressen."}
        try:
            try:
                import certifi
                ctx = ssl.create_default_context(cafile=certifi.where())
            except ImportError:
                ctx = ssl.create_default_context()
            req = urllib.request.Request(url, headers={"User-Agent": "Cockpit/" + VERSION})
            try:
                res = urllib.request.urlopen(req, timeout=20, context=ctx)
            except urllib.error.HTTPError as err:   # Antwort trotzdem weitergeben (z. B. Fehlermeldung als JSON)
                res = err
            data = res.read(8 * 1024 * 1024 + 1)
            if len(data) > 8 * 1024 * 1024:
                return {"ok": False, "error": "Die Datei ist zu groß."}
            charset = res.headers.get_content_charset() or "utf-8"
            return {"ok": True, "status": getattr(res, "status", 200), "text": data.decode(charset, "replace")}
        except Exception as exc:  # noqa: BLE001
            print("Laden fehlgeschlagen:", url, exc)
            return {"ok": False, "error": "Die Adresse ist nicht erreichbar."}

    # -- Mitteilungen
    def notify(self, title, text="", view=""):
        return self._notifier.deliver(title, text, "cockpit", "", str(view or ""))

    def notify_status(self):
        return self._notifier.status()

    def wa_set_notify(self, on):
        self._wa.notify_on = bool(on)
        return True

    # -- Dateien (PDFs und Bilder zum Bearbeiten)
    def _file_path(self, fid):
        fid = "".join(ch for ch in str(fid) if ch.isalnum() or ch in "-_")[:64]
        if not fid:
            raise ValueError("ungültige Kennung")
        return FILES_DIR / fid

    def file_save(self, fid, name, data_url):
        try:
            head, _, b64 = str(data_url).partition(",")
            if not head.startswith("data:") or not b64:
                return {"ok": False, "error": "Ungültige Datei."}
            FILES_DIR.mkdir(parents=True, exist_ok=True)
            path = self._file_path(fid)
            path.write_bytes(base64.b64decode(b64))
            path.with_suffix(".meta").write_text(json.dumps({"name": str(name), "type": head[5:].split(";")[0]}), "utf-8")
            return {"ok": True}
        except Exception as exc:  # noqa: BLE001
            print("Datei speichern fehlgeschlagen:", exc)
            return {"ok": False, "error": "Die Datei konnte nicht gespeichert werden."}

    def file_load(self, fid):
        try:
            path = self._file_path(fid)
            meta = {}
            try:
                meta = json.loads(path.with_suffix(".meta").read_text("utf-8"))
            except Exception:  # noqa: BLE001
                pass
            mime = meta.get("type") or "application/octet-stream"
            return {"ok": True, "data": f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode()}
        except FileNotFoundError:
            return {"ok": False, "error": "Datei nicht gefunden."}
        except Exception as exc:  # noqa: BLE001
            print("Datei laden fehlgeschlagen:", exc)
            return {"ok": False, "error": "Die Datei konnte nicht geladen werden."}

    def file_list(self):
        try:
            return [p.name for p in FILES_DIR.iterdir() if p.suffix != ".meta"] if FILES_DIR.exists() else []
        except Exception:  # noqa: BLE001
            return []

    def file_delete(self, fid):
        try:
            path = self._file_path(fid)
            path.unlink(missing_ok=True)
            path.with_suffix(".meta").unlink(missing_ok=True)
            return True
        except Exception:  # noqa: BLE001
            return False

    def save_download(self, name, data_url):
        """Speichert eine Datei (z. B. bearbeitetes PDF, Whiteboard als Bild) in „Downloads“."""
        try:
            head, _, b64 = str(data_url).partition(",")
            if not head.startswith("data:") or not b64:
                return {"ok": False, "error": "Ungültige Datei."}
            clean = "".join(ch for ch in str(name) if ch not in '/\\:\0').strip() or "Cockpit-Datei"
            downloads = Path.home() / "Downloads"
            downloads.mkdir(exist_ok=True)
            stem, dot, ext = clean.rpartition(".")
            if not dot:
                stem, ext = clean, ""
            target, n = downloads / clean, 2
            while target.exists():
                target = downloads / (f"{stem} {n}.{ext}" if ext else f"{stem} {n}")
                n += 1
            target.write_bytes(base64.b64decode(b64))
            subprocess.run([OPEN, "-R", str(target)])
            return {"ok": True, "name": target.name}
        except Exception as exc:  # noqa: BLE001
            print("Download fehlgeschlagen:", exc)
            return {"ok": False, "error": "Speichern in „Downloads“ fehlgeschlagen."}

    # -- WhatsApp im Cockpit (eigene Web-Ansicht im Fenster)
    def wa_show(self, rect):
        try:
            ok = bool(self._wa.show(rect or {}))
            return {"ok": ok, "error": "" if ok else (self._wa.state.get("error") or "unbekannter Fehler")}
        except Exception as exc:  # noqa: BLE001
            print("WhatsApp anzeigen fehlgeschlagen:", exc)
            return {"ok": False, "error": "WhatsApp konnte nicht eingebettet werden."}

    def wa_move(self, rect):
        try:
            self._wa.move(rect or {})
        except Exception as exc:  # noqa: BLE001
            print("WhatsApp verschieben:", exc)
        return True

    def wa_hide(self):
        try:
            self._wa.hide()
        except Exception as exc:  # noqa: BLE001
            print("WhatsApp ausblenden:", exc)
        return True

    def wa_preload(self):
        try:
            return bool(self._wa.preload())
        except Exception as exc:  # noqa: BLE001
            print("WhatsApp vorladen:", exc)
            return False

    def safe_reset(self):
        """Abgeschaltete Bausteine wieder einschalten (wirkt nach dem nächsten Start)."""
        self._wa.guard.reset()
        self._notifier.guard.reset()
        return True

    def safe_status(self):
        return {"whatsapp": bool(self._wa.guard.crashed), "mitteilungen": bool(self._notifier.guard.crashed)}

    def _open_view(self, view):
        """Cockpit nach vorne holen und einen Bereich zeigen (für cockpit://-Links)."""
        def front():
            app = self._mac.app()
            app.activateIgnoringOtherApps_(True)
            win = getattr(self._window, "native", None)
            if win is not None:
                if win.isMiniaturized():
                    win.deminiaturize_(None)
                win.makeKeyAndOrderFront_(None)
        self._mac.on_main(front)
        for _ in range(20):          # beim Kaltstart warten, bis die Oberfläche bereit ist
            try:
                if self._window.evaluate_js("typeof window.__cockpitOpen === 'function'"):
                    self._window.evaluate_js(f"window.__cockpitOpen({json.dumps(view)})")
                    return
            except Exception:  # noqa: BLE001
                pass
            time.sleep(0.5)

    # -- Google-Konto & Synchronisieren
    def cloud_login(self):
        try:
            return self._account.login()
        except Exception as exc:  # noqa: BLE001
            print("Anmeldung:", exc)
            return {"ok": False, "error": "Die Anmeldung konnte nicht gestartet werden."}

    def cloud_status(self):
        return self._account.status()

    def cloud_logout(self):
        return self._account.logout()

    def cloud_token(self):
        st = self._account.status()
        if not st["signed_in"]:
            return {"ok": False}
        tok = self._account.token()
        return {"ok": bool(tok), "uid": st["uid"], "email": st["email"], "name": st["name"], "token": ""}

    def cloud(self, method, path, body=""):
        return self._account.request(method, path, body)

    def wa_window(self):
        return {"ok": bool(self._wa.open_window()), "error": self._wa.state.get("error", "")}

    def wa_debug(self):
        try:
            return self._wa.debug()
        except Exception as exc:  # noqa: BLE001
            return {"error": str(exc)}

    def wa_reload(self):
        try:
            self._wa.reload()
        except Exception:  # noqa: BLE001
            pass
        return True

    def wa_status(self):
        """Ungelesene Chats: aus der eingebetteten Ansicht (Fenstertitel) und vom Dock-Symbol der App."""
        try:
            web = unread_from_title(self._wa.title())
        except Exception:  # noqa: BLE001
            web = None
        return {"web": web, "desktop": whatsapp_desktop()}

    def request_calendar(self):
        try:
            return self._cal.request()
        except Exception as exc:  # noqa: BLE001
            print("Kalender-Freigabe fehlgeschlagen:", exc)
            return False

    def open_privacy(self, kind):
        url = PRIVACY.get(str(kind))
        if url:
            subprocess.run([OPEN, url])
        return True

    def version(self):
        return VERSION

    # -- Persönlich: App-Symbol im Dock und Fenstertitel
    def set_icon(self, data_url):
        """data_url = Bild als data:-URL (eigenes oder gestaltetes Symbol) oder None für das Standard-Symbol."""
        try:
            if not data_url:
                CUSTOM_ICON.unlink(missing_ok=True)
                self._mac.set_dock_icon(ICON_FILE)
                return True
            head, _, b64 = str(data_url).partition(",")
            if not head.startswith("data:image/") or not b64:
                return False
            SUPPORT_DIR.mkdir(parents=True, exist_ok=True)
            raw = base64.b64decode(b64)
            if CUSTOM_ICON.exists() and CUSTOM_ICON.read_bytes() == raw:
                return True
            CUSTOM_ICON.write_bytes(raw)
            self._mac.set_dock_icon(CUSTOM_ICON)
            return True
        except Exception as exc:  # noqa: BLE001
            print("Symbol setzen fehlgeschlagen:", exc)
            return False

    def set_title(self, title):
        try:
            title = str(title or APP_NAME).strip()[:40] or APP_NAME
            if self._window:
                self._window.set_title(title)
            return True
        except Exception as exc:  # noqa: BLE001
            print("Titel setzen fehlgeschlagen:", exc)
            return False

    # -- Beenden
    def _on_closing(self):
        if not self._quitting:
            threading.Thread(target=self._quit, daemon=True).start()
        return False

    def _flush_ui(self):
        """Vor dem Beenden: noch nicht gespeicherte Änderungen aus dem Fenster holen."""
        try:
            if not self._window:
                return
            pending = self._window.evaluate_js("window.__cockpitPending ? window.__cockpitPending() : false")
            if pending:
                self._saved.clear()
                self._window.evaluate_js("window.__cockpitFlush && (window.__cockpitFlush(), true)")
                self._saved.wait(2)
        except Exception as exc:  # noqa: BLE001
            print("Speichern vor dem Beenden fehlgeschlagen:", exc)

    def _quit(self):
        if self._quitting:
            return
        self._quitting = True
        self._flush_ui()
        time.sleep(0.05)
        print("Beendet")
        try:
            sys.stdout.flush()
        except Exception:  # noqa: BLE001
            pass
        os._exit(0)


# ═════════════════════════════════════════════════════════════ Start
def main():
    import webview

    SUPPORT_DIR.mkdir(parents=True, exist_ok=True)
    try:   # Links mit target="_blank" im normalen Browser öffnen statt im App-Fenster
        webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True
    except Exception:  # noqa: BLE001
        pass
    mac = Mac()
    api = Api(mac)
    window = webview.create_window(
        APP_NAME, url=str(UI_FILE), js_api=api,
        width=1320, height=880, min_size=(760, 560),
        background_color="#06060D", text_select=True)
    api._window = window
    api._wa.pyw = window
    window.events.closing += api._on_closing

    def on_ready():
        mac.set_dock_icon(CUSTOM_ICON if CUSTOM_ICON.exists() else ICON_FILE)
        mac.on_cmd_q(api._quit)
        register_url_handler(mac, api)
        threading.Thread(target=lambda: (time.sleep(1.0), api._notifier.setup()), daemon=True).start()

    # Fensterspeicher dauerhaft machen (pywebview löscht ihn sonst bei jedem Beenden).
    # Die eigentlichen Daten liegen ohnehin in state.json – das hier ist das zweite Netz.
    try:
        WEB_DATA.mkdir(parents=True, exist_ok=True)
        webview.start(on_ready, private_mode=False, storage_path=str(WEB_DATA))
    except TypeError:   # sehr alte pywebview-Version ohne diese Optionen
        webview.start(on_ready)
    os._exit(0)


if __name__ == "__main__":
    main()
