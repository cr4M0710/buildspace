# Wird von Python beim Start automatisch geladen.
# Startet die App nur, wenn macOS sie als „Cockpit.app“ öffnet
# (dann setzt die Info.plist COCKPIT_RUN=1). Der Python-Interpreter liegt
# dabei als Programmdatei direkt in der App, ohne Startargumente – er liest
# sein Programm daher von der Standardeingabe. Die wird hier auf launch.py gelegt.
import os

if os.environ.pop("COCKPIT_RUN", None) == "1":
    _launch = os.path.join(os.path.dirname(os.path.abspath(__file__)), "launch.py")
    if os.path.exists(_launch):
        _fd = os.open(_launch, os.O_RDONLY)
        os.dup2(_fd, 0)
        os.close(_fd)
