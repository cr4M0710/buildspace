/* Ersatz-Starter für Cockpit (nur genutzt, wenn das Kopieren des
 * Python-Interpreters nicht klappt). Lädt Python direkt in diesen Prozess,
 * damit macOS die Freigaben „Cockpit“ zuordnet. LIBPYTHON und LAUNCH_SCRIPT
 * kommen aus stub_config.h, das der Installer erzeugt. */
#include <dlfcn.h>
#include <stdio.h>
#include "stub_config.h"

int main(int argc, char **argv) {
    void *h = dlopen(LIBPYTHON, RTLD_NOW | RTLD_GLOBAL);
    if (!h) { fprintf(stderr, "Python nicht ladbar: %s\n", dlerror()); return 70; }
    int (*py_main)(int, char **) = (int (*)(int, char **))dlsym(h, "Py_BytesMain");
    if (!py_main) { fprintf(stderr, "Py_BytesMain fehlt\n"); return 71; }
    if (argc > 1) return py_main(argc, argv);          /* Testaufruf des Installers */
    char *args[] = { argv[0], LAUNCH_SCRIPT, NULL };
    return py_main(2, args);
}
