# Startdatei von Cockpit.
# Bindet die installierten Bausteine ein, leitet Ausgaben ins Protokoll und
# startet die Oberfläche. Läuft innerhalb des App-Prozesses „Cockpit“,
# damit macOS die Freigaben dieser App zuordnet (nicht „Python“).
import datetime
import os
import site
import subprocess
import sys
import traceback

HOME = os.environ.get("COCKPIT_HOME") or os.path.expanduser(
    "~/Library/Application Support/Cockpit")
VER = f"python{sys.version_info.major}.{sys.version_info.minor}"
site.addsitedir(os.path.join(HOME, "venv", "lib", VER, "site-packages"))
sys.path.insert(0, os.path.join(HOME, "app"))

LOG_DIR = os.path.expanduser("~/Library/Logs/Cockpit")
try:
    os.makedirs(LOG_DIR, exist_ok=True)
    log_path = os.path.join(LOG_DIR, "protokoll.txt")
    # nicht endlos wachsen lassen
    if os.path.exists(log_path) and os.path.getsize(log_path) > 2_000_000:
        os.replace(log_path, log_path + ".alt")
    log = open(log_path, "a", buffering=1, encoding="utf-8")
    sys.stdout = sys.stderr = log
except OSError:
    try:
        log = open(os.path.join(HOME, "protokoll.txt"), "a", buffering=1, encoding="utf-8")
        sys.stdout = sys.stderr = log
    except OSError:
        pass

print(f"\n--- Start {datetime.datetime.now():%Y-%m-%d %H:%M:%S} · "
      f"{sys.executable} · Python {sys.version.split()[0]}")

try:
    import cockpit_app
    cockpit_app.main()
except Exception:  # noqa: BLE001
    traceback.print_exc()
    subprocess.run(["/usr/bin/osascript", "-e",
                    'display alert "Cockpit konnte nicht starten" message '
                    '"Details stehen in ~/Library/Logs/Cockpit/protokoll.txt"'])
finally:
    try:
        sys.stdout.flush()
    except Exception:  # noqa: BLE001
        pass
    os._exit(0)
